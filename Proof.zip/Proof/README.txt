

Alex Moore and CJ Saddler 
Read Me :) this took forever 

We replaced the xv6 built in scheduler with a stride scheduler. Each process has a stride, and the scheduler always runs the RUNNABLE process with the lowest pass value, then adds that process’s stride to its pass. We also added a tester call so we could tarack the runtime for our proof
-----
We worked on the whole project together. Alex did most of the research into how to implement the scheduler, using the stride scheduling section of the textbook. CJ was more comfortable working inside the kernel and handled most of the changes to proc.c and the system call code. We spent the entire development period together. We added all of the stuff inside of pstat.h. It just makes the struct pstat. We then changed up the original testing code to our test file. tester.c makes a call and prints passTotal all runing process’s pid, runtime, and pass.

The most interesting part was building the scheduler, we just took the orginal scheduler and were able to add a few blocks to it to create our stride scheduler. We added the block where reset the counter when passTotal got too big. We added the function to find the lowest pass and then had to build the logic where the scheduler switches to the process and releases the lock
Test program and build

For our proof We ran xv6 on one CPU and then made three copies of hardwork in the background with strides 1, 2, and 4. Then we ran our tester call over and over to get our data of the strides working. we ran it over a span of around 13 minutes. By the end the tests always showed a ratio close to the 4 to 2 to 1 ratio we were looking for. If we let it run even longer were sure it would've reached it.


The project was similar to the previous one, so moving between the header files and C files was not too bad and actually felt a bit comfortable. The most frustrating part was actually getting our scheduler to work because we had many logical issues trying get it to work based of the pseudo code in the book

To run just compile and open in qemu, then just run hardwork 1 2 and 4 and then run tester to see results