user/gfiletest.o: user/gfiletest.c kernel/types.h kernel/stat.h \
 user/user.h kernel/fs.h kernel/fcntl.h
