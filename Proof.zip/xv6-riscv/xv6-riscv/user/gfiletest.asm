
user/_gfiletest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <openFive>:
int fd2=0;
int fd3=0;
int fd4=0;
int fd5=0;
void openFive()
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
fd1 = open("gfilenumtest1", O_CREATE|O_WRONLY);
   8:	20100593          	li	a1,513
   c:	00001517          	auipc	a0,0x1
  10:	a6450513          	addi	a0,a0,-1436 # a70 <malloc+0xfe>
  14:	484000ef          	jal	498 <open>
  18:	00002797          	auipc	a5,0x2
  1c:	fea7ac23          	sw	a0,-8(a5) # 2010 <fd1>
fd2 = open("gfilenumtest2", O_CREATE|O_WRONLY);
  20:	20100593          	li	a1,513
  24:	00001517          	auipc	a0,0x1
  28:	a5c50513          	addi	a0,a0,-1444 # a80 <malloc+0x10e>
  2c:	46c000ef          	jal	498 <open>
  30:	00002797          	auipc	a5,0x2
  34:	fca7ae23          	sw	a0,-36(a5) # 200c <fd2>
fd3 = open("gfilenumtest3", O_CREATE|O_WRONLY);
  38:	20100593          	li	a1,513
  3c:	00001517          	auipc	a0,0x1
  40:	a5450513          	addi	a0,a0,-1452 # a90 <malloc+0x11e>
  44:	454000ef          	jal	498 <open>
  48:	00002797          	auipc	a5,0x2
  4c:	fca7a023          	sw	a0,-64(a5) # 2008 <fd3>
fd4 = open("gfilenumtest4", O_CREATE|O_WRONLY);
  50:	20100593          	li	a1,513
  54:	00001517          	auipc	a0,0x1
  58:	a4c50513          	addi	a0,a0,-1460 # aa0 <malloc+0x12e>
  5c:	43c000ef          	jal	498 <open>
  60:	00002797          	auipc	a5,0x2
  64:	faa7a223          	sw	a0,-92(a5) # 2004 <fd4>
fd5 = open("gfilenumtest5", O_CREATE|O_WRONLY);
  68:	20100593          	li	a1,513
  6c:	00001517          	auipc	a0,0x1
  70:	a4450513          	addi	a0,a0,-1468 # ab0 <malloc+0x13e>
  74:	424000ef          	jal	498 <open>
  78:	00002797          	auipc	a5,0x2
  7c:	f8a7a423          	sw	a0,-120(a5) # 2000 <fd5>
}
  80:	60a2                	ld	ra,8(sp)
  82:	6402                	ld	s0,0(sp)
  84:	0141                	addi	sp,sp,16
  86:	8082                	ret

0000000000000088 <main>:
int
main(int argc, char **argv)
{
  88:	1101                	addi	sp,sp,-32
  8a:	ec06                	sd	ra,24(sp)
  8c:	e822                	sd	s0,16(sp)
  8e:	e426                	sd	s1,8(sp)
  90:	e04a                	sd	s2,0(sp)
  92:	1000                	addi	s0,sp,32
int pid = getpid();
  94:	444000ef          	jal	4d8 <getpid>
  98:	84aa                	mv	s1,a0
printf("files open for %d\n:",pid);
  9a:	85aa                	mv	a1,a0
  9c:	00001517          	auipc	a0,0x1
  a0:	a2450513          	addi	a0,a0,-1500 # ac0 <malloc+0x14e>
  a4:	013000ef          	jal	8b6 <printf>
printf("before opening any additional: %d (should be 3)\n",getfilenum(pid));
  a8:	8526                	mv	a0,s1
  aa:	39e000ef          	jal	448 <getfilenum>
  ae:	85aa                	mv	a1,a0
  b0:	00001517          	auipc	a0,0x1
  b4:	a2850513          	addi	a0,a0,-1496 # ad8 <malloc+0x166>
  b8:	7fe000ef          	jal	8b6 <printf>
openFive();
  bc:	f45ff0ef          	jal	0 <openFive>
printf("opened 5: %d (should be 8)\n",getfilenum(pid));
  c0:	8526                	mv	a0,s1
  c2:	386000ef          	jal	448 <getfilenum>
  c6:	85aa                	mv	a1,a0
  c8:	00001517          	auipc	a0,0x1
  cc:	a4850513          	addi	a0,a0,-1464 # b10 <malloc+0x19e>
  d0:	7e6000ef          	jal	8b6 <printf>
close(fd3);
  d4:	00002517          	auipc	a0,0x2
  d8:	f3452503          	lw	a0,-204(a0) # 2008 <fd3>
  dc:	3a4000ef          	jal	480 <close>
printf("closed 1: %d (should be 7)\n",getfilenum(pid));
  e0:	8526                	mv	a0,s1
  e2:	366000ef          	jal	448 <getfilenum>
  e6:	85aa                	mv	a1,a0
  e8:	00001517          	auipc	a0,0x1
  ec:	a4850513          	addi	a0,a0,-1464 # b30 <malloc+0x1be>
  f0:	7c6000ef          	jal	8b6 <printf>
close(fd1);
  f4:	00002517          	auipc	a0,0x2
  f8:	f1c52503          	lw	a0,-228(a0) # 2010 <fd1>
  fc:	384000ef          	jal	480 <close>
printf("closed another: %d (should be 6)\n",getfilenum(pid));
 100:	8526                	mv	a0,s1
 102:	346000ef          	jal	448 <getfilenum>
 106:	85aa                	mv	a1,a0
 108:	00001517          	auipc	a0,0x1
 10c:	a4850513          	addi	a0,a0,-1464 # b50 <malloc+0x1de>
 110:	7a6000ef          	jal	8b6 <printf>
close(fd5);
 114:	00002917          	auipc	s2,0x2
 118:	eec90913          	addi	s2,s2,-276 # 2000 <fd5>
 11c:	00092503          	lw	a0,0(s2)
 120:	360000ef          	jal	480 <close>
printf("closed another: %d (should be 5)\n",getfilenum(pid));
 124:	8526                	mv	a0,s1
 126:	322000ef          	jal	448 <getfilenum>
 12a:	85aa                	mv	a1,a0
 12c:	00001517          	auipc	a0,0x1
 130:	a4c50513          	addi	a0,a0,-1460 # b78 <malloc+0x206>
 134:	782000ef          	jal	8b6 <printf>
fd5 = open("gfilenmumtest6", O_CREATE|O_WRONLY);
 138:	20100593          	li	a1,513
 13c:	00001517          	auipc	a0,0x1
 140:	a6450513          	addi	a0,a0,-1436 # ba0 <malloc+0x22e>
 144:	354000ef          	jal	498 <open>
 148:	00a92023          	sw	a0,0(s2)
printf("opened 1: %d (should be 6)\n",getfilenum(pid));
 14c:	8526                	mv	a0,s1
 14e:	2fa000ef          	jal	448 <getfilenum>
 152:	85aa                	mv	a1,a0
 154:	00001517          	auipc	a0,0x1
 158:	a5c50513          	addi	a0,a0,-1444 # bb0 <malloc+0x23e>
 15c:	75a000ef          	jal	8b6 <printf>
close(fd5);
 160:	00092503          	lw	a0,0(s2)
 164:	31c000ef          	jal	480 <close>
close(fd2);
 168:	00002517          	auipc	a0,0x2
 16c:	ea452503          	lw	a0,-348(a0) # 200c <fd2>
 170:	310000ef          	jal	480 <close>
close(fd4);
 174:	00002517          	auipc	a0,0x2
 178:	e9052503          	lw	a0,-368(a0) # 2004 <fd4>
 17c:	304000ef          	jal	480 <close>
printf("closed all: %d (should be 3)\n",getfilenum(pid));
 180:	8526                	mv	a0,s1
 182:	2c6000ef          	jal	448 <getfilenum>
 186:	85aa                	mv	a1,a0
 188:	00001517          	auipc	a0,0x1
 18c:	a4850513          	addi	a0,a0,-1464 # bd0 <malloc+0x25e>
 190:	726000ef          	jal	8b6 <printf>
exit(0);
 194:	4501                	li	a0,0
 196:	2c2000ef          	jal	458 <exit>

000000000000019a <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 19a:	1141                	addi	sp,sp,-16
 19c:	e406                	sd	ra,8(sp)
 19e:	e022                	sd	s0,0(sp)
 1a0:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 1a2:	ee7ff0ef          	jal	88 <main>
  exit(r);
 1a6:	2b2000ef          	jal	458 <exit>

00000000000001aa <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
 1aa:	1141                	addi	sp,sp,-16
 1ac:	e406                	sd	ra,8(sp)
 1ae:	e022                	sd	s0,0(sp)
 1b0:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
 1b2:	87aa                	mv	a5,a0
 1b4:	0585                	addi	a1,a1,1
 1b6:	0785                	addi	a5,a5,1
 1b8:	fff5c703          	lbu	a4,-1(a1)
 1bc:	fee78fa3          	sb	a4,-1(a5)
 1c0:	fb75                	bnez	a4,1b4 <strcpy+0xa>
    ;
  return os;
}
 1c2:	60a2                	ld	ra,8(sp)
 1c4:	6402                	ld	s0,0(sp)
 1c6:	0141                	addi	sp,sp,16
 1c8:	8082                	ret

00000000000001ca <strcmp>:

int
strcmp(const char *p, const char *q)
{
 1ca:	1141                	addi	sp,sp,-16
 1cc:	e406                	sd	ra,8(sp)
 1ce:	e022                	sd	s0,0(sp)
 1d0:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
 1d2:	00054783          	lbu	a5,0(a0)
 1d6:	cb91                	beqz	a5,1ea <strcmp+0x20>
 1d8:	0005c703          	lbu	a4,0(a1)
 1dc:	00f71763          	bne	a4,a5,1ea <strcmp+0x20>
    p++, q++;
 1e0:	0505                	addi	a0,a0,1
 1e2:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
 1e4:	00054783          	lbu	a5,0(a0)
 1e8:	fbe5                	bnez	a5,1d8 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 1ea:	0005c503          	lbu	a0,0(a1)
}
 1ee:	40a7853b          	subw	a0,a5,a0
 1f2:	60a2                	ld	ra,8(sp)
 1f4:	6402                	ld	s0,0(sp)
 1f6:	0141                	addi	sp,sp,16
 1f8:	8082                	ret

00000000000001fa <strlen>:

uint
strlen(const char *s)
{
 1fa:	1141                	addi	sp,sp,-16
 1fc:	e406                	sd	ra,8(sp)
 1fe:	e022                	sd	s0,0(sp)
 200:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
 202:	00054783          	lbu	a5,0(a0)
 206:	cf91                	beqz	a5,222 <strlen+0x28>
 208:	00150793          	addi	a5,a0,1
 20c:	86be                	mv	a3,a5
 20e:	0785                	addi	a5,a5,1
 210:	fff7c703          	lbu	a4,-1(a5)
 214:	ff65                	bnez	a4,20c <strlen+0x12>
 216:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 21a:	60a2                	ld	ra,8(sp)
 21c:	6402                	ld	s0,0(sp)
 21e:	0141                	addi	sp,sp,16
 220:	8082                	ret
  for (n = 0; s[n]; n++)
 222:	4501                	li	a0,0
 224:	bfdd                	j	21a <strlen+0x20>

0000000000000226 <memset>:

void *
memset(void *dst, int c, uint n)
{
 226:	1141                	addi	sp,sp,-16
 228:	e406                	sd	ra,8(sp)
 22a:	e022                	sd	s0,0(sp)
 22c:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
 22e:	ca19                	beqz	a2,244 <memset+0x1e>
 230:	87aa                	mv	a5,a0
 232:	1602                	slli	a2,a2,0x20
 234:	9201                	srli	a2,a2,0x20
 236:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 23a:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
 23e:	0785                	addi	a5,a5,1
 240:	fee79de3          	bne	a5,a4,23a <memset+0x14>
  }
  return dst;
}
 244:	60a2                	ld	ra,8(sp)
 246:	6402                	ld	s0,0(sp)
 248:	0141                	addi	sp,sp,16
 24a:	8082                	ret

000000000000024c <strchr>:

char *
strchr(const char *s, char c)
{
 24c:	1141                	addi	sp,sp,-16
 24e:	e406                	sd	ra,8(sp)
 250:	e022                	sd	s0,0(sp)
 252:	0800                	addi	s0,sp,16
  for (; *s; s++)
 254:	00054783          	lbu	a5,0(a0)
 258:	c799                	beqz	a5,266 <strchr+0x1a>
    if (*s == c)
 25a:	00f58763          	beq	a1,a5,268 <strchr+0x1c>
  for (; *s; s++)
 25e:	0505                	addi	a0,a0,1
 260:	00054783          	lbu	a5,0(a0)
 264:	fbfd                	bnez	a5,25a <strchr+0xe>
      return (char *)s;
  return 0;
 266:	4501                	li	a0,0
}
 268:	60a2                	ld	ra,8(sp)
 26a:	6402                	ld	s0,0(sp)
 26c:	0141                	addi	sp,sp,16
 26e:	8082                	ret

0000000000000270 <gets>:

char *
gets(char *buf, int max)
{
 270:	711d                	addi	sp,sp,-96
 272:	ec86                	sd	ra,88(sp)
 274:	e8a2                	sd	s0,80(sp)
 276:	e4a6                	sd	s1,72(sp)
 278:	e0ca                	sd	s2,64(sp)
 27a:	fc4e                	sd	s3,56(sp)
 27c:	f852                	sd	s4,48(sp)
 27e:	f456                	sd	s5,40(sp)
 280:	f05a                	sd	s6,32(sp)
 282:	ec5e                	sd	s7,24(sp)
 284:	e862                	sd	s8,16(sp)
 286:	1080                	addi	s0,sp,96
 288:	8baa                	mv	s7,a0
 28a:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
 28c:	892a                	mv	s2,a0
 28e:	4481                	li	s1,0
    cc = read(0, &c, 1);
 290:	faf40b13          	addi	s6,s0,-81
 294:	4a85                	li	s5,1
  for (i = 0; i + 1 < max;) {
 296:	8c26                	mv	s8,s1
 298:	0014899b          	addiw	s3,s1,1
 29c:	84ce                	mv	s1,s3
 29e:	0349d863          	bge	s3,s4,2ce <gets+0x5e>
    cc = read(0, &c, 1);
 2a2:	8656                	mv	a2,s5
 2a4:	85da                	mv	a1,s6
 2a6:	4501                	li	a0,0
 2a8:	1c8000ef          	jal	470 <read>
    if (cc < 1)
 2ac:	02a05163          	blez	a0,2ce <gets+0x5e>
      break;
    buf[i++] = c;
 2b0:	faf44783          	lbu	a5,-81(s0)
 2b4:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
 2b8:	0905                	addi	s2,s2,1
 2ba:	ff678713          	addi	a4,a5,-10
 2be:	00173713          	seqz	a4,a4
 2c2:	17cd                	addi	a5,a5,-13
 2c4:	0017b793          	seqz	a5,a5
 2c8:	8fd9                	or	a5,a5,a4
 2ca:	d7f1                	beqz	a5,296 <gets+0x26>
    buf[i++] = c;
 2cc:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 2ce:	9c5e                	add	s8,s8,s7
 2d0:	000c0023          	sb	zero,0(s8)
  return buf;
}
 2d4:	855e                	mv	a0,s7
 2d6:	60e6                	ld	ra,88(sp)
 2d8:	6446                	ld	s0,80(sp)
 2da:	64a6                	ld	s1,72(sp)
 2dc:	6906                	ld	s2,64(sp)
 2de:	79e2                	ld	s3,56(sp)
 2e0:	7a42                	ld	s4,48(sp)
 2e2:	7aa2                	ld	s5,40(sp)
 2e4:	7b02                	ld	s6,32(sp)
 2e6:	6be2                	ld	s7,24(sp)
 2e8:	6c42                	ld	s8,16(sp)
 2ea:	6125                	addi	sp,sp,96
 2ec:	8082                	ret

00000000000002ee <stat>:

int
stat(const char *n, struct stat *st)
{
 2ee:	1101                	addi	sp,sp,-32
 2f0:	ec06                	sd	ra,24(sp)
 2f2:	e822                	sd	s0,16(sp)
 2f4:	e04a                	sd	s2,0(sp)
 2f6:	1000                	addi	s0,sp,32
 2f8:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 2fa:	4581                	li	a1,0
 2fc:	19c000ef          	jal	498 <open>
  if (fd < 0)
 300:	02054263          	bltz	a0,324 <stat+0x36>
 304:	e426                	sd	s1,8(sp)
 306:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 308:	85ca                	mv	a1,s2
 30a:	1a6000ef          	jal	4b0 <fstat>
 30e:	892a                	mv	s2,a0
  close(fd);
 310:	8526                	mv	a0,s1
 312:	16e000ef          	jal	480 <close>
  return r;
 316:	64a2                	ld	s1,8(sp)
}
 318:	854a                	mv	a0,s2
 31a:	60e2                	ld	ra,24(sp)
 31c:	6442                	ld	s0,16(sp)
 31e:	6902                	ld	s2,0(sp)
 320:	6105                	addi	sp,sp,32
 322:	8082                	ret
    return -1;
 324:	57fd                	li	a5,-1
 326:	893e                	mv	s2,a5
 328:	bfc5                	j	318 <stat+0x2a>

000000000000032a <atoi>:

int
atoi(const char *s)
{
 32a:	1141                	addi	sp,sp,-16
 32c:	e406                	sd	ra,8(sp)
 32e:	e022                	sd	s0,0(sp)
 330:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
 332:	00054683          	lbu	a3,0(a0)
 336:	fd06879b          	addiw	a5,a3,-48
 33a:	0ff7f793          	zext.b	a5,a5
 33e:	4625                	li	a2,9
 340:	02f66963          	bltu	a2,a5,372 <atoi+0x48>
 344:	872a                	mv	a4,a0
  n = 0;
 346:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
 348:	0705                	addi	a4,a4,1
 34a:	0025179b          	slliw	a5,a0,0x2
 34e:	9fa9                	addw	a5,a5,a0
 350:	0017979b          	slliw	a5,a5,0x1
 354:	9fb5                	addw	a5,a5,a3
 356:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
 35a:	00074683          	lbu	a3,0(a4)
 35e:	fd06879b          	addiw	a5,a3,-48
 362:	0ff7f793          	zext.b	a5,a5
 366:	fef671e3          	bgeu	a2,a5,348 <atoi+0x1e>
  return n;
}
 36a:	60a2                	ld	ra,8(sp)
 36c:	6402                	ld	s0,0(sp)
 36e:	0141                	addi	sp,sp,16
 370:	8082                	ret
  n = 0;
 372:	4501                	li	a0,0
 374:	bfdd                	j	36a <atoi+0x40>

0000000000000376 <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
 376:	1141                	addi	sp,sp,-16
 378:	e406                	sd	ra,8(sp)
 37a:	e022                	sd	s0,0(sp)
 37c:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 37e:	02b57563          	bgeu	a0,a1,3a8 <memmove+0x32>
    while (n-- > 0)
 382:	00c05f63          	blez	a2,3a0 <memmove+0x2a>
 386:	1602                	slli	a2,a2,0x20
 388:	9201                	srli	a2,a2,0x20
 38a:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 38e:	872a                	mv	a4,a0
      *dst++ = *src++;
 390:	0585                	addi	a1,a1,1
 392:	0705                	addi	a4,a4,1
 394:	fff5c683          	lbu	a3,-1(a1)
 398:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
 39c:	fee79ae3          	bne	a5,a4,390 <memmove+0x1a>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 3a0:	60a2                	ld	ra,8(sp)
 3a2:	6402                	ld	s0,0(sp)
 3a4:	0141                	addi	sp,sp,16
 3a6:	8082                	ret
    while (n-- > 0)
 3a8:	fec05ce3          	blez	a2,3a0 <memmove+0x2a>
    dst += n;
 3ac:	00c50733          	add	a4,a0,a2
    src += n;
 3b0:	95b2                	add	a1,a1,a2
 3b2:	fff6079b          	addiw	a5,a2,-1
 3b6:	1782                	slli	a5,a5,0x20
 3b8:	9381                	srli	a5,a5,0x20
 3ba:	fff7c793          	not	a5,a5
 3be:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 3c0:	15fd                	addi	a1,a1,-1
 3c2:	177d                	addi	a4,a4,-1
 3c4:	0005c683          	lbu	a3,0(a1)
 3c8:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
 3cc:	fef71ae3          	bne	a4,a5,3c0 <memmove+0x4a>
 3d0:	bfc1                	j	3a0 <memmove+0x2a>

00000000000003d2 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 3d2:	1141                	addi	sp,sp,-16
 3d4:	e406                	sd	ra,8(sp)
 3d6:	e022                	sd	s0,0(sp)
 3d8:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 3da:	ce19                	beqz	a2,3f8 <memcmp+0x26>
 3dc:	1602                	slli	a2,a2,0x20
 3de:	9201                	srli	a2,a2,0x20
 3e0:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 3e4:	00054783          	lbu	a5,0(a0)
 3e8:	0005c703          	lbu	a4,0(a1)
 3ec:	00e79b63          	bne	a5,a4,402 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 3f0:	0505                	addi	a0,a0,1
    p2++;
 3f2:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 3f4:	fed518e3          	bne	a0,a3,3e4 <memcmp+0x12>
  }
  return 0;
 3f8:	4501                	li	a0,0
}
 3fa:	60a2                	ld	ra,8(sp)
 3fc:	6402                	ld	s0,0(sp)
 3fe:	0141                	addi	sp,sp,16
 400:	8082                	ret
      return *p1 - *p2;
 402:	40e7853b          	subw	a0,a5,a4
 406:	bfd5                	j	3fa <memcmp+0x28>

0000000000000408 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 408:	1141                	addi	sp,sp,-16
 40a:	e406                	sd	ra,8(sp)
 40c:	e022                	sd	s0,0(sp)
 40e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 410:	f67ff0ef          	jal	376 <memmove>
}
 414:	60a2                	ld	ra,8(sp)
 416:	6402                	ld	s0,0(sp)
 418:	0141                	addi	sp,sp,16
 41a:	8082                	ret

000000000000041c <sbrk>:

char *
sbrk(int n)
{
 41c:	1141                	addi	sp,sp,-16
 41e:	e406                	sd	ra,8(sp)
 420:	e022                	sd	s0,0(sp)
 422:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 424:	4585                	li	a1,1
 426:	0ba000ef          	jal	4e0 <sys_sbrk>
}
 42a:	60a2                	ld	ra,8(sp)
 42c:	6402                	ld	s0,0(sp)
 42e:	0141                	addi	sp,sp,16
 430:	8082                	ret

0000000000000432 <sbrklazy>:

char *
sbrklazy(int n)
{
 432:	1141                	addi	sp,sp,-16
 434:	e406                	sd	ra,8(sp)
 436:	e022                	sd	s0,0(sp)
 438:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 43a:	4589                	li	a1,2
 43c:	0a4000ef          	jal	4e0 <sys_sbrk>
}
 440:	60a2                	ld	ra,8(sp)
 442:	6402                	ld	s0,0(sp)
 444:	0141                	addi	sp,sp,16
 446:	8082                	ret

0000000000000448 <getfilenum>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global getfilenum
getfilenum:
 li a7, SYS_getfilenum
 448:	48dd                	li	a7,23
 ecall
 44a:	00000073          	ecall
 ret
 44e:	8082                	ret

0000000000000450 <fork>:
.global fork
fork:
 li a7, SYS_fork
 450:	4885                	li	a7,1
 ecall
 452:	00000073          	ecall
 ret
 456:	8082                	ret

0000000000000458 <exit>:
.global exit
exit:
 li a7, SYS_exit
 458:	4889                	li	a7,2
 ecall
 45a:	00000073          	ecall
 ret
 45e:	8082                	ret

0000000000000460 <wait>:
.global wait
wait:
 li a7, SYS_wait
 460:	488d                	li	a7,3
 ecall
 462:	00000073          	ecall
 ret
 466:	8082                	ret

0000000000000468 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 468:	4891                	li	a7,4
 ecall
 46a:	00000073          	ecall
 ret
 46e:	8082                	ret

0000000000000470 <read>:
.global read
read:
 li a7, SYS_read
 470:	4895                	li	a7,5
 ecall
 472:	00000073          	ecall
 ret
 476:	8082                	ret

0000000000000478 <write>:
.global write
write:
 li a7, SYS_write
 478:	48c1                	li	a7,16
 ecall
 47a:	00000073          	ecall
 ret
 47e:	8082                	ret

0000000000000480 <close>:
.global close
close:
 li a7, SYS_close
 480:	48d5                	li	a7,21
 ecall
 482:	00000073          	ecall
 ret
 486:	8082                	ret

0000000000000488 <kill>:
.global kill
kill:
 li a7, SYS_kill
 488:	4899                	li	a7,6
 ecall
 48a:	00000073          	ecall
 ret
 48e:	8082                	ret

0000000000000490 <exec>:
.global exec
exec:
 li a7, SYS_exec
 490:	489d                	li	a7,7
 ecall
 492:	00000073          	ecall
 ret
 496:	8082                	ret

0000000000000498 <open>:
.global open
open:
 li a7, SYS_open
 498:	48bd                	li	a7,15
 ecall
 49a:	00000073          	ecall
 ret
 49e:	8082                	ret

00000000000004a0 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 4a0:	48c5                	li	a7,17
 ecall
 4a2:	00000073          	ecall
 ret
 4a6:	8082                	ret

00000000000004a8 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 4a8:	48c9                	li	a7,18
 ecall
 4aa:	00000073          	ecall
 ret
 4ae:	8082                	ret

00000000000004b0 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 4b0:	48a1                	li	a7,8
 ecall
 4b2:	00000073          	ecall
 ret
 4b6:	8082                	ret

00000000000004b8 <link>:
.global link
link:
 li a7, SYS_link
 4b8:	48cd                	li	a7,19
 ecall
 4ba:	00000073          	ecall
 ret
 4be:	8082                	ret

00000000000004c0 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 4c0:	48d1                	li	a7,20
 ecall
 4c2:	00000073          	ecall
 ret
 4c6:	8082                	ret

00000000000004c8 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 4c8:	48a5                	li	a7,9
 ecall
 4ca:	00000073          	ecall
 ret
 4ce:	8082                	ret

00000000000004d0 <dup>:
.global dup
dup:
 li a7, SYS_dup
 4d0:	48a9                	li	a7,10
 ecall
 4d2:	00000073          	ecall
 ret
 4d6:	8082                	ret

00000000000004d8 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 4d8:	48ad                	li	a7,11
 ecall
 4da:	00000073          	ecall
 ret
 4de:	8082                	ret

00000000000004e0 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 4e0:	48b1                	li	a7,12
 ecall
 4e2:	00000073          	ecall
 ret
 4e6:	8082                	ret

00000000000004e8 <pause>:
.global pause
pause:
 li a7, SYS_pause
 4e8:	48b5                	li	a7,13
 ecall
 4ea:	00000073          	ecall
 ret
 4ee:	8082                	ret

00000000000004f0 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 4f0:	48b9                	li	a7,14
 ecall
 4f2:	00000073          	ecall
 ret
 4f6:	8082                	ret

00000000000004f8 <sync>:
.global sync
sync:
 li a7, SYS_sync
 4f8:	48d9                	li	a7,22
 ecall
 4fa:	00000073          	ecall
 ret
 4fe:	8082                	ret

0000000000000500 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 500:	1101                	addi	sp,sp,-32
 502:	ec06                	sd	ra,24(sp)
 504:	e822                	sd	s0,16(sp)
 506:	1000                	addi	s0,sp,32
 508:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 50c:	4605                	li	a2,1
 50e:	fef40593          	addi	a1,s0,-17
 512:	f67ff0ef          	jal	478 <write>
}
 516:	60e2                	ld	ra,24(sp)
 518:	6442                	ld	s0,16(sp)
 51a:	6105                	addi	sp,sp,32
 51c:	8082                	ret

000000000000051e <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 51e:	715d                	addi	sp,sp,-80
 520:	e486                	sd	ra,72(sp)
 522:	e0a2                	sd	s0,64(sp)
 524:	f84a                	sd	s2,48(sp)
 526:	f44e                	sd	s3,40(sp)
 528:	0880                	addi	s0,sp,80
 52a:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
 52c:	00d036b3          	snez	a3,a3
 530:	03f5d793          	srli	a5,a1,0x3f
 534:	8efd                	and	a3,a3,a5
  neg = 0;
 536:	4301                	li	t1,0
  if (sgn && xx < 0) {
 538:	c681                	beqz	a3,540 <printint+0x22>
    neg = 1;
    x = -xx;
 53a:	40b005b3          	neg	a1,a1
    neg = 1;
 53e:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 540:	fb840993          	addi	s3,s0,-72
  neg = 0;
 544:	86ce                	mv	a3,s3
  i = 0;
 546:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
 548:	00000817          	auipc	a6,0x0
 54c:	6b080813          	addi	a6,a6,1712 # bf8 <digits>
 550:	88ba                	mv	a7,a4
 552:	0017051b          	addiw	a0,a4,1
 556:	872a                	mv	a4,a0
 558:	02c5f7b3          	remu	a5,a1,a2
 55c:	97c2                	add	a5,a5,a6
 55e:	0007c783          	lbu	a5,0(a5)
 562:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
 566:	87ae                	mv	a5,a1
 568:	02c5d5b3          	divu	a1,a1,a2
 56c:	0685                	addi	a3,a3,1
 56e:	fec7f1e3          	bgeu	a5,a2,550 <printint+0x32>
  if (neg)
 572:	00030b63          	beqz	t1,588 <printint+0x6a>
    buf[i++] = '-';
 576:	fd040793          	addi	a5,s0,-48
 57a:	953e                	add	a0,a0,a5
 57c:	02d00793          	li	a5,45
 580:	fef50423          	sb	a5,-24(a0)
 584:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
 588:	02e05563          	blez	a4,5b2 <printint+0x94>
 58c:	fc26                	sd	s1,56(sp)
 58e:	377d                	addiw	a4,a4,-1
 590:	00e984b3          	add	s1,s3,a4
 594:	19fd                	addi	s3,s3,-1
 596:	99ba                	add	s3,s3,a4
 598:	1702                	slli	a4,a4,0x20
 59a:	9301                	srli	a4,a4,0x20
 59c:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 5a0:	0004c583          	lbu	a1,0(s1)
 5a4:	854a                	mv	a0,s2
 5a6:	f5bff0ef          	jal	500 <putc>
  while (--i >= 0)
 5aa:	14fd                	addi	s1,s1,-1
 5ac:	ff349ae3          	bne	s1,s3,5a0 <printint+0x82>
 5b0:	74e2                	ld	s1,56(sp)
}
 5b2:	60a6                	ld	ra,72(sp)
 5b4:	6406                	ld	s0,64(sp)
 5b6:	7942                	ld	s2,48(sp)
 5b8:	79a2                	ld	s3,40(sp)
 5ba:	6161                	addi	sp,sp,80
 5bc:	8082                	ret

00000000000005be <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 5be:	711d                	addi	sp,sp,-96
 5c0:	ec86                	sd	ra,88(sp)
 5c2:	e8a2                	sd	s0,80(sp)
 5c4:	e4a6                	sd	s1,72(sp)
 5c6:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
 5c8:	0005c483          	lbu	s1,0(a1)
 5cc:	2a048063          	beqz	s1,86c <vprintf+0x2ae>
 5d0:	e0ca                	sd	s2,64(sp)
 5d2:	fc4e                	sd	s3,56(sp)
 5d4:	f852                	sd	s4,48(sp)
 5d6:	f456                	sd	s5,40(sp)
 5d8:	f05a                	sd	s6,32(sp)
 5da:	ec5e                	sd	s7,24(sp)
 5dc:	e862                	sd	s8,16(sp)
 5de:	8b2a                	mv	s6,a0
 5e0:	8a2e                	mv	s4,a1
 5e2:	8bb2                	mv	s7,a2
  state = 0;
 5e4:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
 5e6:	4901                	li	s2,0
 5e8:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
 5ea:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
 5ee:	06400c13          	li	s8,100
 5f2:	a00d                	j	614 <vprintf+0x56>
        putc(fd, c0);
 5f4:	85a6                	mv	a1,s1
 5f6:	855a                	mv	a0,s6
 5f8:	f09ff0ef          	jal	500 <putc>
 5fc:	a019                	j	602 <vprintf+0x44>
    } else if (state == '%') {
 5fe:	03598363          	beq	s3,s5,624 <vprintf+0x66>
  for (i = 0; fmt[i]; i++) {
 602:	0019079b          	addiw	a5,s2,1
 606:	893e                	mv	s2,a5
 608:	873e                	mv	a4,a5
 60a:	97d2                	add	a5,a5,s4
 60c:	0007c483          	lbu	s1,0(a5)
 610:	24048763          	beqz	s1,85e <vprintf+0x2a0>
    c0 = fmt[i] & 0xff;
 614:	0004879b          	sext.w	a5,s1
    if (state == 0) {
 618:	fe0993e3          	bnez	s3,5fe <vprintf+0x40>
      if (c0 == '%') {
 61c:	fd579ce3          	bne	a5,s5,5f4 <vprintf+0x36>
        state = '%';
 620:	89be                	mv	s3,a5
 622:	b7c5                	j	602 <vprintf+0x44>
        c1 = fmt[i + 1] & 0xff;
 624:	00ea06b3          	add	a3,s4,a4
 628:	0016c603          	lbu	a2,1(a3)
      if (c1)
 62c:	24060563          	beqz	a2,876 <vprintf+0x2b8>
      if (c0 == 'd') {
 630:	0b878763          	beq	a5,s8,6de <vprintf+0x120>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
 634:	f9478693          	addi	a3,a5,-108
 638:	0016b693          	seqz	a3,a3
 63c:	f9c60593          	addi	a1,a2,-100
 640:	0015b593          	seqz	a1,a1
 644:	8df5                	and	a1,a1,a3
 646:	e9c5                	bnez	a1,6f6 <vprintf+0x138>
        c2 = fmt[i + 2] & 0xff;
 648:	9752                	add	a4,a4,s4
 64a:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 64e:	f9460713          	addi	a4,a2,-108
 652:	00173713          	seqz	a4,a4
 656:	8f75                	and	a4,a4,a3
 658:	f9c50593          	addi	a1,a0,-100
 65c:	0015b593          	seqz	a1,a1
 660:	8df9                	and	a1,a1,a4
 662:	e5dd                	bnez	a1,710 <vprintf+0x152>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if (c0 == 'u') {
 664:	07500593          	li	a1,117
 668:	0cb78163          	beq	a5,a1,72a <vprintf+0x16c>
        printint(fd, va_arg(ap, uint32), 10, 0);
      } else if (c0 == 'l' && c1 == 'u') {
 66c:	f8b60593          	addi	a1,a2,-117
 670:	0015b593          	seqz	a1,a1
 674:	8df5                	and	a1,a1,a3
 676:	e5f1                	bnez	a1,742 <vprintf+0x184>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
 678:	f8b50593          	addi	a1,a0,-117
 67c:	0015b593          	seqz	a1,a1
 680:	8df9                	and	a1,a1,a4
 682:	ede9                	bnez	a1,75c <vprintf+0x19e>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if (c0 == 'x') {
 684:	07800593          	li	a1,120
 688:	0eb78763          	beq	a5,a1,776 <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint32), 16, 0);
      } else if (c0 == 'l' && c1 == 'x') {
 68c:	f8860613          	addi	a2,a2,-120
 690:	00163613          	seqz	a2,a2
 694:	8ef1                	and	a3,a3,a2
 696:	0e069c63          	bnez	a3,78e <vprintf+0x1d0>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
 69a:	f8850513          	addi	a0,a0,-120
 69e:	00153513          	seqz	a0,a0
 6a2:	8f69                	and	a4,a4,a0
 6a4:	10071263          	bnez	a4,7a8 <vprintf+0x1ea>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if (c0 == 'p') {
 6a8:	07000713          	li	a4,112
 6ac:	10e78a63          	beq	a5,a4,7c0 <vprintf+0x202>
        printptr(fd, va_arg(ap, uint64));
      } else if (c0 == 'c') {
 6b0:	06300713          	li	a4,99
 6b4:	14e78a63          	beq	a5,a4,808 <vprintf+0x24a>
        putc(fd, va_arg(ap, uint32));
      } else if (c0 == 's') {
 6b8:	07300713          	li	a4,115
 6bc:	16e78063          	beq	a5,a4,81c <vprintf+0x25e>
        if ((s = va_arg(ap, char *)) == 0)
          s = "(null)";
        for (; *s; s++)
          putc(fd, *s);
      } else if (c0 == '%') {
 6c0:	02500713          	li	a4,37
 6c4:	18e78863          	beq	a5,a4,854 <vprintf+0x296>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 6c8:	02500593          	li	a1,37
 6cc:	855a                	mv	a0,s6
 6ce:	e33ff0ef          	jal	500 <putc>
        putc(fd, c0);
 6d2:	85a6                	mv	a1,s1
 6d4:	855a                	mv	a0,s6
 6d6:	e2bff0ef          	jal	500 <putc>
      }

      state = 0;
 6da:	4981                	li	s3,0
 6dc:	b71d                	j	602 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 6de:	008b8493          	addi	s1,s7,8
 6e2:	4685                	li	a3,1
 6e4:	4629                	li	a2,10
 6e6:	000ba583          	lw	a1,0(s7)
 6ea:	855a                	mv	a0,s6
 6ec:	e33ff0ef          	jal	51e <printint>
 6f0:	8ba6                	mv	s7,s1
      state = 0;
 6f2:	4981                	li	s3,0
 6f4:	b739                	j	602 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 6f6:	008b8493          	addi	s1,s7,8
 6fa:	4685                	li	a3,1
 6fc:	4629                	li	a2,10
 6fe:	000bb583          	ld	a1,0(s7)
 702:	855a                	mv	a0,s6
 704:	e1bff0ef          	jal	51e <printint>
        i += 1;
 708:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 70a:	8ba6                	mv	s7,s1
      state = 0;
 70c:	4981                	li	s3,0
 70e:	bdd5                	j	602 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 710:	008b8493          	addi	s1,s7,8
 714:	4685                	li	a3,1
 716:	4629                	li	a2,10
 718:	000bb583          	ld	a1,0(s7)
 71c:	855a                	mv	a0,s6
 71e:	e01ff0ef          	jal	51e <printint>
        i += 2;
 722:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 724:	8ba6                	mv	s7,s1
      state = 0;
 726:	4981                	li	s3,0
        i += 2;
 728:	bde9                	j	602 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 72a:	008b8493          	addi	s1,s7,8
 72e:	4681                	li	a3,0
 730:	4629                	li	a2,10
 732:	000be583          	lwu	a1,0(s7)
 736:	855a                	mv	a0,s6
 738:	de7ff0ef          	jal	51e <printint>
 73c:	8ba6                	mv	s7,s1
      state = 0;
 73e:	4981                	li	s3,0
 740:	b5c9                	j	602 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 742:	008b8493          	addi	s1,s7,8
 746:	4681                	li	a3,0
 748:	4629                	li	a2,10
 74a:	000bb583          	ld	a1,0(s7)
 74e:	855a                	mv	a0,s6
 750:	dcfff0ef          	jal	51e <printint>
        i += 1;
 754:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 756:	8ba6                	mv	s7,s1
      state = 0;
 758:	4981                	li	s3,0
 75a:	b565                	j	602 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 75c:	008b8493          	addi	s1,s7,8
 760:	4681                	li	a3,0
 762:	4629                	li	a2,10
 764:	000bb583          	ld	a1,0(s7)
 768:	855a                	mv	a0,s6
 76a:	db5ff0ef          	jal	51e <printint>
        i += 2;
 76e:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 770:	8ba6                	mv	s7,s1
      state = 0;
 772:	4981                	li	s3,0
        i += 2;
 774:	b579                	j	602 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 776:	008b8493          	addi	s1,s7,8
 77a:	4681                	li	a3,0
 77c:	4641                	li	a2,16
 77e:	000be583          	lwu	a1,0(s7)
 782:	855a                	mv	a0,s6
 784:	d9bff0ef          	jal	51e <printint>
 788:	8ba6                	mv	s7,s1
      state = 0;
 78a:	4981                	li	s3,0
 78c:	bd9d                	j	602 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 78e:	008b8493          	addi	s1,s7,8
 792:	4681                	li	a3,0
 794:	4641                	li	a2,16
 796:	000bb583          	ld	a1,0(s7)
 79a:	855a                	mv	a0,s6
 79c:	d83ff0ef          	jal	51e <printint>
        i += 1;
 7a0:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 7a2:	8ba6                	mv	s7,s1
      state = 0;
 7a4:	4981                	li	s3,0
 7a6:	bdb1                	j	602 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 7a8:	008b8493          	addi	s1,s7,8
 7ac:	4641                	li	a2,16
 7ae:	000bb583          	ld	a1,0(s7)
 7b2:	855a                	mv	a0,s6
 7b4:	d6bff0ef          	jal	51e <printint>
        i += 2;
 7b8:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 7ba:	8ba6                	mv	s7,s1
      state = 0;
 7bc:	4981                	li	s3,0
        i += 2;
 7be:	b591                	j	602 <vprintf+0x44>
 7c0:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 7c2:	008b8793          	addi	a5,s7,8
 7c6:	8cbe                	mv	s9,a5
 7c8:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 7cc:	03000593          	li	a1,48
 7d0:	855a                	mv	a0,s6
 7d2:	d2fff0ef          	jal	500 <putc>
  putc(fd, 'x');
 7d6:	07800593          	li	a1,120
 7da:	855a                	mv	a0,s6
 7dc:	d25ff0ef          	jal	500 <putc>
 7e0:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 7e2:	00000b97          	auipc	s7,0x0
 7e6:	416b8b93          	addi	s7,s7,1046 # bf8 <digits>
 7ea:	03c9d793          	srli	a5,s3,0x3c
 7ee:	97de                	add	a5,a5,s7
 7f0:	0007c583          	lbu	a1,0(a5)
 7f4:	855a                	mv	a0,s6
 7f6:	d0bff0ef          	jal	500 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 7fa:	0992                	slli	s3,s3,0x4
 7fc:	34fd                	addiw	s1,s1,-1
 7fe:	f4f5                	bnez	s1,7ea <vprintf+0x22c>
        printptr(fd, va_arg(ap, uint64));
 800:	8be6                	mv	s7,s9
      state = 0;
 802:	4981                	li	s3,0
 804:	6ca2                	ld	s9,8(sp)
 806:	bbf5                	j	602 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 808:	008b8493          	addi	s1,s7,8
 80c:	000bc583          	lbu	a1,0(s7)
 810:	855a                	mv	a0,s6
 812:	cefff0ef          	jal	500 <putc>
 816:	8ba6                	mv	s7,s1
      state = 0;
 818:	4981                	li	s3,0
 81a:	b3e5                	j	602 <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
 81c:	008b8993          	addi	s3,s7,8
 820:	000bb483          	ld	s1,0(s7)
 824:	cc91                	beqz	s1,840 <vprintf+0x282>
        for (; *s; s++)
 826:	0004c583          	lbu	a1,0(s1)
 82a:	c195                	beqz	a1,84e <vprintf+0x290>
          putc(fd, *s);
 82c:	855a                	mv	a0,s6
 82e:	cd3ff0ef          	jal	500 <putc>
        for (; *s; s++)
 832:	0485                	addi	s1,s1,1
 834:	0004c583          	lbu	a1,0(s1)
 838:	f9f5                	bnez	a1,82c <vprintf+0x26e>
        if ((s = va_arg(ap, char *)) == 0)
 83a:	8bce                	mv	s7,s3
      state = 0;
 83c:	4981                	li	s3,0
 83e:	b3d1                	j	602 <vprintf+0x44>
          s = "(null)";
 840:	00000497          	auipc	s1,0x0
 844:	3b048493          	addi	s1,s1,944 # bf0 <malloc+0x27e>
        for (; *s; s++)
 848:	02800593          	li	a1,40
 84c:	b7c5                	j	82c <vprintf+0x26e>
        if ((s = va_arg(ap, char *)) == 0)
 84e:	8bce                	mv	s7,s3
      state = 0;
 850:	4981                	li	s3,0
 852:	bb45                	j	602 <vprintf+0x44>
        putc(fd, '%');
 854:	85be                	mv	a1,a5
 856:	855a                	mv	a0,s6
 858:	ca9ff0ef          	jal	500 <putc>
 85c:	bdbd                	j	6da <vprintf+0x11c>
 85e:	6906                	ld	s2,64(sp)
 860:	79e2                	ld	s3,56(sp)
 862:	7a42                	ld	s4,48(sp)
 864:	7aa2                	ld	s5,40(sp)
 866:	7b02                	ld	s6,32(sp)
 868:	6be2                	ld	s7,24(sp)
 86a:	6c42                	ld	s8,16(sp)
    }
  }
}
 86c:	60e6                	ld	ra,88(sp)
 86e:	6446                	ld	s0,80(sp)
 870:	64a6                	ld	s1,72(sp)
 872:	6125                	addi	sp,sp,96
 874:	8082                	ret
      if (c0 == 'd') {
 876:	06400713          	li	a4,100
 87a:	e6e782e3          	beq	a5,a4,6de <vprintf+0x120>
      } else if (c0 == 'l' && c1 == 'd') {
 87e:	f9478693          	addi	a3,a5,-108
 882:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 886:	8532                	mv	a0,a2
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 888:	4701                	li	a4,0
 88a:	bbe9                	j	664 <vprintf+0xa6>

000000000000088c <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 88c:	715d                	addi	sp,sp,-80
 88e:	ec06                	sd	ra,24(sp)
 890:	e822                	sd	s0,16(sp)
 892:	1000                	addi	s0,sp,32
 894:	e010                	sd	a2,0(s0)
 896:	e414                	sd	a3,8(s0)
 898:	e818                	sd	a4,16(s0)
 89a:	ec1c                	sd	a5,24(s0)
 89c:	03043023          	sd	a6,32(s0)
 8a0:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 8a4:	8622                	mv	a2,s0
 8a6:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 8aa:	d15ff0ef          	jal	5be <vprintf>
}
 8ae:	60e2                	ld	ra,24(sp)
 8b0:	6442                	ld	s0,16(sp)
 8b2:	6161                	addi	sp,sp,80
 8b4:	8082                	ret

00000000000008b6 <printf>:

void
printf(const char *fmt, ...)
{
 8b6:	711d                	addi	sp,sp,-96
 8b8:	ec06                	sd	ra,24(sp)
 8ba:	e822                	sd	s0,16(sp)
 8bc:	1000                	addi	s0,sp,32
 8be:	e40c                	sd	a1,8(s0)
 8c0:	e810                	sd	a2,16(s0)
 8c2:	ec14                	sd	a3,24(s0)
 8c4:	f018                	sd	a4,32(s0)
 8c6:	f41c                	sd	a5,40(s0)
 8c8:	03043823          	sd	a6,48(s0)
 8cc:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 8d0:	00840613          	addi	a2,s0,8
 8d4:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 8d8:	85aa                	mv	a1,a0
 8da:	4505                	li	a0,1
 8dc:	ce3ff0ef          	jal	5be <vprintf>
}
 8e0:	60e2                	ld	ra,24(sp)
 8e2:	6442                	ld	s0,16(sp)
 8e4:	6125                	addi	sp,sp,96
 8e6:	8082                	ret

00000000000008e8 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 8e8:	1141                	addi	sp,sp,-16
 8ea:	e406                	sd	ra,8(sp)
 8ec:	e022                	sd	s0,0(sp)
 8ee:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
 8f0:	ff050713          	addi	a4,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8f4:	00001797          	auipc	a5,0x1
 8f8:	7247b783          	ld	a5,1828(a5) # 2018 <freep>
 8fc:	a095                	j	960 <free+0x78>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if (bp + bp->s.size == p->s.ptr) {
 8fe:	ff852583          	lw	a1,-8(a0)
 902:	6390                	ld	a2,0(a5)
 904:	02059813          	slli	a6,a1,0x20
 908:	01c85693          	srli	a3,a6,0x1c
 90c:	96ba                	add	a3,a3,a4
 90e:	02d60563          	beq	a2,a3,938 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 912:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
 916:	4790                	lw	a2,8(a5)
 918:	02061593          	slli	a1,a2,0x20
 91c:	01c5d693          	srli	a3,a1,0x1c
 920:	96be                	add	a3,a3,a5
 922:	02d70263          	beq	a4,a3,946 <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 926:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 928:	00001717          	auipc	a4,0x1
 92c:	6ef73823          	sd	a5,1776(a4) # 2018 <freep>
}
 930:	60a2                	ld	ra,8(sp)
 932:	6402                	ld	s0,0(sp)
 934:	0141                	addi	sp,sp,16
 936:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 938:	4614                	lw	a3,8(a2)
 93a:	9ead                	addw	a3,a3,a1
 93c:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 940:	6394                	ld	a3,0(a5)
 942:	6290                	ld	a2,0(a3)
 944:	b7f9                	j	912 <free+0x2a>
    p->s.size += bp->s.size;
 946:	ff852703          	lw	a4,-8(a0)
 94a:	9f31                	addw	a4,a4,a2
 94c:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 94e:	ff053703          	ld	a4,-16(a0)
 952:	bfd1                	j	926 <free+0x3e>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 954:	6394                	ld	a3,0(a5)
 956:	00d7e463          	bltu	a5,a3,95e <free+0x76>
 95a:	fad762e3          	bltu	a4,a3,8fe <free+0x16>
 95e:	87b6                	mv	a5,a3
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 960:	fee7fae3          	bgeu	a5,a4,954 <free+0x6c>
 964:	6394                	ld	a3,0(a5)
 966:	f8d76ce3          	bltu	a4,a3,8fe <free+0x16>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 96a:	f8d7fae3          	bgeu	a5,a3,8fe <free+0x16>
 96e:	87b6                	mv	a5,a3
 970:	bfc5                	j	960 <free+0x78>

0000000000000972 <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
 972:	7139                	addi	sp,sp,-64
 974:	fc06                	sd	ra,56(sp)
 976:	f822                	sd	s0,48(sp)
 978:	f04a                	sd	s2,32(sp)
 97a:	ec4e                	sd	s3,24(sp)
 97c:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
 97e:	02051993          	slli	s3,a0,0x20
 982:	0209d993          	srli	s3,s3,0x20
 986:	09bd                	addi	s3,s3,15
 988:	0049d993          	srli	s3,s3,0x4
 98c:	2985                	addiw	s3,s3,1
 98e:	894e                	mv	s2,s3
  if ((prevp = freep) == 0) {
 990:	00001517          	auipc	a0,0x1
 994:	68853503          	ld	a0,1672(a0) # 2018 <freep>
 998:	c905                	beqz	a0,9c8 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 99a:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 99c:	4798                	lw	a4,8(a5)
 99e:	09377663          	bgeu	a4,s3,a2a <malloc+0xb8>
 9a2:	f426                	sd	s1,40(sp)
 9a4:	e852                	sd	s4,16(sp)
 9a6:	e456                	sd	s5,8(sp)
 9a8:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
 9aa:	8a4e                	mv	s4,s3
 9ac:	6705                	lui	a4,0x1
 9ae:	00e9f363          	bgeu	s3,a4,9b4 <malloc+0x42>
 9b2:	6a05                	lui	s4,0x1
 9b4:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 9b8:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
 9bc:	00001497          	auipc	s1,0x1
 9c0:	65c48493          	addi	s1,s1,1628 # 2018 <freep>
  if (p == SBRK_ERROR)
 9c4:	5afd                	li	s5,-1
 9c6:	a83d                	j	a04 <malloc+0x92>
 9c8:	f426                	sd	s1,40(sp)
 9ca:	e852                	sd	s4,16(sp)
 9cc:	e456                	sd	s5,8(sp)
 9ce:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 9d0:	00001797          	auipc	a5,0x1
 9d4:	65078793          	addi	a5,a5,1616 # 2020 <base>
 9d8:	00001717          	auipc	a4,0x1
 9dc:	64f73023          	sd	a5,1600(a4) # 2018 <freep>
 9e0:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 9e2:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
 9e6:	b7d1                	j	9aa <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 9e8:	6398                	ld	a4,0(a5)
 9ea:	e118                	sd	a4,0(a0)
 9ec:	a899                	j	a42 <malloc+0xd0>
  hp->s.size = nu;
 9ee:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
 9f2:	0541                	addi	a0,a0,16
 9f4:	ef5ff0ef          	jal	8e8 <free>
  return freep;
 9f8:	6088                	ld	a0,0(s1)
      if ((p = morecore(nunits)) == 0)
 9fa:	c125                	beqz	a0,a5a <malloc+0xe8>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 9fc:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 9fe:	4798                	lw	a4,8(a5)
 a00:	03277163          	bgeu	a4,s2,a22 <malloc+0xb0>
    if (p == freep)
 a04:	6098                	ld	a4,0(s1)
 a06:	853e                	mv	a0,a5
 a08:	fef71ae3          	bne	a4,a5,9fc <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 a0c:	8552                	mv	a0,s4
 a0e:	a0fff0ef          	jal	41c <sbrk>
  if (p == SBRK_ERROR)
 a12:	fd551ee3          	bne	a0,s5,9ee <malloc+0x7c>
        return 0;
 a16:	4501                	li	a0,0
 a18:	74a2                	ld	s1,40(sp)
 a1a:	6a42                	ld	s4,16(sp)
 a1c:	6aa2                	ld	s5,8(sp)
 a1e:	6b02                	ld	s6,0(sp)
 a20:	a03d                	j	a4e <malloc+0xdc>
 a22:	74a2                	ld	s1,40(sp)
 a24:	6a42                	ld	s4,16(sp)
 a26:	6aa2                	ld	s5,8(sp)
 a28:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
 a2a:	fae90fe3          	beq	s2,a4,9e8 <malloc+0x76>
        p->s.size -= nunits;
 a2e:	4137073b          	subw	a4,a4,s3
 a32:	c798                	sw	a4,8(a5)
        p += p->s.size;
 a34:	02071693          	slli	a3,a4,0x20
 a38:	01c6d713          	srli	a4,a3,0x1c
 a3c:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 a3e:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 a42:	00001717          	auipc	a4,0x1
 a46:	5ca73b23          	sd	a0,1494(a4) # 2018 <freep>
      return (void *)(p + 1);
 a4a:	01078513          	addi	a0,a5,16
  }
}
 a4e:	70e2                	ld	ra,56(sp)
 a50:	7442                	ld	s0,48(sp)
 a52:	7902                	ld	s2,32(sp)
 a54:	69e2                	ld	s3,24(sp)
 a56:	6121                	addi	sp,sp,64
 a58:	8082                	ret
 a5a:	74a2                	ld	s1,40(sp)
 a5c:	6a42                	ld	s4,16(sp)
 a5e:	6aa2                	ld	s5,8(sp)
 a60:	6b02                	ld	s6,0(sp)
 a62:	b7f5                	j	a4e <malloc+0xdc>
