
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	0000a117          	auipc	sp,0xa
    80000004:	2c813103          	ld	sp,712(sp) # 8000a2c8 <_GLOBAL_OFFSET_TABLE_+0x8>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	042000ef          	jal	80000058 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e406                	sd	ra,8(sp)
    80000020:	e022                	sd	s0,0(sp)
    80000022:	0800                	addi	s0,sp,16
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    80000024:	30a027f3          	csrr	a5,0x30a
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | MENVCFG_STCE);
    80000028:	577d                	li	a4,-1
    8000002a:	177e                	slli	a4,a4,0x3f
    8000002c:	8fd9                	or	a5,a5,a4

static inline void
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    8000002e:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r"(x));
    80000032:	306027f3          	csrr	a5,mcounteren

  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000036:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r"(x));
    8000003a:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r"(x));
    8000003e:	c01027f3          	rdtime	a5

  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80000042:	000f4737          	lui	a4,0xf4
    80000046:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    8000004a:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    8000004c:	14d79073          	csrw	stimecmp,a5
}
    80000050:	60a2                	ld	ra,8(sp)
    80000052:	6402                	ld	s0,0(sp)
    80000054:	0141                	addi	sp,sp,16
    80000056:	8082                	ret

0000000080000058 <start>:
{
    80000058:	1141                	addi	sp,sp,-16
    8000005a:	e406                	sd	ra,8(sp)
    8000005c:	e022                	sd	s0,0(sp)
    8000005e:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r"(x));
    80000060:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000064:	7779                	lui	a4,0xffffe
    80000066:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdb1cf>
    8000006a:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    8000006c:	6705                	lui	a4,0x1
    8000006e:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80000072:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r"(x));
    80000074:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r"(x));
    80000078:	00001797          	auipc	a5,0x1
    8000007c:	de878793          	addi	a5,a5,-536 # 80000e60 <main>
    80000080:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r"(x));
    80000084:	4781                	li	a5,0
    80000086:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r"(x));
    8000008a:	67c1                	lui	a5,0x10
    8000008c:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000008e:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r"(x));
    80000092:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r"(x));
    80000096:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    8000009a:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r"(x));
    8000009e:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r"(x));
    800000a2:	57fd                	li	a5,-1
    800000a4:	83a9                	srli	a5,a5,0xa
    800000a6:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r"(x));
    800000aa:	47bd                	li	a5,15
    800000ac:	3a079073          	csrw	pmpcfg0,a5
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    800000b0:	30a027f3          	csrr	a5,0x30a
  w_menvcfg(r_menvcfg() | MENVCFG_ADUE);
    800000b4:	4705                	li	a4,1
    800000b6:	1776                	slli	a4,a4,0x3d
    800000b8:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    800000ba:	30a79073          	csrw	0x30a,a5
  timerinit();
    800000be:	f5fff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r"(x));
    800000c2:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c6:	2781                	sext.w	a5,a5
}

static inline void
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r"(x));
    800000c8:	823e                	mv	tp,a5
  asm volatile("mret");
    800000ca:	30200073          	mret
}
    800000ce:	60a2                	ld	ra,8(sp)
    800000d0:	6402                	ld	s0,0(sp)
    800000d2:	0141                	addi	sp,sp,16
    800000d4:	8082                	ret

00000000800000d6 <consolewrite>:
// user write() system calls to the console go here.
// uses sleep() and UART interrupts.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d6:	7119                	addi	sp,sp,-128
    800000d8:	fc86                	sd	ra,120(sp)
    800000da:	f8a2                	sd	s0,112(sp)
    800000dc:	f4a6                	sd	s1,104(sp)
    800000de:	0100                	addi	s0,sp,128
  char buf[32]; // move batches from user space to uart.
  int i = 0;

  while (i < n) {
    800000e0:	06c05b63          	blez	a2,80000156 <consolewrite+0x80>
    800000e4:	f0ca                	sd	s2,96(sp)
    800000e6:	ecce                	sd	s3,88(sp)
    800000e8:	e8d2                	sd	s4,80(sp)
    800000ea:	e4d6                	sd	s5,72(sp)
    800000ec:	e0da                	sd	s6,64(sp)
    800000ee:	fc5e                	sd	s7,56(sp)
    800000f0:	f862                	sd	s8,48(sp)
    800000f2:	f466                	sd	s9,40(sp)
    800000f4:	f06a                	sd	s10,32(sp)
    800000f6:	8b2a                	mv	s6,a0
    800000f8:	8bae                	mv	s7,a1
    800000fa:	8a32                	mv	s4,a2
  int i = 0;
    800000fc:	4481                	li	s1,0
    int nn = sizeof(buf);
    if (nn > n - i)
    800000fe:	02000c93          	li	s9,32
    80000102:	02000d13          	li	s10,32
      nn = n - i;
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000106:	f8040a93          	addi	s5,s0,-128
    8000010a:	5c7d                	li	s8,-1
    8000010c:	a025                	j	80000134 <consolewrite+0x5e>
    if (nn > n - i)
    8000010e:	0009099b          	sext.w	s3,s2
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000112:	86ce                	mv	a3,s3
    80000114:	01748633          	add	a2,s1,s7
    80000118:	85da                	mv	a1,s6
    8000011a:	8556                	mv	a0,s5
    8000011c:	212020ef          	jal	8000232e <either_copyin>
    80000120:	03850d63          	beq	a0,s8,8000015a <consolewrite+0x84>
      break;
    uartwrite(buf, nn);
    80000124:	85ce                	mv	a1,s3
    80000126:	8556                	mv	a0,s5
    80000128:	7d6000ef          	jal	800008fe <uartwrite>
    i += nn;
    8000012c:	009904bb          	addw	s1,s2,s1
  while (i < n) {
    80000130:	0144d963          	bge	s1,s4,80000142 <consolewrite+0x6c>
    if (nn > n - i)
    80000134:	409a07bb          	subw	a5,s4,s1
    80000138:	893e                	mv	s2,a5
    8000013a:	fcfcdae3          	bge	s9,a5,8000010e <consolewrite+0x38>
    8000013e:	896a                	mv	s2,s10
    80000140:	b7f9                	j	8000010e <consolewrite+0x38>
    80000142:	7906                	ld	s2,96(sp)
    80000144:	69e6                	ld	s3,88(sp)
    80000146:	6a46                	ld	s4,80(sp)
    80000148:	6aa6                	ld	s5,72(sp)
    8000014a:	6b06                	ld	s6,64(sp)
    8000014c:	7be2                	ld	s7,56(sp)
    8000014e:	7c42                	ld	s8,48(sp)
    80000150:	7ca2                	ld	s9,40(sp)
    80000152:	7d02                	ld	s10,32(sp)
    80000154:	a821                	j	8000016c <consolewrite+0x96>
  int i = 0;
    80000156:	4481                	li	s1,0
    80000158:	a811                	j	8000016c <consolewrite+0x96>
    8000015a:	7906                	ld	s2,96(sp)
    8000015c:	69e6                	ld	s3,88(sp)
    8000015e:	6a46                	ld	s4,80(sp)
    80000160:	6aa6                	ld	s5,72(sp)
    80000162:	6b06                	ld	s6,64(sp)
    80000164:	7be2                	ld	s7,56(sp)
    80000166:	7c42                	ld	s8,48(sp)
    80000168:	7ca2                	ld	s9,40(sp)
    8000016a:	7d02                	ld	s10,32(sp)
  }

  return i;
}
    8000016c:	8526                	mv	a0,s1
    8000016e:	70e6                	ld	ra,120(sp)
    80000170:	7446                	ld	s0,112(sp)
    80000172:	74a6                	ld	s1,104(sp)
    80000174:	6109                	addi	sp,sp,128
    80000176:	8082                	ret

0000000080000178 <consoleread>:
// user_dst indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000178:	711d                	addi	sp,sp,-96
    8000017a:	ec86                	sd	ra,88(sp)
    8000017c:	e8a2                	sd	s0,80(sp)
    8000017e:	e4a6                	sd	s1,72(sp)
    80000180:	e0ca                	sd	s2,64(sp)
    80000182:	fc4e                	sd	s3,56(sp)
    80000184:	f852                	sd	s4,48(sp)
    80000186:	f05a                	sd	s6,32(sp)
    80000188:	ec5e                	sd	s7,24(sp)
    8000018a:	1080                	addi	s0,sp,96
    8000018c:	8b2a                	mv	s6,a0
    8000018e:	8a2e                	mv	s4,a1
    80000190:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000192:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80000194:	00012517          	auipc	a0,0x12
    80000198:	17c50513          	addi	a0,a0,380 # 80012310 <cons>
    8000019c:	25d000ef          	jal	80000bf8 <acquire>
  while (n > 0) {
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while (cons.r == cons.w) {
    800001a0:	00012497          	auipc	s1,0x12
    800001a4:	17048493          	addi	s1,s1,368 # 80012310 <cons>
      if (killed(myproc())) {
        release(&cons.lock);
        return -1;
      }
      sleep_prepare(&cons.r);
    800001a8:	00012917          	auipc	s2,0x12
    800001ac:	20090913          	addi	s2,s2,512 # 800123a8 <cons+0x98>
  while (n > 0) {
    800001b0:	0d305263          	blez	s3,80000274 <consoleread+0xfc>
    while (cons.r == cons.w) {
    800001b4:	0984a783          	lw	a5,152(s1)
    800001b8:	09c4a703          	lw	a4,156(s1)
    800001bc:	0af71763          	bne	a4,a5,8000026a <consoleread+0xf2>
      if (killed(myproc())) {
    800001c0:	722010ef          	jal	800018e2 <myproc>
    800001c4:	7ed010ef          	jal	800021b0 <killed>
    800001c8:	e925                	bnez	a0,80000238 <consoleread+0xc0>
      sleep_prepare(&cons.r);
    800001ca:	854a                	mv	a0,s2
    800001cc:	51f010ef          	jal	80001eea <sleep_prepare>
      release(&cons.lock);
    800001d0:	8526                	mv	a0,s1
    800001d2:	2ab000ef          	jal	80000c7c <release>
      sleep();
    800001d6:	551010ef          	jal	80001f26 <sleep>
      acquire(&cons.lock);
    800001da:	8526                	mv	a0,s1
    800001dc:	21d000ef          	jal	80000bf8 <acquire>
    while (cons.r == cons.w) {
    800001e0:	0984a783          	lw	a5,152(s1)
    800001e4:	09c4a703          	lw	a4,156(s1)
    800001e8:	fcf70ce3          	beq	a4,a5,800001c0 <consoleread+0x48>
    800001ec:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001ee:	00012717          	auipc	a4,0x12
    800001f2:	12270713          	addi	a4,a4,290 # 80012310 <cons>
    800001f6:	0017869b          	addiw	a3,a5,1
    800001fa:	08d72c23          	sw	a3,152(a4)
    800001fe:	07f7f693          	andi	a3,a5,127
    80000202:	9736                	add	a4,a4,a3
    80000204:	01874703          	lbu	a4,24(a4)
    80000208:	00070a9b          	sext.w	s5,a4

    if (c == C('D')) { // end-of-file
    8000020c:	4691                	li	a3,4
    8000020e:	04da8663          	beq	s5,a3,8000025a <consoleread+0xe2>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80000212:	fae407a3          	sb	a4,-81(s0)
    if (either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000216:	4685                	li	a3,1
    80000218:	faf40613          	addi	a2,s0,-81
    8000021c:	85d2                	mv	a1,s4
    8000021e:	855a                	mv	a0,s6
    80000220:	0c2020ef          	jal	800022e2 <either_copyout>
    80000224:	57fd                	li	a5,-1
    80000226:	04f50663          	beq	a0,a5,80000272 <consoleread+0xfa>
      break;

    dst++;
    8000022a:	0a05                	addi	s4,s4,1
    --n;
    8000022c:	39fd                	addiw	s3,s3,-1

    if (c == '\n') {
    8000022e:	47a9                	li	a5,10
    80000230:	04fa8b63          	beq	s5,a5,80000286 <consoleread+0x10e>
    80000234:	7aa2                	ld	s5,40(sp)
    80000236:	bfad                	j	800001b0 <consoleread+0x38>
        release(&cons.lock);
    80000238:	00012517          	auipc	a0,0x12
    8000023c:	0d850513          	addi	a0,a0,216 # 80012310 <cons>
    80000240:	23d000ef          	jal	80000c7c <release>
        return -1;
    80000244:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000246:	60e6                	ld	ra,88(sp)
    80000248:	6446                	ld	s0,80(sp)
    8000024a:	64a6                	ld	s1,72(sp)
    8000024c:	6906                	ld	s2,64(sp)
    8000024e:	79e2                	ld	s3,56(sp)
    80000250:	7a42                	ld	s4,48(sp)
    80000252:	7b02                	ld	s6,32(sp)
    80000254:	6be2                	ld	s7,24(sp)
    80000256:	6125                	addi	sp,sp,96
    80000258:	8082                	ret
      if (n < target) {
    8000025a:	0179fa63          	bgeu	s3,s7,8000026e <consoleread+0xf6>
        cons.r--;
    8000025e:	00012717          	auipc	a4,0x12
    80000262:	14f72523          	sw	a5,330(a4) # 800123a8 <cons+0x98>
    80000266:	7aa2                	ld	s5,40(sp)
    80000268:	a031                	j	80000274 <consoleread+0xfc>
    8000026a:	f456                	sd	s5,40(sp)
    8000026c:	b749                	j	800001ee <consoleread+0x76>
    8000026e:	7aa2                	ld	s5,40(sp)
    80000270:	a011                	j	80000274 <consoleread+0xfc>
    80000272:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80000274:	00012517          	auipc	a0,0x12
    80000278:	09c50513          	addi	a0,a0,156 # 80012310 <cons>
    8000027c:	201000ef          	jal	80000c7c <release>
  return target - n;
    80000280:	413b853b          	subw	a0,s7,s3
    80000284:	b7c9                	j	80000246 <consoleread+0xce>
    80000286:	7aa2                	ld	s5,40(sp)
    80000288:	b7f5                	j	80000274 <consoleread+0xfc>

000000008000028a <consputc>:
{
    8000028a:	1141                	addi	sp,sp,-16
    8000028c:	e406                	sd	ra,8(sp)
    8000028e:	e022                	sd	s0,0(sp)
    80000290:	0800                	addi	s0,sp,16
  if (c == BACKSPACE) {
    80000292:	10000793          	li	a5,256
    80000296:	00f50863          	beq	a0,a5,800002a6 <consputc+0x1c>
    uartputc_sync(c);
    8000029a:	6ea000ef          	jal	80000984 <uartputc_sync>
}
    8000029e:	60a2                	ld	ra,8(sp)
    800002a0:	6402                	ld	s0,0(sp)
    800002a2:	0141                	addi	sp,sp,16
    800002a4:	8082                	ret
    uartputc_sync('\b');
    800002a6:	4521                	li	a0,8
    800002a8:	6dc000ef          	jal	80000984 <uartputc_sync>
    uartputc_sync(' ');
    800002ac:	02000513          	li	a0,32
    800002b0:	6d4000ef          	jal	80000984 <uartputc_sync>
    uartputc_sync('\b');
    800002b4:	4521                	li	a0,8
    800002b6:	6ce000ef          	jal	80000984 <uartputc_sync>
    800002ba:	b7d5                	j	8000029e <consputc+0x14>

00000000800002bc <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002bc:	1101                	addi	sp,sp,-32
    800002be:	ec06                	sd	ra,24(sp)
    800002c0:	e822                	sd	s0,16(sp)
    800002c2:	e426                	sd	s1,8(sp)
    800002c4:	1000                	addi	s0,sp,32
    800002c6:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002c8:	00012517          	auipc	a0,0x12
    800002cc:	04850513          	addi	a0,a0,72 # 80012310 <cons>
    800002d0:	129000ef          	jal	80000bf8 <acquire>

  switch (c) {
    800002d4:	47d5                	li	a5,21
    800002d6:	0af48163          	beq	s1,a5,80000378 <consoleintr+0xbc>
    800002da:	0297c563          	blt	a5,s1,80000304 <consoleintr+0x48>
    800002de:	47a1                	li	a5,8
    800002e0:	0ef48663          	beq	s1,a5,800003cc <consoleintr+0x110>
    800002e4:	47c1                	li	a5,16
    800002e6:	10f49763          	bne	s1,a5,800003f4 <consoleintr+0x138>
  case C('P'): // Print process list.
    procdump();
    800002ea:	090020ef          	jal	8000237a <procdump>
      }
    }
    break;
  }

  release(&cons.lock);
    800002ee:	00012517          	auipc	a0,0x12
    800002f2:	02250513          	addi	a0,a0,34 # 80012310 <cons>
    800002f6:	187000ef          	jal	80000c7c <release>
}
    800002fa:	60e2                	ld	ra,24(sp)
    800002fc:	6442                	ld	s0,16(sp)
    800002fe:	64a2                	ld	s1,8(sp)
    80000300:	6105                	addi	sp,sp,32
    80000302:	8082                	ret
  switch (c) {
    80000304:	07f00793          	li	a5,127
    80000308:	0cf48263          	beq	s1,a5,800003cc <consoleintr+0x110>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    8000030c:	00012717          	auipc	a4,0x12
    80000310:	00470713          	addi	a4,a4,4 # 80012310 <cons>
    80000314:	0a072783          	lw	a5,160(a4)
    80000318:	09872703          	lw	a4,152(a4)
    8000031c:	9f99                	subw	a5,a5,a4
    8000031e:	07f00713          	li	a4,127
    80000322:	fcf766e3          	bltu	a4,a5,800002ee <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000326:	47b5                	li	a5,13
    80000328:	0cf48963          	beq	s1,a5,800003fa <consoleintr+0x13e>
      consputc(c);
    8000032c:	8526                	mv	a0,s1
    8000032e:	f5dff0ef          	jal	8000028a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000332:	00012717          	auipc	a4,0x12
    80000336:	fde70713          	addi	a4,a4,-34 # 80012310 <cons>
    8000033a:	0a072683          	lw	a3,160(a4)
    8000033e:	0016879b          	addiw	a5,a3,1
    80000342:	863e                	mv	a2,a5
    80000344:	0af72023          	sw	a5,160(a4)
    80000348:	07f6f693          	andi	a3,a3,127
    8000034c:	9736                	add	a4,a4,a3
    8000034e:	00970c23          	sb	s1,24(a4)
      if (c == '\n' || c == C('D') || cons.e - cons.r == INPUT_BUF_SIZE) {
    80000352:	ff648713          	addi	a4,s1,-10
    80000356:	00173713          	seqz	a4,a4
    8000035a:	14f1                	addi	s1,s1,-4
    8000035c:	0014b493          	seqz	s1,s1
    80000360:	8f45                	or	a4,a4,s1
    80000362:	e361                	bnez	a4,80000422 <consoleintr+0x166>
    80000364:	00012717          	auipc	a4,0x12
    80000368:	04472703          	lw	a4,68(a4) # 800123a8 <cons+0x98>
    8000036c:	9f99                	subw	a5,a5,a4
    8000036e:	08000713          	li	a4,128
    80000372:	f6e79ee3          	bne	a5,a4,800002ee <consoleintr+0x32>
    80000376:	a075                	j	80000422 <consoleintr+0x166>
    80000378:	e04a                	sd	s2,0(sp)
    while (cons.e != cons.w &&
    8000037a:	00012717          	auipc	a4,0x12
    8000037e:	f9670713          	addi	a4,a4,-106 # 80012310 <cons>
    80000382:	0a072783          	lw	a5,160(a4)
    80000386:	09c72703          	lw	a4,156(a4)
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    8000038a:	00012497          	auipc	s1,0x12
    8000038e:	f8648493          	addi	s1,s1,-122 # 80012310 <cons>
    while (cons.e != cons.w &&
    80000392:	4929                	li	s2,10
    80000394:	02f70863          	beq	a4,a5,800003c4 <consoleintr+0x108>
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000398:	37fd                	addiw	a5,a5,-1
    8000039a:	07f7f713          	andi	a4,a5,127
    8000039e:	9726                	add	a4,a4,s1
    while (cons.e != cons.w &&
    800003a0:	01874703          	lbu	a4,24(a4)
    800003a4:	03270263          	beq	a4,s2,800003c8 <consoleintr+0x10c>
      cons.e--;
    800003a8:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    800003ac:	10000513          	li	a0,256
    800003b0:	edbff0ef          	jal	8000028a <consputc>
    while (cons.e != cons.w &&
    800003b4:	0a04a783          	lw	a5,160(s1)
    800003b8:	09c4a703          	lw	a4,156(s1)
    800003bc:	fcf71ee3          	bne	a4,a5,80000398 <consoleintr+0xdc>
    800003c0:	6902                	ld	s2,0(sp)
    800003c2:	b735                	j	800002ee <consoleintr+0x32>
    800003c4:	6902                	ld	s2,0(sp)
    800003c6:	b725                	j	800002ee <consoleintr+0x32>
    800003c8:	6902                	ld	s2,0(sp)
    800003ca:	b715                	j	800002ee <consoleintr+0x32>
    if (cons.e != cons.w) {
    800003cc:	00012717          	auipc	a4,0x12
    800003d0:	f4470713          	addi	a4,a4,-188 # 80012310 <cons>
    800003d4:	0a072783          	lw	a5,160(a4)
    800003d8:	09c72703          	lw	a4,156(a4)
    800003dc:	f0f709e3          	beq	a4,a5,800002ee <consoleintr+0x32>
      cons.e--;
    800003e0:	37fd                	addiw	a5,a5,-1
    800003e2:	00012717          	auipc	a4,0x12
    800003e6:	fcf72723          	sw	a5,-50(a4) # 800123b0 <cons+0xa0>
      consputc(BACKSPACE);
    800003ea:	10000513          	li	a0,256
    800003ee:	e9dff0ef          	jal	8000028a <consputc>
    800003f2:	bdf5                	j	800002ee <consoleintr+0x32>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    800003f4:	ee048de3          	beqz	s1,800002ee <consoleintr+0x32>
    800003f8:	bf11                	j	8000030c <consoleintr+0x50>
      consputc(c);
    800003fa:	4529                	li	a0,10
    800003fc:	e8fff0ef          	jal	8000028a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000400:	00012797          	auipc	a5,0x12
    80000404:	f1078793          	addi	a5,a5,-240 # 80012310 <cons>
    80000408:	0a07a703          	lw	a4,160(a5)
    8000040c:	0017069b          	addiw	a3,a4,1
    80000410:	8636                	mv	a2,a3
    80000412:	0ad7a023          	sw	a3,160(a5)
    80000416:	07f77713          	andi	a4,a4,127
    8000041a:	97ba                	add	a5,a5,a4
    8000041c:	4729                	li	a4,10
    8000041e:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    80000422:	00012797          	auipc	a5,0x12
    80000426:	f8c7a523          	sw	a2,-118(a5) # 800123ac <cons+0x9c>
        wakeup(&cons.r);
    8000042a:	00012517          	auipc	a0,0x12
    8000042e:	f7e50513          	addi	a0,a0,-130 # 800123a8 <cons+0x98>
    80000432:	325010ef          	jal	80001f56 <wakeup>
    80000436:	bd65                	j	800002ee <consoleintr+0x32>

0000000080000438 <consoleinit>:

void
consoleinit(void)
{
    80000438:	1141                	addi	sp,sp,-16
    8000043a:	e406                	sd	ra,8(sp)
    8000043c:	e022                	sd	s0,0(sp)
    8000043e:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000440:	00007597          	auipc	a1,0x7
    80000444:	bc058593          	addi	a1,a1,-1088 # 80007000 <etext>
    80000448:	00012517          	auipc	a0,0x12
    8000044c:	ec850513          	addi	a0,a0,-312 # 80012310 <cons>
    80000450:	728000ef          	jal	80000b78 <initlock>

  uartinit();
    80000454:	454000ef          	jal	800008a8 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000458:	00022797          	auipc	a5,0x22
    8000045c:	04078793          	addi	a5,a5,64 # 80022498 <devsw>
    80000460:	00000717          	auipc	a4,0x0
    80000464:	d1870713          	addi	a4,a4,-744 # 80000178 <consoleread>
    80000468:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    8000046a:	00000717          	auipc	a4,0x0
    8000046e:	c6c70713          	addi	a4,a4,-916 # 800000d6 <consolewrite>
    80000472:	ef98                	sd	a4,24(a5)
}
    80000474:	60a2                	ld	ra,8(sp)
    80000476:	6402                	ld	s0,0(sp)
    80000478:	0141                	addi	sp,sp,16
    8000047a:	8082                	ret

000000008000047c <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    8000047c:	7139                	addi	sp,sp,-64
    8000047e:	fc06                	sd	ra,56(sp)
    80000480:	f822                	sd	s0,48(sp)
    80000482:	f04a                	sd	s2,32(sp)
    80000484:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if (sign && (sign = (xx < 0)))
    80000486:	c219                	beqz	a2,8000048c <printint+0x10>
    80000488:	08054063          	bltz	a0,80000508 <printint+0x8c>
    x = -xx;
  else
    x = xx;
    8000048c:	4301                	li	t1,0

  i = 0;
    8000048e:	fc840913          	addi	s2,s0,-56
    x = xx;
    80000492:	86ca                	mv	a3,s2
  i = 0;
    80000494:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    80000496:	00007817          	auipc	a6,0x7
    8000049a:	29a80813          	addi	a6,a6,666 # 80007730 <digits>
    8000049e:	88ba                	mv	a7,a4
    800004a0:	0017061b          	addiw	a2,a4,1
    800004a4:	8732                	mv	a4,a2
    800004a6:	02b577b3          	remu	a5,a0,a1
    800004aa:	97c2                	add	a5,a5,a6
    800004ac:	0007c783          	lbu	a5,0(a5)
    800004b0:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
    800004b4:	87aa                	mv	a5,a0
    800004b6:	02b55533          	divu	a0,a0,a1
    800004ba:	0685                	addi	a3,a3,1
    800004bc:	feb7f1e3          	bgeu	a5,a1,8000049e <printint+0x22>

  if (sign)
    800004c0:	00030b63          	beqz	t1,800004d6 <printint+0x5a>
    buf[i++] = '-';
    800004c4:	fe040793          	addi	a5,s0,-32
    800004c8:	963e                	add	a2,a2,a5
    800004ca:	02d00793          	li	a5,45
    800004ce:	fef60423          	sb	a5,-24(a2)
    800004d2:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
    800004d6:	02e05463          	blez	a4,800004fe <printint+0x82>
    800004da:	f426                	sd	s1,40(sp)
    800004dc:	377d                	addiw	a4,a4,-1
    800004de:	00e904b3          	add	s1,s2,a4
    800004e2:	197d                	addi	s2,s2,-1
    800004e4:	993a                	add	s2,s2,a4
    800004e6:	1702                	slli	a4,a4,0x20
    800004e8:	9301                	srli	a4,a4,0x20
    800004ea:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    800004ee:	0004c503          	lbu	a0,0(s1)
    800004f2:	d99ff0ef          	jal	8000028a <consputc>
  while (--i >= 0)
    800004f6:	14fd                	addi	s1,s1,-1
    800004f8:	ff249be3          	bne	s1,s2,800004ee <printint+0x72>
    800004fc:	74a2                	ld	s1,40(sp)
}
    800004fe:	70e2                	ld	ra,56(sp)
    80000500:	7442                	ld	s0,48(sp)
    80000502:	7902                	ld	s2,32(sp)
    80000504:	6121                	addi	sp,sp,64
    80000506:	8082                	ret
    x = -xx;
    80000508:	40a00533          	neg	a0,a0
  if (sign && (sign = (xx < 0)))
    8000050c:	4305                	li	t1,1
    x = -xx;
    8000050e:	b741                	j	8000048e <printint+0x12>

0000000080000510 <printk>:
}

// Print to the console.
int
printk(char *fmt, ...)
{
    80000510:	7131                	addi	sp,sp,-192
    80000512:	fc86                	sd	ra,120(sp)
    80000514:	f8a2                	sd	s0,112(sp)
    80000516:	f4a6                	sd	s1,104(sp)
    80000518:	0100                	addi	s0,sp,128
    8000051a:	84aa                	mv	s1,a0
    8000051c:	e40c                	sd	a1,8(s0)
    8000051e:	e810                	sd	a2,16(s0)
    80000520:	ec14                	sd	a3,24(s0)
    80000522:	f018                	sd	a4,32(s0)
    80000524:	f41c                	sd	a5,40(s0)
    80000526:	03043823          	sd	a6,48(s0)
    8000052a:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if (panicking == 0)
    8000052e:	0000a797          	auipc	a5,0xa
    80000532:	db67a783          	lw	a5,-586(a5) # 8000a2e4 <panicking>
    80000536:	cf9d                	beqz	a5,80000574 <printk+0x64>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000538:	00840793          	addi	a5,s0,8
    8000053c:	f8f43423          	sd	a5,-120(s0)
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    80000540:	0004c503          	lbu	a0,0(s1)
    80000544:	22050363          	beqz	a0,8000076a <printk+0x25a>
    80000548:	f0ca                	sd	s2,96(sp)
    8000054a:	ecce                	sd	s3,88(sp)
    8000054c:	e8d2                	sd	s4,80(sp)
    8000054e:	e4d6                	sd	s5,72(sp)
    80000550:	e0da                	sd	s6,64(sp)
    80000552:	fc5e                	sd	s7,56(sp)
    80000554:	f862                	sd	s8,48(sp)
    80000556:	f06a                	sd	s10,32(sp)
    80000558:	ec6e                	sd	s11,24(sp)
    8000055a:	4a01                	li	s4,0
    if (cx != '%') {
    8000055c:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if (c0 == 'u') {
    80000560:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if (c0 == 'x') {
    80000564:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if (c0 == 'p') {
    80000568:	07000d93          	li	s11,112
      printint(va_arg(ap, uint64), 10, 0);
    8000056c:	4b29                	li	s6,10
    if (c0 == 'd') {
    8000056e:	06400b93          	li	s7,100
    80000572:	a015                	j	80000596 <printk+0x86>
    acquire(&pr.lock);
    80000574:	00012517          	auipc	a0,0x12
    80000578:	e4450513          	addi	a0,a0,-444 # 800123b8 <pr>
    8000057c:	67c000ef          	jal	80000bf8 <acquire>
    80000580:	bf65                	j	80000538 <printk+0x28>
      consputc(cx);
    80000582:	d09ff0ef          	jal	8000028a <consputc>
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    80000586:	001a079b          	addiw	a5,s4,1
    8000058a:	8a3e                	mv	s4,a5
    8000058c:	97a6                	add	a5,a5,s1
    8000058e:	0007c503          	lbu	a0,0(a5)
    80000592:	1c050363          	beqz	a0,80000758 <printk+0x248>
    if (cx != '%') {
    80000596:	ff3516e3          	bne	a0,s3,80000582 <printk+0x72>
    i++;
    8000059a:	001a091b          	addiw	s2,s4,1
    c0 = fmt[i + 0] & 0xff;
    8000059e:	012487b3          	add	a5,s1,s2
    800005a2:	0007ca83          	lbu	s5,0(a5)
    if (c0)
    800005a6:	200a8763          	beqz	s5,800007b4 <printk+0x2a4>
      c1 = fmt[i + 1] & 0xff;
    800005aa:	0017c703          	lbu	a4,1(a5)
    if (c1)
    800005ae:	1e070a63          	beqz	a4,800007a2 <printk+0x292>
    if (c0 == 'd') {
    800005b2:	037a8963          	beq	s5,s7,800005e4 <printk+0xd4>
    } else if (c0 == 'l' && c1 == 'd') {
    800005b6:	f94a8793          	addi	a5,s5,-108
    800005ba:	0017b793          	seqz	a5,a5
    800005be:	f9c70693          	addi	a3,a4,-100
    800005c2:	0016b693          	seqz	a3,a3
    800005c6:	8efd                	and	a3,a3,a5
    800005c8:	ca9d                	beqz	a3,800005fe <printk+0xee>
      printint(va_arg(ap, uint64), 10, 1);
    800005ca:	f8843783          	ld	a5,-120(s0)
    800005ce:	00878713          	addi	a4,a5,8
    800005d2:	f8e43423          	sd	a4,-120(s0)
    800005d6:	4605                	li	a2,1
    800005d8:	85da                	mv	a1,s6
    800005da:	6388                	ld	a0,0(a5)
    800005dc:	ea1ff0ef          	jal	8000047c <printint>
      i += 1;
    800005e0:	2a09                	addiw	s4,s4,2
    800005e2:	b755                	j	80000586 <printk+0x76>
      printint(va_arg(ap, int), 10, 1);
    800005e4:	f8843783          	ld	a5,-120(s0)
    800005e8:	00878713          	addi	a4,a5,8
    800005ec:	f8e43423          	sd	a4,-120(s0)
    800005f0:	4605                	li	a2,1
    800005f2:	85da                	mv	a1,s6
    800005f4:	4388                	lw	a0,0(a5)
    800005f6:	e87ff0ef          	jal	8000047c <printint>
    i++;
    800005fa:	8a4a                	mv	s4,s2
    800005fc:	b769                	j	80000586 <printk+0x76>
      c2 = fmt[i + 2] & 0xff;
    800005fe:	012486b3          	add	a3,s1,s2
    80000602:	863a                	mv	a2,a4
    80000604:	0026c703          	lbu	a4,2(a3)
    80000608:	aa65                	j	800007c0 <printk+0x2b0>
      printint(va_arg(ap, uint64), 10, 1);
    8000060a:	f8843783          	ld	a5,-120(s0)
    8000060e:	00878713          	addi	a4,a5,8
    80000612:	f8e43423          	sd	a4,-120(s0)
    80000616:	4605                	li	a2,1
    80000618:	45a9                	li	a1,10
    8000061a:	6388                	ld	a0,0(a5)
    8000061c:	e61ff0ef          	jal	8000047c <printint>
      i += 2;
    80000620:	2a0d                	addiw	s4,s4,3
    80000622:	b795                	j	80000586 <printk+0x76>
      printint(va_arg(ap, uint32), 10, 0);
    80000624:	f8843783          	ld	a5,-120(s0)
    80000628:	00878713          	addi	a4,a5,8
    8000062c:	f8e43423          	sd	a4,-120(s0)
    80000630:	4601                	li	a2,0
    80000632:	85da                	mv	a1,s6
    80000634:	0007e503          	lwu	a0,0(a5)
    80000638:	e45ff0ef          	jal	8000047c <printint>
    8000063c:	bf7d                	j	800005fa <printk+0xea>
      printint(va_arg(ap, uint64), 10, 0);
    8000063e:	f8843783          	ld	a5,-120(s0)
    80000642:	00878713          	addi	a4,a5,8
    80000646:	f8e43423          	sd	a4,-120(s0)
    8000064a:	4601                	li	a2,0
    8000064c:	85da                	mv	a1,s6
    8000064e:	6388                	ld	a0,0(a5)
    80000650:	e2dff0ef          	jal	8000047c <printint>
      i += 1;
    80000654:	2a09                	addiw	s4,s4,2
    80000656:	bf05                	j	80000586 <printk+0x76>
      printint(va_arg(ap, uint64), 10, 0);
    80000658:	f8843783          	ld	a5,-120(s0)
    8000065c:	00878713          	addi	a4,a5,8
    80000660:	f8e43423          	sd	a4,-120(s0)
    80000664:	4601                	li	a2,0
    80000666:	45a9                	li	a1,10
    80000668:	6388                	ld	a0,0(a5)
    8000066a:	e13ff0ef          	jal	8000047c <printint>
      i += 2;
    8000066e:	2a0d                	addiw	s4,s4,3
    80000670:	bf19                	j	80000586 <printk+0x76>
      printint(va_arg(ap, uint32), 16, 0);
    80000672:	f8843783          	ld	a5,-120(s0)
    80000676:	00878713          	addi	a4,a5,8
    8000067a:	f8e43423          	sd	a4,-120(s0)
    8000067e:	4601                	li	a2,0
    80000680:	45c1                	li	a1,16
    80000682:	0007e503          	lwu	a0,0(a5)
    80000686:	df7ff0ef          	jal	8000047c <printint>
    8000068a:	bf85                	j	800005fa <printk+0xea>
      printint(va_arg(ap, uint64), 16, 0);
    8000068c:	f8843783          	ld	a5,-120(s0)
    80000690:	00878713          	addi	a4,a5,8
    80000694:	f8e43423          	sd	a4,-120(s0)
    80000698:	4601                	li	a2,0
    8000069a:	45c1                	li	a1,16
    8000069c:	6388                	ld	a0,0(a5)
    8000069e:	ddfff0ef          	jal	8000047c <printint>
      i += 1;
    800006a2:	2a09                	addiw	s4,s4,2
    800006a4:	b5cd                	j	80000586 <printk+0x76>
      printint(va_arg(ap, uint64), 16, 0);
    800006a6:	f8843783          	ld	a5,-120(s0)
    800006aa:	00878713          	addi	a4,a5,8
    800006ae:	f8e43423          	sd	a4,-120(s0)
    800006b2:	45c1                	li	a1,16
    800006b4:	6388                	ld	a0,0(a5)
    800006b6:	dc7ff0ef          	jal	8000047c <printint>
      i += 2;
    800006ba:	2a0d                	addiw	s4,s4,3
    800006bc:	b5e9                	j	80000586 <printk+0x76>
    800006be:	f466                	sd	s9,40(sp)
      printptr(va_arg(ap, uint64));
    800006c0:	f8843783          	ld	a5,-120(s0)
    800006c4:	00878713          	addi	a4,a5,8
    800006c8:	f8e43423          	sd	a4,-120(s0)
    800006cc:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    800006d0:	03000513          	li	a0,48
    800006d4:	bb7ff0ef          	jal	8000028a <consputc>
  consputc('x');
    800006d8:	07800513          	li	a0,120
    800006dc:	bafff0ef          	jal	8000028a <consputc>
    800006e0:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006e2:	00007c97          	auipc	s9,0x7
    800006e6:	04ec8c93          	addi	s9,s9,78 # 80007730 <digits>
    800006ea:	03cad793          	srli	a5,s5,0x3c
    800006ee:	97e6                	add	a5,a5,s9
    800006f0:	0007c503          	lbu	a0,0(a5)
    800006f4:	b97ff0ef          	jal	8000028a <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006f8:	0a92                	slli	s5,s5,0x4
    800006fa:	3a7d                	addiw	s4,s4,-1
    800006fc:	fe0a17e3          	bnez	s4,800006ea <printk+0x1da>
    80000700:	7ca2                	ld	s9,40(sp)
    80000702:	bde5                	j	800005fa <printk+0xea>
    } else if (c0 == 'c') {
      consputc(va_arg(ap, uint));
    80000704:	f8843783          	ld	a5,-120(s0)
    80000708:	00878713          	addi	a4,a5,8
    8000070c:	f8e43423          	sd	a4,-120(s0)
    80000710:	4388                	lw	a0,0(a5)
    80000712:	b79ff0ef          	jal	8000028a <consputc>
    80000716:	b5d5                	j	800005fa <printk+0xea>
    } else if (c0 == 's') {
      if ((s = va_arg(ap, char *)) == 0)
    80000718:	f8843783          	ld	a5,-120(s0)
    8000071c:	00878713          	addi	a4,a5,8
    80000720:	f8e43423          	sd	a4,-120(s0)
    80000724:	0007ba03          	ld	s4,0(a5)
    80000728:	000a0d63          	beqz	s4,80000742 <printk+0x232>
        s = "(null)";
      for (; *s; s++)
    8000072c:	000a4503          	lbu	a0,0(s4)
    80000730:	ec0505e3          	beqz	a0,800005fa <printk+0xea>
        consputc(*s);
    80000734:	b57ff0ef          	jal	8000028a <consputc>
      for (; *s; s++)
    80000738:	0a05                	addi	s4,s4,1
    8000073a:	000a4503          	lbu	a0,0(s4)
    8000073e:	f97d                	bnez	a0,80000734 <printk+0x224>
    80000740:	bd6d                	j	800005fa <printk+0xea>
        s = "(null)";
    80000742:	00007a17          	auipc	s4,0x7
    80000746:	8c6a0a13          	addi	s4,s4,-1850 # 80007008 <etext+0x8>
      for (; *s; s++)
    8000074a:	02800513          	li	a0,40
    8000074e:	b7dd                	j	80000734 <printk+0x224>
    } else if (c0 == '%') {
      consputc('%');
    80000750:	8556                	mv	a0,s5
    80000752:	b39ff0ef          	jal	8000028a <consputc>
    80000756:	b555                	j	800005fa <printk+0xea>
    80000758:	7906                	ld	s2,96(sp)
    8000075a:	69e6                	ld	s3,88(sp)
    8000075c:	6a46                	ld	s4,80(sp)
    8000075e:	6aa6                	ld	s5,72(sp)
    80000760:	6b06                	ld	s6,64(sp)
    80000762:	7be2                	ld	s7,56(sp)
    80000764:	7c42                	ld	s8,48(sp)
    80000766:	7d02                	ld	s10,32(sp)
    80000768:	6de2                	ld	s11,24(sp)
      consputc(c0);
    }
  }
  va_end(ap);

  if (panicking == 0)
    8000076a:	0000a797          	auipc	a5,0xa
    8000076e:	b7a7a783          	lw	a5,-1158(a5) # 8000a2e4 <panicking>
    80000772:	c38d                	beqz	a5,80000794 <printk+0x284>
    release(&pr.lock);

  return 0;
}
    80000774:	4501                	li	a0,0
    80000776:	70e6                	ld	ra,120(sp)
    80000778:	7446                	ld	s0,112(sp)
    8000077a:	74a6                	ld	s1,104(sp)
    8000077c:	6129                	addi	sp,sp,192
    8000077e:	8082                	ret
    80000780:	7906                	ld	s2,96(sp)
    80000782:	69e6                	ld	s3,88(sp)
    80000784:	6a46                	ld	s4,80(sp)
    80000786:	6aa6                	ld	s5,72(sp)
    80000788:	6b06                	ld	s6,64(sp)
    8000078a:	7be2                	ld	s7,56(sp)
    8000078c:	7c42                	ld	s8,48(sp)
    8000078e:	7d02                	ld	s10,32(sp)
    80000790:	6de2                	ld	s11,24(sp)
    80000792:	bfe1                	j	8000076a <printk+0x25a>
    release(&pr.lock);
    80000794:	00012517          	auipc	a0,0x12
    80000798:	c2450513          	addi	a0,a0,-988 # 800123b8 <pr>
    8000079c:	4e0000ef          	jal	80000c7c <release>
  return 0;
    800007a0:	bfd1                	j	80000774 <printk+0x264>
    if (c0 == 'd') {
    800007a2:	e57a81e3          	beq	s5,s7,800005e4 <printk+0xd4>
    } else if (c0 == 'l' && c1 == 'd') {
    800007a6:	f94a8793          	addi	a5,s5,-108
    800007aa:	0017b793          	seqz	a5,a5
    800007ae:	863a                	mv	a2,a4
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    800007b0:	4681                	li	a3,0
    800007b2:	a01d                	j	800007d8 <printk+0x2c8>
    } else if (c0 == 'l' && c1 == 'd') {
    800007b4:	f94a8793          	addi	a5,s5,-108
    800007b8:	0017b793          	seqz	a5,a5
    c1 = c2 = 0;
    800007bc:	8656                	mv	a2,s5
    800007be:	8756                	mv	a4,s5
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    800007c0:	f9460693          	addi	a3,a2,-108
    800007c4:	0016b693          	seqz	a3,a3
    800007c8:	8efd                	and	a3,a3,a5
    800007ca:	f9c70593          	addi	a1,a4,-100
    800007ce:	0015b593          	seqz	a1,a1
    800007d2:	8df5                	and	a1,a1,a3
    800007d4:	e2059be3          	bnez	a1,8000060a <printk+0xfa>
    } else if (c0 == 'u') {
    800007d8:	e58a86e3          	beq	s5,s8,80000624 <printk+0x114>
    } else if (c0 == 'l' && c1 == 'u') {
    800007dc:	f8b60593          	addi	a1,a2,-117
    800007e0:	0015b593          	seqz	a1,a1
    800007e4:	8dfd                	and	a1,a1,a5
    800007e6:	e4059ce3          	bnez	a1,8000063e <printk+0x12e>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
    800007ea:	f8b70593          	addi	a1,a4,-117
    800007ee:	0015b593          	seqz	a1,a1
    800007f2:	8df5                	and	a1,a1,a3
    800007f4:	e60592e3          	bnez	a1,80000658 <printk+0x148>
    } else if (c0 == 'x') {
    800007f8:	e7aa8de3          	beq	s5,s10,80000672 <printk+0x162>
    } else if (c0 == 'l' && c1 == 'x') {
    800007fc:	f8860613          	addi	a2,a2,-120
    80000800:	00163613          	seqz	a2,a2
    80000804:	8e7d                	and	a2,a2,a5
    80000806:	e80613e3          	bnez	a2,8000068c <printk+0x17c>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
    8000080a:	f8870713          	addi	a4,a4,-120
    8000080e:	00173713          	seqz	a4,a4
    80000812:	8f75                	and	a4,a4,a3
    80000814:	e80719e3          	bnez	a4,800006a6 <printk+0x196>
    } else if (c0 == 'p') {
    80000818:	ebba83e3          	beq	s5,s11,800006be <printk+0x1ae>
    } else if (c0 == 'c') {
    8000081c:	06300793          	li	a5,99
    80000820:	eefa82e3          	beq	s5,a5,80000704 <printk+0x1f4>
    } else if (c0 == 's') {
    80000824:	07300793          	li	a5,115
    80000828:	eefa88e3          	beq	s5,a5,80000718 <printk+0x208>
    } else if (c0 == '%') {
    8000082c:	02500793          	li	a5,37
    80000830:	f2fa80e3          	beq	s5,a5,80000750 <printk+0x240>
    } else if (c0 == 0) {
    80000834:	f40a86e3          	beqz	s5,80000780 <printk+0x270>
      consputc('%');
    80000838:	02500513          	li	a0,37
    8000083c:	a4fff0ef          	jal	8000028a <consputc>
      consputc(c0);
    80000840:	8556                	mv	a0,s5
    80000842:	a49ff0ef          	jal	8000028a <consputc>
    80000846:	bb55                	j	800005fa <printk+0xea>

0000000080000848 <panic>:

void
panic(char *s)
{
    80000848:	1101                	addi	sp,sp,-32
    8000084a:	ec06                	sd	ra,24(sp)
    8000084c:	e822                	sd	s0,16(sp)
    8000084e:	e426                	sd	s1,8(sp)
    80000850:	e04a                	sd	s2,0(sp)
    80000852:	1000                	addi	s0,sp,32
    80000854:	892a                	mv	s2,a0
  panicking = 1;
    80000856:	4485                	li	s1,1
    80000858:	0000a797          	auipc	a5,0xa
    8000085c:	a897a623          	sw	s1,-1396(a5) # 8000a2e4 <panicking>
  printk("panic: ");
    80000860:	00006517          	auipc	a0,0x6
    80000864:	7b850513          	addi	a0,a0,1976 # 80007018 <etext+0x18>
    80000868:	ca9ff0ef          	jal	80000510 <printk>
  printk("%s\n", s);
    8000086c:	85ca                	mv	a1,s2
    8000086e:	00006517          	auipc	a0,0x6
    80000872:	7b250513          	addi	a0,a0,1970 # 80007020 <etext+0x20>
    80000876:	c9bff0ef          	jal	80000510 <printk>
  panicked = 1; // freeze uart output from other CPUs
    8000087a:	0000a797          	auipc	a5,0xa
    8000087e:	a697a323          	sw	s1,-1434(a5) # 8000a2e0 <panicked>
  for (;;)
    80000882:	a001                	j	80000882 <panic+0x3a>

0000000080000884 <printkinit>:
    ;
}

void
printkinit(void)
{
    80000884:	1141                	addi	sp,sp,-16
    80000886:	e406                	sd	ra,8(sp)
    80000888:	e022                	sd	s0,0(sp)
    8000088a:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    8000088c:	00006597          	auipc	a1,0x6
    80000890:	79c58593          	addi	a1,a1,1948 # 80007028 <etext+0x28>
    80000894:	00012517          	auipc	a0,0x12
    80000898:	b2450513          	addi	a0,a0,-1244 # 800123b8 <pr>
    8000089c:	2dc000ef          	jal	80000b78 <initlock>
}
    800008a0:	60a2                	ld	ra,8(sp)
    800008a2:	6402                	ld	s0,0(sp)
    800008a4:	0141                	addi	sp,sp,16
    800008a6:	8082                	ret

00000000800008a8 <uartinit>:
extern volatile int panicking; // from printk.c
extern volatile int panicked;  // from printk.c

void
uartinit(void)
{
    800008a8:	1141                	addi	sp,sp,-16
    800008aa:	e406                	sd	ra,8(sp)
    800008ac:	e022                	sd	s0,0(sp)
    800008ae:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    800008b0:	100007b7          	lui	a5,0x10000
    800008b4:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    800008b8:	10000737          	lui	a4,0x10000
    800008bc:	f8000693          	li	a3,-128
    800008c0:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800008c4:	468d                	li	a3,3
    800008c6:	10000637          	lui	a2,0x10000
    800008ca:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800008ce:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800008d2:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800008d6:	8732                	mv	a4,a2
    800008d8:	461d                	li	a2,7
    800008da:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800008de:	00d780a3          	sb	a3,1(a5)

  initsleeplock(&tx_lock, "uart");
    800008e2:	00006597          	auipc	a1,0x6
    800008e6:	74e58593          	addi	a1,a1,1870 # 80007030 <etext+0x30>
    800008ea:	00012517          	auipc	a0,0x12
    800008ee:	ae650513          	addi	a0,a0,-1306 # 800123d0 <tx_lock>
    800008f2:	6ea030ef          	jal	80003fdc <initsleeplock>
}
    800008f6:	60a2                	ld	ra,8(sp)
    800008f8:	6402                	ld	s0,0(sp)
    800008fa:	0141                	addi	sp,sp,16
    800008fc:	8082                	ret

00000000800008fe <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    800008fe:	7139                	addi	sp,sp,-64
    80000900:	fc06                	sd	ra,56(sp)
    80000902:	f822                	sd	s0,48(sp)
    80000904:	f04a                	sd	s2,32(sp)
    80000906:	e456                	sd	s5,8(sp)
    80000908:	0080                	addi	s0,sp,64
    8000090a:	8aaa                	mv	s5,a0
    8000090c:	892e                	mv	s2,a1
  acquiresleep(&tx_lock);
    8000090e:	00012517          	auipc	a0,0x12
    80000912:	ac250513          	addi	a0,a0,-1342 # 800123d0 <tx_lock>
    80000916:	6fc030ef          	jal	80004012 <acquiresleep>

  int i = 0;
  while (i < n) {
    8000091a:	05205963          	blez	s2,8000096c <uartwrite+0x6e>
    8000091e:	f426                	sd	s1,40(sp)
    80000920:	ec4e                	sd	s3,24(sp)
    80000922:	e852                	sd	s4,16(sp)
    80000924:	e05a                	sd	s6,0(sp)
  int i = 0;
    80000926:	4481                	li	s1,0
    sleep_prepare(&tx_chan);
    80000928:	0000aa17          	auipc	s4,0xa
    8000092c:	9c0a0a13          	addi	s4,s4,-1600 # 8000a2e8 <tx_chan>
    if (ReadReg(LSR) & LSR_TX_IDLE) {
    80000930:	100009b7          	lui	s3,0x10000
    80000934:	0995                	addi	s3,s3,5 # 10000005 <_entry-0x6ffffffb>
      WriteReg(THR, buf[i]);
    80000936:	10000b37          	lui	s6,0x10000
    8000093a:	a029                	j	80000944 <uartwrite+0x46>
      i += 1;
    } else {
      sleep();
    8000093c:	5ea010ef          	jal	80001f26 <sleep>
  while (i < n) {
    80000940:	0324d263          	bge	s1,s2,80000964 <uartwrite+0x66>
    sleep_prepare(&tx_chan);
    80000944:	8552                	mv	a0,s4
    80000946:	5a4010ef          	jal	80001eea <sleep_prepare>
    if (ReadReg(LSR) & LSR_TX_IDLE) {
    8000094a:	0009c783          	lbu	a5,0(s3)
    8000094e:	0207f793          	andi	a5,a5,32
    80000952:	d7ed                	beqz	a5,8000093c <uartwrite+0x3e>
      WriteReg(THR, buf[i]);
    80000954:	009a87b3          	add	a5,s5,s1
    80000958:	0007c783          	lbu	a5,0(a5)
    8000095c:	00fb0023          	sb	a5,0(s6) # 10000000 <_entry-0x70000000>
      i += 1;
    80000960:	2485                	addiw	s1,s1,1
    80000962:	bff9                	j	80000940 <uartwrite+0x42>
    80000964:	74a2                	ld	s1,40(sp)
    80000966:	69e2                	ld	s3,24(sp)
    80000968:	6a42                	ld	s4,16(sp)
    8000096a:	6b02                	ld	s6,0(sp)
    }
  }

  releasesleep(&tx_lock);
    8000096c:	00012517          	auipc	a0,0x12
    80000970:	a6450513          	addi	a0,a0,-1436 # 800123d0 <tx_lock>
    80000974:	6f2030ef          	jal	80004066 <releasesleep>
}
    80000978:	70e2                	ld	ra,56(sp)
    8000097a:	7442                	ld	s0,48(sp)
    8000097c:	7902                	ld	s2,32(sp)
    8000097e:	6aa2                	ld	s5,8(sp)
    80000980:	6121                	addi	sp,sp,64
    80000982:	8082                	ret

0000000080000984 <uartputc_sync>:
// interrupts, for use by kernel printk() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    80000984:	1101                	addi	sp,sp,-32
    80000986:	ec06                	sd	ra,24(sp)
    80000988:	e822                	sd	s0,16(sp)
    8000098a:	e426                	sd	s1,8(sp)
    8000098c:	1000                	addi	s0,sp,32
    8000098e:	84aa                	mv	s1,a0
  if (panicking == 0)
    80000990:	0000a797          	auipc	a5,0xa
    80000994:	9547a783          	lw	a5,-1708(a5) # 8000a2e4 <panicking>
    80000998:	cb91                	beqz	a5,800009ac <uartputc_sync+0x28>
    push_off();

  if (panicked) {
    8000099a:	0000a797          	auipc	a5,0xa
    8000099e:	9467a783          	lw	a5,-1722(a5) # 8000a2e0 <panicked>
    for (;;)
      ;
  }

  // wait for UART to set Transmit Holding Empty in LSR.
  while ((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800009a2:	10000737          	lui	a4,0x10000
    800009a6:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
  if (panicked) {
    800009a8:	c789                	beqz	a5,800009b2 <uartputc_sync+0x2e>
    for (;;)
    800009aa:	a001                	j	800009aa <uartputc_sync+0x26>
    push_off();
    800009ac:	212000ef          	jal	80000bbe <push_off>
    800009b0:	b7ed                	j	8000099a <uartputc_sync+0x16>
  while ((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800009b2:	00074783          	lbu	a5,0(a4)
    800009b6:	0207f793          	andi	a5,a5,32
    800009ba:	dfe5                	beqz	a5,800009b2 <uartputc_sync+0x2e>
    ;
  WriteReg(THR, c);
    800009bc:	100007b7          	lui	a5,0x10000
    800009c0:	00978023          	sb	s1,0(a5) # 10000000 <_entry-0x70000000>

  if (panicking == 0)
    800009c4:	0000a797          	auipc	a5,0xa
    800009c8:	9207a783          	lw	a5,-1760(a5) # 8000a2e4 <panicking>
    800009cc:	c791                	beqz	a5,800009d8 <uartputc_sync+0x54>
    pop_off();
}
    800009ce:	60e2                	ld	ra,24(sp)
    800009d0:	6442                	ld	s0,16(sp)
    800009d2:	64a2                	ld	s1,8(sp)
    800009d4:	6105                	addi	sp,sp,32
    800009d6:	8082                	ret
    pop_off();
    800009d8:	25c000ef          	jal	80000c34 <pop_off>
}
    800009dc:	bfcd                	j	800009ce <uartputc_sync+0x4a>

00000000800009de <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009de:	1101                	addi	sp,sp,-32
    800009e0:	ec06                	sd	ra,24(sp)
    800009e2:	e822                	sd	s0,16(sp)
    800009e4:	e426                	sd	s1,8(sp)
    800009e6:	e04a                	sd	s2,0(sp)
    800009e8:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009ea:	100007b7          	lui	a5,0x10000
    800009ee:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  if (ReadReg(LSR) & LSR_TX_IDLE) {
    800009f2:	100007b7          	lui	a5,0x10000
    800009f6:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    800009fa:	0207f793          	andi	a5,a5,32
    800009fe:	ef99                	bnez	a5,80000a1c <uartintr+0x3e>
  if (ReadReg(LSR) & LSR_RX_READY) {
    80000a00:	100004b7          	lui	s1,0x10000
    80000a04:	0495                	addi	s1,s1,5 # 10000005 <_entry-0x6ffffffb>
    return ReadReg(RHR);
    80000a06:	10000937          	lui	s2,0x10000
  if (ReadReg(LSR) & LSR_RX_READY) {
    80000a0a:	0004c783          	lbu	a5,0(s1)
    80000a0e:	8b85                	andi	a5,a5,1
    80000a10:	cf89                	beqz	a5,80000a2a <uartintr+0x4c>
  // read and process incoming characters, if any.
  while (1) {
    int c = uartgetc();
    if (c == -1)
      break;
    consoleintr(c);
    80000a12:	00094503          	lbu	a0,0(s2) # 10000000 <_entry-0x70000000>
    80000a16:	8a7ff0ef          	jal	800002bc <consoleintr>
  while (1) {
    80000a1a:	bfc5                	j	80000a0a <uartintr+0x2c>
    wakeup(&tx_chan);
    80000a1c:	0000a517          	auipc	a0,0xa
    80000a20:	8cc50513          	addi	a0,a0,-1844 # 8000a2e8 <tx_chan>
    80000a24:	532010ef          	jal	80001f56 <wakeup>
    80000a28:	bfe1                	j	80000a00 <uartintr+0x22>
  }
}
    80000a2a:	60e2                	ld	ra,24(sp)
    80000a2c:	6442                	ld	s0,16(sp)
    80000a2e:	64a2                	ld	s1,8(sp)
    80000a30:	6902                	ld	s2,0(sp)
    80000a32:	6105                	addi	sp,sp,32
    80000a34:	8082                	ret

0000000080000a36 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a36:	1101                	addi	sp,sp,-32
    80000a38:	ec06                	sd	ra,24(sp)
    80000a3a:	e822                	sd	s0,16(sp)
    80000a3c:	e426                	sd	s1,8(sp)
    80000a3e:	e04a                	sd	s2,0(sp)
    80000a40:	1000                	addi	s0,sp,32
  struct run *r;

  if (((uint64)pa % PGSIZE) != 0 || (char *)pa < end || (uint64)pa >= PHYSTOP)
    80000a42:	00023797          	auipc	a5,0x23
    80000a46:	bee78793          	addi	a5,a5,-1042 # 80023630 <end>
    80000a4a:	00f53733          	sltu	a4,a0,a5
    80000a4e:	47c5                	li	a5,17
    80000a50:	07ee                	slli	a5,a5,0x1b
    80000a52:	17fd                	addi	a5,a5,-1
    80000a54:	00a7b7b3          	sltu	a5,a5,a0
    80000a58:	8fd9                	or	a5,a5,a4
    80000a5a:	03451713          	slli	a4,a0,0x34
    80000a5e:	8fd9                	or	a5,a5,a4
    80000a60:	eb9d                	bnez	a5,80000a96 <kfree+0x60>
    80000a62:	84aa                	mv	s1,a0
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a64:	6605                	lui	a2,0x1
    80000a66:	4585                	li	a1,1
    80000a68:	24c000ef          	jal	80000cb4 <memset>

  r = (struct run *)pa;

  acquire(&kmem.lock);
    80000a6c:	00012917          	auipc	s2,0x12
    80000a70:	99490913          	addi	s2,s2,-1644 # 80012400 <kmem>
    80000a74:	854a                	mv	a0,s2
    80000a76:	182000ef          	jal	80000bf8 <acquire>
  r->next = kmem.freelist;
    80000a7a:	01893783          	ld	a5,24(s2)
    80000a7e:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a80:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a84:	854a                	mv	a0,s2
    80000a86:	1f6000ef          	jal	80000c7c <release>
}
    80000a8a:	60e2                	ld	ra,24(sp)
    80000a8c:	6442                	ld	s0,16(sp)
    80000a8e:	64a2                	ld	s1,8(sp)
    80000a90:	6902                	ld	s2,0(sp)
    80000a92:	6105                	addi	sp,sp,32
    80000a94:	8082                	ret
    panic("kfree");
    80000a96:	00006517          	auipc	a0,0x6
    80000a9a:	5a250513          	addi	a0,a0,1442 # 80007038 <etext+0x38>
    80000a9e:	dabff0ef          	jal	80000848 <panic>

0000000080000aa2 <freerange>:
{
    80000aa2:	7179                	addi	sp,sp,-48
    80000aa4:	f406                	sd	ra,40(sp)
    80000aa6:	f022                	sd	s0,32(sp)
    80000aa8:	ec26                	sd	s1,24(sp)
    80000aaa:	1800                	addi	s0,sp,48
  p = (char *)PGROUNDUP((uint64)pa_start);
    80000aac:	6785                	lui	a5,0x1
    80000aae:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000ab2:	00e504b3          	add	s1,a0,a4
    80000ab6:	777d                	lui	a4,0xfffff
    80000ab8:	8cf9                	and	s1,s1,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000aba:	94be                	add	s1,s1,a5
    80000abc:	0295e263          	bltu	a1,s1,80000ae0 <freerange+0x3e>
    80000ac0:	e84a                	sd	s2,16(sp)
    80000ac2:	e44e                	sd	s3,8(sp)
    80000ac4:	e052                	sd	s4,0(sp)
    80000ac6:	892e                	mv	s2,a1
    kfree(p);
    80000ac8:	8a3a                	mv	s4,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000aca:	89be                	mv	s3,a5
    kfree(p);
    80000acc:	01448533          	add	a0,s1,s4
    80000ad0:	f67ff0ef          	jal	80000a36 <kfree>
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000ad4:	94ce                	add	s1,s1,s3
    80000ad6:	fe997be3          	bgeu	s2,s1,80000acc <freerange+0x2a>
    80000ada:	6942                	ld	s2,16(sp)
    80000adc:	69a2                	ld	s3,8(sp)
    80000ade:	6a02                	ld	s4,0(sp)
}
    80000ae0:	70a2                	ld	ra,40(sp)
    80000ae2:	7402                	ld	s0,32(sp)
    80000ae4:	64e2                	ld	s1,24(sp)
    80000ae6:	6145                	addi	sp,sp,48
    80000ae8:	8082                	ret

0000000080000aea <kinit>:
{
    80000aea:	1141                	addi	sp,sp,-16
    80000aec:	e406                	sd	ra,8(sp)
    80000aee:	e022                	sd	s0,0(sp)
    80000af0:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000af2:	00006597          	auipc	a1,0x6
    80000af6:	54e58593          	addi	a1,a1,1358 # 80007040 <etext+0x40>
    80000afa:	00012517          	auipc	a0,0x12
    80000afe:	90650513          	addi	a0,a0,-1786 # 80012400 <kmem>
    80000b02:	076000ef          	jal	80000b78 <initlock>
  freerange(end, (void *)PHYSTOP);
    80000b06:	45c5                	li	a1,17
    80000b08:	05ee                	slli	a1,a1,0x1b
    80000b0a:	00023517          	auipc	a0,0x23
    80000b0e:	b2650513          	addi	a0,a0,-1242 # 80023630 <end>
    80000b12:	f91ff0ef          	jal	80000aa2 <freerange>
}
    80000b16:	60a2                	ld	ra,8(sp)
    80000b18:	6402                	ld	s0,0(sp)
    80000b1a:	0141                	addi	sp,sp,16
    80000b1c:	8082                	ret

0000000080000b1e <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b1e:	1101                	addi	sp,sp,-32
    80000b20:	ec06                	sd	ra,24(sp)
    80000b22:	e822                	sd	s0,16(sp)
    80000b24:	e426                	sd	s1,8(sp)
    80000b26:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b28:	00012517          	auipc	a0,0x12
    80000b2c:	8d850513          	addi	a0,a0,-1832 # 80012400 <kmem>
    80000b30:	0c8000ef          	jal	80000bf8 <acquire>
  r = kmem.freelist;
    80000b34:	00012497          	auipc	s1,0x12
    80000b38:	8e44b483          	ld	s1,-1820(s1) # 80012418 <kmem+0x18>
  if (r)
    80000b3c:	c49d                	beqz	s1,80000b6a <kalloc+0x4c>
    kmem.freelist = r->next;
    80000b3e:	609c                	ld	a5,0(s1)
    80000b40:	00012717          	auipc	a4,0x12
    80000b44:	8cf73c23          	sd	a5,-1832(a4) # 80012418 <kmem+0x18>
  release(&kmem.lock);
    80000b48:	00012517          	auipc	a0,0x12
    80000b4c:	8b850513          	addi	a0,a0,-1864 # 80012400 <kmem>
    80000b50:	12c000ef          	jal	80000c7c <release>

  if (r)
    memset((char *)r, 5, PGSIZE); // fill with junk
    80000b54:	6605                	lui	a2,0x1
    80000b56:	4595                	li	a1,5
    80000b58:	8526                	mv	a0,s1
    80000b5a:	15a000ef          	jal	80000cb4 <memset>
  return (void *)r;
}
    80000b5e:	8526                	mv	a0,s1
    80000b60:	60e2                	ld	ra,24(sp)
    80000b62:	6442                	ld	s0,16(sp)
    80000b64:	64a2                	ld	s1,8(sp)
    80000b66:	6105                	addi	sp,sp,32
    80000b68:	8082                	ret
  release(&kmem.lock);
    80000b6a:	00012517          	auipc	a0,0x12
    80000b6e:	89650513          	addi	a0,a0,-1898 # 80012400 <kmem>
    80000b72:	10a000ef          	jal	80000c7c <release>
  if (r)
    80000b76:	b7e5                	j	80000b5e <kalloc+0x40>

0000000080000b78 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b78:	1141                	addi	sp,sp,-16
    80000b7a:	e406                	sd	ra,8(sp)
    80000b7c:	e022                	sd	s0,0(sp)
    80000b7e:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b80:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b82:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b86:	00053823          	sd	zero,16(a0)
}
    80000b8a:	60a2                	ld	ra,8(sp)
    80000b8c:	6402                	ld	s0,0(sp)
    80000b8e:	0141                	addi	sp,sp,16
    80000b90:	8082                	ret

0000000080000b92 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000b92:	411c                	lw	a5,0(a0)
    80000b94:	e399                	bnez	a5,80000b9a <holding+0x8>
    80000b96:	4501                	li	a0,0
  return r;
}
    80000b98:	8082                	ret
{
    80000b9a:	1101                	addi	sp,sp,-32
    80000b9c:	ec06                	sd	ra,24(sp)
    80000b9e:	e822                	sd	s0,16(sp)
    80000ba0:	e426                	sd	s1,8(sp)
    80000ba2:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000ba4:	691c                	ld	a5,16(a0)
    80000ba6:	84be                	mv	s1,a5
    80000ba8:	51b000ef          	jal	800018c2 <mycpu>
    80000bac:	40a48533          	sub	a0,s1,a0
    80000bb0:	00153513          	seqz	a0,a0
}
    80000bb4:	60e2                	ld	ra,24(sp)
    80000bb6:	6442                	ld	s0,16(sp)
    80000bb8:	64a2                	ld	s1,8(sp)
    80000bba:	6105                	addi	sp,sp,32
    80000bbc:	8082                	ret

0000000080000bbe <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000bbe:	1101                	addi	sp,sp,-32
    80000bc0:	ec06                	sd	ra,24(sp)
    80000bc2:	e822                	sd	s0,16(sp)
    80000bc4:	e426                	sd	s1,8(sp)
    80000bc6:	1000                	addi	s0,sp,32
  __asm__ __volatile__("csrrc %0, sstatus, %1" : "=r"(x) : "rK"(x) : "memory");
    80000bc8:	100177f3          	csrrci	a5,sstatus,2
    80000bcc:	84be                	mv	s1,a5
  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  uint64 flags = rc_sstatus(SSTATUS_SIE);
  int old = !!(flags & SSTATUS_SIE);

  if (mycpu()->noff == 0)
    80000bce:	4f5000ef          	jal	800018c2 <mycpu>
    80000bd2:	5d3c                	lw	a5,120(a0)
    80000bd4:	cb99                	beqz	a5,80000bea <push_off+0x2c>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000bd6:	4ed000ef          	jal	800018c2 <mycpu>
    80000bda:	5d3c                	lw	a5,120(a0)
    80000bdc:	2785                	addiw	a5,a5,1
    80000bde:	dd3c                	sw	a5,120(a0)
}
    80000be0:	60e2                	ld	ra,24(sp)
    80000be2:	6442                	ld	s0,16(sp)
    80000be4:	64a2                	ld	s1,8(sp)
    80000be6:	6105                	addi	sp,sp,32
    80000be8:	8082                	ret
    mycpu()->intena = old;
    80000bea:	4d9000ef          	jal	800018c2 <mycpu>
  int old = !!(flags & SSTATUS_SIE);
    80000bee:	0014d793          	srli	a5,s1,0x1
    80000bf2:	8b85                	andi	a5,a5,1
    mycpu()->intena = old;
    80000bf4:	dd7c                	sw	a5,124(a0)
    80000bf6:	b7c5                	j	80000bd6 <push_off+0x18>

0000000080000bf8 <acquire>:
{
    80000bf8:	1101                	addi	sp,sp,-32
    80000bfa:	ec06                	sd	ra,24(sp)
    80000bfc:	e822                	sd	s0,16(sp)
    80000bfe:	e426                	sd	s1,8(sp)
    80000c00:	1000                	addi	s0,sp,32
    80000c02:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000c04:	fbbff0ef          	jal	80000bbe <push_off>
  if (holding(lk))
    80000c08:	8526                	mv	a0,s1
    80000c0a:	f89ff0ef          	jal	80000b92 <holding>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000c0e:	4705                	li	a4,1
  if (holding(lk))
    80000c10:	ed01                	bnez	a0,80000c28 <acquire+0x30>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000c12:	0ce4a7af          	amoswap.w.aq	a5,a4,(s1)
    80000c16:	fff5                	bnez	a5,80000c12 <acquire+0x1a>
  lk->cpu = mycpu();
    80000c18:	4ab000ef          	jal	800018c2 <mycpu>
    80000c1c:	e888                	sd	a0,16(s1)
}
    80000c1e:	60e2                	ld	ra,24(sp)
    80000c20:	6442                	ld	s0,16(sp)
    80000c22:	64a2                	ld	s1,8(sp)
    80000c24:	6105                	addi	sp,sp,32
    80000c26:	8082                	ret
    panic("acquire");
    80000c28:	00006517          	auipc	a0,0x6
    80000c2c:	42050513          	addi	a0,a0,1056 # 80007048 <etext+0x48>
    80000c30:	c19ff0ef          	jal	80000848 <panic>

0000000080000c34 <pop_off>:

void
pop_off(void)
{
    80000c34:	1141                	addi	sp,sp,-16
    80000c36:	e406                	sd	ra,8(sp)
    80000c38:	e022                	sd	s0,0(sp)
    80000c3a:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c3c:	487000ef          	jal	800018c2 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80000c40:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c44:	8b89                	andi	a5,a5,2
  if (intr_get())
    80000c46:	ef99                	bnez	a5,80000c64 <pop_off+0x30>
    panic("pop_off - interruptible");
  if (c->noff < 1)
    80000c48:	5d3c                	lw	a5,120(a0)
    80000c4a:	02f05363          	blez	a5,80000c70 <pop_off+0x3c>
    panic("pop_off");
  c->noff -= 1;
    80000c4e:	37fd                	addiw	a5,a5,-1
    80000c50:	dd3c                	sw	a5,120(a0)
  if (c->noff == 0 && c->intena)
    80000c52:	e789                	bnez	a5,80000c5c <pop_off+0x28>
    80000c54:	5d7c                	lw	a5,124(a0)
    80000c56:	c399                	beqz	a5,80000c5c <pop_off+0x28>
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80000c58:	10016073          	csrsi	sstatus,2
    intr_on();
}
    80000c5c:	60a2                	ld	ra,8(sp)
    80000c5e:	6402                	ld	s0,0(sp)
    80000c60:	0141                	addi	sp,sp,16
    80000c62:	8082                	ret
    panic("pop_off - interruptible");
    80000c64:	00006517          	auipc	a0,0x6
    80000c68:	3ec50513          	addi	a0,a0,1004 # 80007050 <etext+0x50>
    80000c6c:	bddff0ef          	jal	80000848 <panic>
    panic("pop_off");
    80000c70:	00006517          	auipc	a0,0x6
    80000c74:	3f850513          	addi	a0,a0,1016 # 80007068 <etext+0x68>
    80000c78:	bd1ff0ef          	jal	80000848 <panic>

0000000080000c7c <release>:
{
    80000c7c:	1101                	addi	sp,sp,-32
    80000c7e:	ec06                	sd	ra,24(sp)
    80000c80:	e822                	sd	s0,16(sp)
    80000c82:	e426                	sd	s1,8(sp)
    80000c84:	1000                	addi	s0,sp,32
    80000c86:	84aa                	mv	s1,a0
  if (!holding(lk))
    80000c88:	f0bff0ef          	jal	80000b92 <holding>
    80000c8c:	cd11                	beqz	a0,80000ca8 <release+0x2c>
  lk->cpu = 0;
    80000c8e:	0004b823          	sd	zero,16(s1)
  __atomic_store_n(&lk->locked, 0, __ATOMIC_RELEASE);
    80000c92:	0310000f          	fence	rw,w
    80000c96:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000c9a:	f9bff0ef          	jal	80000c34 <pop_off>
}
    80000c9e:	60e2                	ld	ra,24(sp)
    80000ca0:	6442                	ld	s0,16(sp)
    80000ca2:	64a2                	ld	s1,8(sp)
    80000ca4:	6105                	addi	sp,sp,32
    80000ca6:	8082                	ret
    panic("release");
    80000ca8:	00006517          	auipc	a0,0x6
    80000cac:	3c850513          	addi	a0,a0,968 # 80007070 <etext+0x70>
    80000cb0:	b99ff0ef          	jal	80000848 <panic>

0000000080000cb4 <memset>:
#include "types.h"

void *
memset(void *dst, int c, uint n)
{
    80000cb4:	1141                	addi	sp,sp,-16
    80000cb6:	e406                	sd	ra,8(sp)
    80000cb8:	e022                	sd	s0,0(sp)
    80000cba:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
    80000cbc:	ca19                	beqz	a2,80000cd2 <memset+0x1e>
    80000cbe:	87aa                	mv	a5,a0
    80000cc0:	1602                	slli	a2,a2,0x20
    80000cc2:	9201                	srli	a2,a2,0x20
    80000cc4:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000cc8:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
    80000ccc:	0785                	addi	a5,a5,1
    80000cce:	fee79de3          	bne	a5,a4,80000cc8 <memset+0x14>
  }
  return dst;
}
    80000cd2:	60a2                	ld	ra,8(sp)
    80000cd4:	6402                	ld	s0,0(sp)
    80000cd6:	0141                	addi	sp,sp,16
    80000cd8:	8082                	ret

0000000080000cda <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000cda:	1141                	addi	sp,sp,-16
    80000cdc:	e406                	sd	ra,8(sp)
    80000cde:	e022                	sd	s0,0(sp)
    80000ce0:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while (n-- > 0) {
    80000ce2:	ce19                	beqz	a2,80000d00 <memcmp+0x26>
    80000ce4:	1602                	slli	a2,a2,0x20
    80000ce6:	9201                	srli	a2,a2,0x20
    80000ce8:	00c506b3          	add	a3,a0,a2
    if (*s1 != *s2)
    80000cec:	00054783          	lbu	a5,0(a0)
    80000cf0:	0005c703          	lbu	a4,0(a1)
    80000cf4:	00e79b63          	bne	a5,a4,80000d0a <memcmp+0x30>
      return *s1 - *s2;
    s1++, s2++;
    80000cf8:	0505                	addi	a0,a0,1
    80000cfa:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    80000cfc:	fed518e3          	bne	a0,a3,80000cec <memcmp+0x12>
  }

  return 0;
    80000d00:	4501                	li	a0,0
}
    80000d02:	60a2                	ld	ra,8(sp)
    80000d04:	6402                	ld	s0,0(sp)
    80000d06:	0141                	addi	sp,sp,16
    80000d08:	8082                	ret
      return *s1 - *s2;
    80000d0a:	40e7853b          	subw	a0,a5,a4
    80000d0e:	bfd5                	j	80000d02 <memcmp+0x28>

0000000080000d10 <memmove>:

void *
memmove(void *dst, const void *src, uint n)
{
    80000d10:	1141                	addi	sp,sp,-16
    80000d12:	e406                	sd	ra,8(sp)
    80000d14:	e022                	sd	s0,0(sp)
    80000d16:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if (n == 0)
    80000d18:	c61d                	beqz	a2,80000d46 <memmove+0x36>
    return dst;

  s = src;
  d = dst;
  if (s < d && s + n > d) {
    80000d1a:	00a5f963          	bgeu	a1,a0,80000d2c <memmove+0x1c>
    80000d1e:	02061693          	slli	a3,a2,0x20
    80000d22:	9281                	srli	a3,a3,0x20
    80000d24:	00d58733          	add	a4,a1,a3
    80000d28:	02e56363          	bltu	a0,a4,80000d4e <memmove+0x3e>
    s += n;
    d += n;
    while (n-- > 0)
      *--d = *--s;
  } else
    while (n-- > 0)
    80000d2c:	1602                	slli	a2,a2,0x20
    80000d2e:	9201                	srli	a2,a2,0x20
    80000d30:	00c587b3          	add	a5,a1,a2
{
    80000d34:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d36:	0585                	addi	a1,a1,1
    80000d38:	0705                	addi	a4,a4,1
    80000d3a:	fff5c683          	lbu	a3,-1(a1)
    80000d3e:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
    80000d42:	fef59ae3          	bne	a1,a5,80000d36 <memmove+0x26>

  return dst;
}
    80000d46:	60a2                	ld	ra,8(sp)
    80000d48:	6402                	ld	s0,0(sp)
    80000d4a:	0141                	addi	sp,sp,16
    80000d4c:	8082                	ret
    d += n;
    80000d4e:	96aa                	add	a3,a3,a0
    while (n-- > 0)
    80000d50:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000d54:	1782                	slli	a5,a5,0x20
    80000d56:	9381                	srli	a5,a5,0x20
    80000d58:	fff7c793          	not	a5,a5
    80000d5c:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000d5e:	177d                	addi	a4,a4,-1
    80000d60:	16fd                	addi	a3,a3,-1
    80000d62:	00074603          	lbu	a2,0(a4)
    80000d66:	00c68023          	sb	a2,0(a3)
    while (n-- > 0)
    80000d6a:	fee79ae3          	bne	a5,a4,80000d5e <memmove+0x4e>
    80000d6e:	bfe1                	j	80000d46 <memmove+0x36>

0000000080000d70 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void *
memcpy(void *dst, const void *src, uint n)
{
    80000d70:	1141                	addi	sp,sp,-16
    80000d72:	e406                	sd	ra,8(sp)
    80000d74:	e022                	sd	s0,0(sp)
    80000d76:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000d78:	f99ff0ef          	jal	80000d10 <memmove>
}
    80000d7c:	60a2                	ld	ra,8(sp)
    80000d7e:	6402                	ld	s0,0(sp)
    80000d80:	0141                	addi	sp,sp,16
    80000d82:	8082                	ret

0000000080000d84 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000d84:	1141                	addi	sp,sp,-16
    80000d86:	e406                	sd	ra,8(sp)
    80000d88:	e022                	sd	s0,0(sp)
    80000d8a:	0800                	addi	s0,sp,16
  while (n > 0 && *p && *p == *q)
    80000d8c:	ce01                	beqz	a2,80000da4 <strncmp+0x20>
    80000d8e:	00054783          	lbu	a5,0(a0)
    80000d92:	cb99                	beqz	a5,80000da8 <strncmp+0x24>
    80000d94:	0005c703          	lbu	a4,0(a1)
    80000d98:	00f71863          	bne	a4,a5,80000da8 <strncmp+0x24>
    n--, p++, q++;
    80000d9c:	367d                	addiw	a2,a2,-1
    80000d9e:	0505                	addi	a0,a0,1
    80000da0:	0585                	addi	a1,a1,1
  while (n > 0 && *p && *p == *q)
    80000da2:	f675                	bnez	a2,80000d8e <strncmp+0xa>
  if (n == 0)
    return 0;
    80000da4:	4501                	li	a0,0
    80000da6:	a031                	j	80000db2 <strncmp+0x2e>
  return (uchar)*p - (uchar)*q;
    80000da8:	00054503          	lbu	a0,0(a0)
    80000dac:	0005c783          	lbu	a5,0(a1)
    80000db0:	9d1d                	subw	a0,a0,a5
}
    80000db2:	60a2                	ld	ra,8(sp)
    80000db4:	6402                	ld	s0,0(sp)
    80000db6:	0141                	addi	sp,sp,16
    80000db8:	8082                	ret

0000000080000dba <strncpy>:

char *
strncpy(char *s, const char *t, int n)
{
    80000dba:	1141                	addi	sp,sp,-16
    80000dbc:	e406                	sd	ra,8(sp)
    80000dbe:	e022                	sd	s0,0(sp)
    80000dc0:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while (n-- > 0 && (*s++ = *t++) != 0)
    80000dc2:	87aa                	mv	a5,a0
    80000dc4:	a011                	j	80000dc8 <strncpy+0xe>
    80000dc6:	8636                	mv	a2,a3
    80000dc8:	02c05763          	blez	a2,80000df6 <strncpy+0x3c>
    80000dcc:	fff6069b          	addiw	a3,a2,-1
    80000dd0:	0785                	addi	a5,a5,1
    80000dd2:	0005c703          	lbu	a4,0(a1)
    80000dd6:	fee78fa3          	sb	a4,-1(a5)
    80000dda:	0585                	addi	a1,a1,1
    80000ddc:	f76d                	bnez	a4,80000dc6 <strncpy+0xc>
    ;
  while (n-- > 0)
    80000dde:	873e                	mv	a4,a5
    80000de0:	00d05b63          	blez	a3,80000df6 <strncpy+0x3c>
    80000de4:	9fb1                	addw	a5,a5,a2
    80000de6:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    80000de8:	0705                	addi	a4,a4,1
    80000dea:	fe070fa3          	sb	zero,-1(a4)
  while (n-- > 0)
    80000dee:	40e786bb          	subw	a3,a5,a4
    80000df2:	fed04be3          	bgtz	a3,80000de8 <strncpy+0x2e>
  return os;
}
    80000df6:	60a2                	ld	ra,8(sp)
    80000df8:	6402                	ld	s0,0(sp)
    80000dfa:	0141                	addi	sp,sp,16
    80000dfc:	8082                	ret

0000000080000dfe <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char *
safestrcpy(char *s, const char *t, int n)
{
    80000dfe:	1141                	addi	sp,sp,-16
    80000e00:	e406                	sd	ra,8(sp)
    80000e02:	e022                	sd	s0,0(sp)
    80000e04:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if (n <= 0)
    80000e06:	02c05363          	blez	a2,80000e2c <safestrcpy+0x2e>
    80000e0a:	fff6069b          	addiw	a3,a2,-1
    80000e0e:	1682                	slli	a3,a3,0x20
    80000e10:	9281                	srli	a3,a3,0x20
    80000e12:	96ae                	add	a3,a3,a1
    80000e14:	87aa                	mv	a5,a0
    return os;
  while (--n > 0 && (*s++ = *t++) != 0)
    80000e16:	00d58963          	beq	a1,a3,80000e28 <safestrcpy+0x2a>
    80000e1a:	0585                	addi	a1,a1,1
    80000e1c:	0785                	addi	a5,a5,1
    80000e1e:	fff5c703          	lbu	a4,-1(a1)
    80000e22:	fee78fa3          	sb	a4,-1(a5)
    80000e26:	fb65                	bnez	a4,80000e16 <safestrcpy+0x18>
    ;
  *s = 0;
    80000e28:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e2c:	60a2                	ld	ra,8(sp)
    80000e2e:	6402                	ld	s0,0(sp)
    80000e30:	0141                	addi	sp,sp,16
    80000e32:	8082                	ret

0000000080000e34 <strlen>:

int
strlen(const char *s)
{
    80000e34:	1141                	addi	sp,sp,-16
    80000e36:	e406                	sd	ra,8(sp)
    80000e38:	e022                	sd	s0,0(sp)
    80000e3a:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
    80000e3c:	00054783          	lbu	a5,0(a0)
    80000e40:	cf91                	beqz	a5,80000e5c <strlen+0x28>
    80000e42:	00150793          	addi	a5,a0,1
    80000e46:	86be                	mv	a3,a5
    80000e48:	0785                	addi	a5,a5,1
    80000e4a:	fff7c703          	lbu	a4,-1(a5)
    80000e4e:	ff65                	bnez	a4,80000e46 <strlen+0x12>
    80000e50:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000e54:	60a2                	ld	ra,8(sp)
    80000e56:	6402                	ld	s0,0(sp)
    80000e58:	0141                	addi	sp,sp,16
    80000e5a:	8082                	ret
  for (n = 0; s[n]; n++)
    80000e5c:	4501                	li	a0,0
    80000e5e:	bfdd                	j	80000e54 <strlen+0x20>

0000000080000e60 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000e60:	1141                	addi	sp,sp,-16
    80000e62:	e406                	sd	ra,8(sp)
    80000e64:	e022                	sd	s0,0(sp)
    80000e66:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    80000e68:	247000ef          	jal	800018ae <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();         // first user process

    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
  } else {
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000e6c:	00009717          	auipc	a4,0x9
    80000e70:	48070713          	addi	a4,a4,1152 # 8000a2ec <started>
  if (cpuid() == 0) {
    80000e74:	c51d                	beqz	a0,80000ea2 <main+0x42>
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000e76:	431c                	lw	a5,0(a4)
    80000e78:	0230000f          	fence	r,rw
    80000e7c:	2781                	sext.w	a5,a5
    80000e7e:	dfe5                	beqz	a5,80000e76 <main+0x16>
      ;

    printk("hart %d starting\n", cpuid());
    80000e80:	22f000ef          	jal	800018ae <cpuid>
    80000e84:	85aa                	mv	a1,a0
    80000e86:	00006517          	auipc	a0,0x6
    80000e8a:	21250513          	addi	a0,a0,530 # 80007098 <etext+0x98>
    80000e8e:	e82ff0ef          	jal	80000510 <printk>
    kvminithart();  // turn on paging
    80000e92:	082000ef          	jal	80000f14 <kvminithart>
    trapinithart(); // install kernel trap vector
    80000e96:	612010ef          	jal	800024a8 <trapinithart>
    plicinithart(); // ask PLIC for device interrupts
    80000e9a:	75e040ef          	jal	800055f8 <plicinithart>
  }

  scheduler();
    80000e9e:	6b7000ef          	jal	80001d54 <scheduler>
    consoleinit();
    80000ea2:	d96ff0ef          	jal	80000438 <consoleinit>
    printkinit();
    80000ea6:	9dfff0ef          	jal	80000884 <printkinit>
    printk("\n");
    80000eaa:	00006517          	auipc	a0,0x6
    80000eae:	1ce50513          	addi	a0,a0,462 # 80007078 <etext+0x78>
    80000eb2:	e5eff0ef          	jal	80000510 <printk>
    printk("xv6 kernel is booting\n");
    80000eb6:	00006517          	auipc	a0,0x6
    80000eba:	1ca50513          	addi	a0,a0,458 # 80007080 <etext+0x80>
    80000ebe:	e52ff0ef          	jal	80000510 <printk>
    printk("\n");
    80000ec2:	00006517          	auipc	a0,0x6
    80000ec6:	1b650513          	addi	a0,a0,438 # 80007078 <etext+0x78>
    80000eca:	e46ff0ef          	jal	80000510 <printk>
    kinit();            // physical page allocator
    80000ece:	c1dff0ef          	jal	80000aea <kinit>
    kvminit();          // create kernel page table
    80000ed2:	2c2000ef          	jal	80001194 <kvminit>
    kvminithart();      // turn on paging
    80000ed6:	03e000ef          	jal	80000f14 <kvminithart>
    procinit();         // process table
    80000eda:	11d000ef          	jal	800017f6 <procinit>
    trapinit();         // trap vectors
    80000ede:	5a6010ef          	jal	80002484 <trapinit>
    trapinithart();     // install kernel trap vector
    80000ee2:	5c6010ef          	jal	800024a8 <trapinithart>
    plicinit();         // set up interrupt controller
    80000ee6:	6f8040ef          	jal	800055de <plicinit>
    plicinithart();     // ask PLIC for device interrupts
    80000eea:	70e040ef          	jal	800055f8 <plicinithart>
    binit();            // buffer cache
    80000eee:	475010ef          	jal	80002b62 <binit>
    iinit();            // inode table
    80000ef2:	1ce020ef          	jal	800030c0 <iinit>
    fileinit();         // file table
    80000ef6:	1f2030ef          	jal	800040e8 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000efa:	7ee040ef          	jal	800056e8 <virtio_disk_init>
    userinit();         // first user process
    80000efe:	4b5000ef          	jal	80001bb2 <userinit>
    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
    80000f02:	00009797          	auipc	a5,0x9
    80000f06:	3ea78793          	addi	a5,a5,1002 # 8000a2ec <started>
    80000f0a:	4705                	li	a4,1
    80000f0c:	0310000f          	fence	rw,w
    80000f10:	c398                	sw	a4,0(a5)
    80000f12:	b771                	j	80000e9e <main+0x3e>

0000000080000f14 <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000f14:	1141                	addi	sp,sp,-16
    80000f16:	e406                	sd	ra,8(sp)
    80000f18:	e022                	sd	s0,0(sp)
    80000f1a:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000f1c:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f20:	00009797          	auipc	a5,0x9
    80000f24:	3d07b783          	ld	a5,976(a5) # 8000a2f0 <kernel_pagetable>
    80000f28:	83b1                	srli	a5,a5,0xc
    80000f2a:	577d                	li	a4,-1
    80000f2c:	177e                	slli	a4,a4,0x3f
    80000f2e:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r"(x));
    80000f30:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000f34:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000f38:	60a2                	ld	ra,8(sp)
    80000f3a:	6402                	ld	s0,0(sp)
    80000f3c:	0141                	addi	sp,sp,16
    80000f3e:	8082                	ret

0000000080000f40 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000f40:	7139                	addi	sp,sp,-64
    80000f42:	fc06                	sd	ra,56(sp)
    80000f44:	f822                	sd	s0,48(sp)
    80000f46:	f426                	sd	s1,40(sp)
    80000f48:	f04a                	sd	s2,32(sp)
    80000f4a:	ec4e                	sd	s3,24(sp)
    80000f4c:	e852                	sd	s4,16(sp)
    80000f4e:	e456                	sd	s5,8(sp)
    80000f50:	e05a                	sd	s6,0(sp)
    80000f52:	0080                	addi	s0,sp,64
    80000f54:	84aa                	mv	s1,a0
    80000f56:	89ae                	mv	s3,a1
    80000f58:	8b32                	mv	s6,a2
  if (va >= MAXVA)
    80000f5a:	57fd                	li	a5,-1
    80000f5c:	83e9                	srli	a5,a5,0x1a
    80000f5e:	4a79                	li	s4,30
    panic("walk");

  for (int level = 2; level > 0; level--) {
    80000f60:	4ab1                	li	s5,12
  if (va >= MAXVA)
    80000f62:	06b7e363          	bltu	a5,a1,80000fc8 <walk+0x88>
    pte_t *pte = &pagetable[PX(level, va)];
    80000f66:	0149d933          	srl	s2,s3,s4
    80000f6a:	1ff97913          	andi	s2,s2,511
    80000f6e:	090e                	slli	s2,s2,0x3
    80000f70:	9926                	add	s2,s2,s1
    if (*pte & PTE_V) {
    80000f72:	00093483          	ld	s1,0(s2)
    80000f76:	0014f793          	andi	a5,s1,1
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000f7a:	80a9                	srli	s1,s1,0xa
    80000f7c:	04b2                	slli	s1,s1,0xc
    if (*pte & PTE_V) {
    80000f7e:	e395                	bnez	a5,80000fa2 <walk+0x62>
    } else {
      if (!alloc || (pagetable = (pde_t *)kalloc()) == 0)
    80000f80:	040b0a63          	beqz	s6,80000fd4 <walk+0x94>
    80000f84:	b9bff0ef          	jal	80000b1e <kalloc>
    80000f88:	84aa                	mv	s1,a0
    80000f8a:	c50d                	beqz	a0,80000fb4 <walk+0x74>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000f8c:	6605                	lui	a2,0x1
    80000f8e:	4581                	li	a1,0
    80000f90:	d25ff0ef          	jal	80000cb4 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000f94:	00c4d793          	srli	a5,s1,0xc
    80000f98:	07aa                	slli	a5,a5,0xa
    80000f9a:	0017e793          	ori	a5,a5,1
    80000f9e:	00f93023          	sd	a5,0(s2)
  for (int level = 2; level > 0; level--) {
    80000fa2:	3a5d                	addiw	s4,s4,-9
    80000fa4:	fd5a11e3          	bne	s4,s5,80000f66 <walk+0x26>
    }
  }
  return &pagetable[PX(0, va)];
    80000fa8:	00c9d513          	srli	a0,s3,0xc
    80000fac:	1ff57513          	andi	a0,a0,511
    80000fb0:	050e                	slli	a0,a0,0x3
    80000fb2:	9526                	add	a0,a0,s1
}
    80000fb4:	70e2                	ld	ra,56(sp)
    80000fb6:	7442                	ld	s0,48(sp)
    80000fb8:	74a2                	ld	s1,40(sp)
    80000fba:	7902                	ld	s2,32(sp)
    80000fbc:	69e2                	ld	s3,24(sp)
    80000fbe:	6a42                	ld	s4,16(sp)
    80000fc0:	6aa2                	ld	s5,8(sp)
    80000fc2:	6b02                	ld	s6,0(sp)
    80000fc4:	6121                	addi	sp,sp,64
    80000fc6:	8082                	ret
    panic("walk");
    80000fc8:	00006517          	auipc	a0,0x6
    80000fcc:	0e850513          	addi	a0,a0,232 # 800070b0 <etext+0xb0>
    80000fd0:	879ff0ef          	jal	80000848 <panic>
        return 0;
    80000fd4:	4501                	li	a0,0
    80000fd6:	bff9                	j	80000fb4 <walk+0x74>

0000000080000fd8 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if (va >= MAXVA)
    80000fd8:	57fd                	li	a5,-1
    80000fda:	83e9                	srli	a5,a5,0x1a
    80000fdc:	00b7f463          	bgeu	a5,a1,80000fe4 <walkaddr+0xc>
    return 0;
    80000fe0:	4501                	li	a0,0
    return 0;
  if ((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000fe2:	8082                	ret
{
    80000fe4:	1141                	addi	sp,sp,-16
    80000fe6:	e406                	sd	ra,8(sp)
    80000fe8:	e022                	sd	s0,0(sp)
    80000fea:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000fec:	4601                	li	a2,0
    80000fee:	f53ff0ef          	jal	80000f40 <walk>
  if (pte == 0)
    80000ff2:	c519                	beqz	a0,80001000 <walkaddr+0x28>
  if ((*pte & PTE_V) == 0)
    80000ff4:	6108                	ld	a0,0(a0)
  if ((*pte & PTE_U) == 0)
    80000ff6:	01157713          	andi	a4,a0,17
    80000ffa:	47c5                	li	a5,17
    80000ffc:	00f70763          	beq	a4,a5,8000100a <walkaddr+0x32>
    return 0;
    80001000:	4501                	li	a0,0
}
    80001002:	60a2                	ld	ra,8(sp)
    80001004:	6402                	ld	s0,0(sp)
    80001006:	0141                	addi	sp,sp,16
    80001008:	8082                	ret
  pa = PTE2PA(*pte);
    8000100a:	8129                	srli	a0,a0,0xa
    8000100c:	0532                	slli	a0,a0,0xc
  return pa;
    8000100e:	bfd5                	j	80001002 <walkaddr+0x2a>

0000000080001010 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001010:	715d                	addi	sp,sp,-80
    80001012:	e486                	sd	ra,72(sp)
    80001014:	e0a2                	sd	s0,64(sp)
    80001016:	fc26                	sd	s1,56(sp)
    80001018:	f84a                	sd	s2,48(sp)
    8000101a:	f44e                	sd	s3,40(sp)
    8000101c:	f052                	sd	s4,32(sp)
    8000101e:	ec56                	sd	s5,24(sp)
    80001020:	e85a                	sd	s6,16(sp)
    80001022:	e45e                	sd	s7,8(sp)
    80001024:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    80001026:	03459793          	slli	a5,a1,0x34
    8000102a:	e7b1                	bnez	a5,80001076 <mappages+0x66>
    8000102c:	8a2a                	mv	s4,a0
    8000102e:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if ((size % PGSIZE) != 0)
    80001030:	03461793          	slli	a5,a2,0x34
    80001034:	e7b9                	bnez	a5,80001082 <mappages+0x72>
    panic("mappages: size not aligned");

  if (size == 0)
    80001036:	ce21                	beqz	a2,8000108e <mappages+0x7e>
    panic("mappages: size");

  a = va;
  last = va + size - PGSIZE;
    80001038:	77fd                	lui	a5,0xfffff
    8000103a:	963e                	add	a2,a2,a5
    8000103c:	00b60933          	add	s2,a2,a1
  a = va;
    80001040:	84ae                	mv	s1,a1
  for (;;) {
    if ((pte = walk(pagetable, a, 1)) == 0)
    80001042:	4b05                	li	s6,1
    80001044:	40b689b3          	sub	s3,a3,a1
    if (*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if (a == last)
      break;
    a += PGSIZE;
    80001048:	6b85                	lui	s7,0x1
    if ((pte = walk(pagetable, a, 1)) == 0)
    8000104a:	865a                	mv	a2,s6
    8000104c:	85a6                	mv	a1,s1
    8000104e:	8552                	mv	a0,s4
    80001050:	ef1ff0ef          	jal	80000f40 <walk>
    80001054:	c929                	beqz	a0,800010a6 <mappages+0x96>
    if (*pte & PTE_V)
    80001056:	611c                	ld	a5,0(a0)
    80001058:	8b85                	andi	a5,a5,1
    8000105a:	e3a1                	bnez	a5,8000109a <mappages+0x8a>
    *pte = PA2PTE(pa) | perm | PTE_V;
    8000105c:	013487b3          	add	a5,s1,s3
    80001060:	83b1                	srli	a5,a5,0xc
    80001062:	07aa                	slli	a5,a5,0xa
    80001064:	0157e7b3          	or	a5,a5,s5
    80001068:	0017e793          	ori	a5,a5,1
    8000106c:	e11c                	sd	a5,0(a0)
    if (a == last)
    8000106e:	05248863          	beq	s1,s2,800010be <mappages+0xae>
    a += PGSIZE;
    80001072:	94de                	add	s1,s1,s7
    if ((pte = walk(pagetable, a, 1)) == 0)
    80001074:	bfd9                	j	8000104a <mappages+0x3a>
    panic("mappages: va not aligned");
    80001076:	00006517          	auipc	a0,0x6
    8000107a:	04250513          	addi	a0,a0,66 # 800070b8 <etext+0xb8>
    8000107e:	fcaff0ef          	jal	80000848 <panic>
    panic("mappages: size not aligned");
    80001082:	00006517          	auipc	a0,0x6
    80001086:	05650513          	addi	a0,a0,86 # 800070d8 <etext+0xd8>
    8000108a:	fbeff0ef          	jal	80000848 <panic>
    panic("mappages: size");
    8000108e:	00006517          	auipc	a0,0x6
    80001092:	06a50513          	addi	a0,a0,106 # 800070f8 <etext+0xf8>
    80001096:	fb2ff0ef          	jal	80000848 <panic>
      panic("mappages: remap");
    8000109a:	00006517          	auipc	a0,0x6
    8000109e:	06e50513          	addi	a0,a0,110 # 80007108 <etext+0x108>
    800010a2:	fa6ff0ef          	jal	80000848 <panic>
      return -1;
    800010a6:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    800010a8:	60a6                	ld	ra,72(sp)
    800010aa:	6406                	ld	s0,64(sp)
    800010ac:	74e2                	ld	s1,56(sp)
    800010ae:	7942                	ld	s2,48(sp)
    800010b0:	79a2                	ld	s3,40(sp)
    800010b2:	7a02                	ld	s4,32(sp)
    800010b4:	6ae2                	ld	s5,24(sp)
    800010b6:	6b42                	ld	s6,16(sp)
    800010b8:	6ba2                	ld	s7,8(sp)
    800010ba:	6161                	addi	sp,sp,80
    800010bc:	8082                	ret
  return 0;
    800010be:	4501                	li	a0,0
    800010c0:	b7e5                	j	800010a8 <mappages+0x98>

00000000800010c2 <kvmmap>:
{
    800010c2:	1141                	addi	sp,sp,-16
    800010c4:	e406                	sd	ra,8(sp)
    800010c6:	e022                	sd	s0,0(sp)
    800010c8:	0800                	addi	s0,sp,16
    800010ca:	87b6                	mv	a5,a3
  if (mappages(kpgtbl, va, sz, pa, perm) != 0)
    800010cc:	86b2                	mv	a3,a2
    800010ce:	863e                	mv	a2,a5
    800010d0:	f41ff0ef          	jal	80001010 <mappages>
    800010d4:	e509                	bnez	a0,800010de <kvmmap+0x1c>
}
    800010d6:	60a2                	ld	ra,8(sp)
    800010d8:	6402                	ld	s0,0(sp)
    800010da:	0141                	addi	sp,sp,16
    800010dc:	8082                	ret
    panic("kvmmap");
    800010de:	00006517          	auipc	a0,0x6
    800010e2:	03a50513          	addi	a0,a0,58 # 80007118 <etext+0x118>
    800010e6:	f62ff0ef          	jal	80000848 <panic>

00000000800010ea <kvmmake>:
{
    800010ea:	1101                	addi	sp,sp,-32
    800010ec:	ec06                	sd	ra,24(sp)
    800010ee:	e822                	sd	s0,16(sp)
    800010f0:	e426                	sd	s1,8(sp)
    800010f2:	e04a                	sd	s2,0(sp)
    800010f4:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t)kalloc();
    800010f6:	a29ff0ef          	jal	80000b1e <kalloc>
    800010fa:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    800010fc:	6605                	lui	a2,0x1
    800010fe:	4581                	li	a1,0
    80001100:	bb5ff0ef          	jal	80000cb4 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001104:	4719                	li	a4,6
    80001106:	6685                	lui	a3,0x1
    80001108:	10000637          	lui	a2,0x10000
    8000110c:	85b2                	mv	a1,a2
    8000110e:	8526                	mv	a0,s1
    80001110:	fb3ff0ef          	jal	800010c2 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001114:	4719                	li	a4,6
    80001116:	6685                	lui	a3,0x1
    80001118:	10001637          	lui	a2,0x10001
    8000111c:	85b2                	mv	a1,a2
    8000111e:	8526                	mv	a0,s1
    80001120:	fa3ff0ef          	jal	800010c2 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    80001124:	4719                	li	a4,6
    80001126:	040006b7          	lui	a3,0x4000
    8000112a:	0c000637          	lui	a2,0xc000
    8000112e:	85b2                	mv	a1,a2
    80001130:	8526                	mv	a0,s1
    80001132:	f91ff0ef          	jal	800010c2 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext - KERNBASE, PTE_R | PTE_X);
    80001136:	00006917          	auipc	s2,0x6
    8000113a:	eca90913          	addi	s2,s2,-310 # 80007000 <etext>
    8000113e:	4729                	li	a4,10
    80001140:	800006b7          	lui	a3,0x80000
    80001144:	96ca                	add	a3,a3,s2
    80001146:	4605                	li	a2,1
    80001148:	067e                	slli	a2,a2,0x1f
    8000114a:	85b2                	mv	a1,a2
    8000114c:	8526                	mv	a0,s1
    8000114e:	f75ff0ef          	jal	800010c2 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP - (uint64)etext,
    80001152:	4719                	li	a4,6
    80001154:	46c5                	li	a3,17
    80001156:	06ee                	slli	a3,a3,0x1b
    80001158:	412686b3          	sub	a3,a3,s2
    8000115c:	864a                	mv	a2,s2
    8000115e:	85ca                	mv	a1,s2
    80001160:	8526                	mv	a0,s1
    80001162:	f61ff0ef          	jal	800010c2 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80001166:	4729                	li	a4,10
    80001168:	6685                	lui	a3,0x1
    8000116a:	00005617          	auipc	a2,0x5
    8000116e:	e9660613          	addi	a2,a2,-362 # 80006000 <_trampoline>
    80001172:	040005b7          	lui	a1,0x4000
    80001176:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001178:	05b2                	slli	a1,a1,0xc
    8000117a:	8526                	mv	a0,s1
    8000117c:	f47ff0ef          	jal	800010c2 <kvmmap>
  proc_mapstacks(kpgtbl);
    80001180:	8526                	mv	a0,s1
    80001182:	5e0000ef          	jal	80001762 <proc_mapstacks>
}
    80001186:	8526                	mv	a0,s1
    80001188:	60e2                	ld	ra,24(sp)
    8000118a:	6442                	ld	s0,16(sp)
    8000118c:	64a2                	ld	s1,8(sp)
    8000118e:	6902                	ld	s2,0(sp)
    80001190:	6105                	addi	sp,sp,32
    80001192:	8082                	ret

0000000080001194 <kvminit>:
{
    80001194:	1141                	addi	sp,sp,-16
    80001196:	e406                	sd	ra,8(sp)
    80001198:	e022                	sd	s0,0(sp)
    8000119a:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    8000119c:	f4fff0ef          	jal	800010ea <kvmmake>
    800011a0:	00009797          	auipc	a5,0x9
    800011a4:	14a7b823          	sd	a0,336(a5) # 8000a2f0 <kernel_pagetable>
}
    800011a8:	60a2                	ld	ra,8(sp)
    800011aa:	6402                	ld	s0,0(sp)
    800011ac:	0141                	addi	sp,sp,16
    800011ae:	8082                	ret

00000000800011b0 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    800011b0:	1101                	addi	sp,sp,-32
    800011b2:	ec06                	sd	ra,24(sp)
    800011b4:	e822                	sd	s0,16(sp)
    800011b6:	e426                	sd	s1,8(sp)
    800011b8:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t)kalloc();
    800011ba:	965ff0ef          	jal	80000b1e <kalloc>
    800011be:	84aa                	mv	s1,a0
  if (pagetable == 0)
    800011c0:	c509                	beqz	a0,800011ca <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    800011c2:	6605                	lui	a2,0x1
    800011c4:	4581                	li	a1,0
    800011c6:	aefff0ef          	jal	80000cb4 <memset>
  return pagetable;
}
    800011ca:	8526                	mv	a0,s1
    800011cc:	60e2                	ld	ra,24(sp)
    800011ce:	6442                	ld	s0,16(sp)
    800011d0:	64a2                	ld	s1,8(sp)
    800011d2:	6105                	addi	sp,sp,32
    800011d4:	8082                	ret

00000000800011d6 <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    800011d6:	7139                	addi	sp,sp,-64
    800011d8:	fc06                	sd	ra,56(sp)
    800011da:	f822                	sd	s0,48(sp)
    800011dc:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    800011de:	03459793          	slli	a5,a1,0x34
    800011e2:	e38d                	bnez	a5,80001204 <uvmunmap+0x2e>
    800011e4:	f04a                	sd	s2,32(sp)
    800011e6:	ec4e                	sd	s3,24(sp)
    800011e8:	e852                	sd	s4,16(sp)
    800011ea:	e456                	sd	s5,8(sp)
    800011ec:	e05a                	sd	s6,0(sp)
    800011ee:	8a2a                	mv	s4,a0
    800011f0:	892e                	mv	s2,a1
    800011f2:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    800011f4:	0632                	slli	a2,a2,0xc
    800011f6:	00b609b3          	add	s3,a2,a1
    800011fa:	6b05                	lui	s6,0x1
    800011fc:	0535f963          	bgeu	a1,s3,8000124e <uvmunmap+0x78>
    80001200:	f426                	sd	s1,40(sp)
    80001202:	a015                	j	80001226 <uvmunmap+0x50>
    80001204:	f426                	sd	s1,40(sp)
    80001206:	f04a                	sd	s2,32(sp)
    80001208:	ec4e                	sd	s3,24(sp)
    8000120a:	e852                	sd	s4,16(sp)
    8000120c:	e456                	sd	s5,8(sp)
    8000120e:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    80001210:	00006517          	auipc	a0,0x6
    80001214:	f1050513          	addi	a0,a0,-240 # 80007120 <etext+0x120>
    80001218:	e30ff0ef          	jal	80000848 <panic>
      continue;
    if (do_free) {
      uint64 pa = PTE2PA(*pte);
      kfree((void *)pa);
    }
    *pte = 0;
    8000121c:	0004b023          	sd	zero,0(s1)
  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    80001220:	995a                	add	s2,s2,s6
    80001222:	03397563          	bgeu	s2,s3,8000124c <uvmunmap+0x76>
    if ((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    80001226:	4601                	li	a2,0
    80001228:	85ca                	mv	a1,s2
    8000122a:	8552                	mv	a0,s4
    8000122c:	d15ff0ef          	jal	80000f40 <walk>
    80001230:	84aa                	mv	s1,a0
    80001232:	d57d                	beqz	a0,80001220 <uvmunmap+0x4a>
    if ((*pte & PTE_V) == 0) // has physical page been allocated?
    80001234:	611c                	ld	a5,0(a0)
    80001236:	0017f713          	andi	a4,a5,1
    8000123a:	d37d                	beqz	a4,80001220 <uvmunmap+0x4a>
    if (do_free) {
    8000123c:	fe0a80e3          	beqz	s5,8000121c <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    80001240:	83a9                	srli	a5,a5,0xa
      kfree((void *)pa);
    80001242:	00c79513          	slli	a0,a5,0xc
    80001246:	ff0ff0ef          	jal	80000a36 <kfree>
    8000124a:	bfc9                	j	8000121c <uvmunmap+0x46>
    8000124c:	74a2                	ld	s1,40(sp)
    8000124e:	7902                	ld	s2,32(sp)
    80001250:	69e2                	ld	s3,24(sp)
    80001252:	6a42                	ld	s4,16(sp)
    80001254:	6aa2                	ld	s5,8(sp)
    80001256:	6b02                	ld	s6,0(sp)
  }
}
    80001258:	70e2                	ld	ra,56(sp)
    8000125a:	7442                	ld	s0,48(sp)
    8000125c:	6121                	addi	sp,sp,64
    8000125e:	8082                	ret

0000000080001260 <uvmdealloc>:
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
  if (newsz >= oldsz)
    80001260:	04b67163          	bgeu	a2,a1,800012a2 <uvmdealloc+0x42>
{
    80001264:	1101                	addi	sp,sp,-32
    80001266:	ec06                	sd	ra,24(sp)
    80001268:	e822                	sd	s0,16(sp)
    8000126a:	e426                	sd	s1,8(sp)
    8000126c:	1000                	addi	s0,sp,32
    8000126e:	84b2                	mv	s1,a2
    return oldsz;

  if (PGROUNDUP(newsz) < PGROUNDUP(oldsz)) {
    80001270:	6785                	lui	a5,0x1
    80001272:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001274:	00f60733          	add	a4,a2,a5
    80001278:	76fd                	lui	a3,0xfffff
    8000127a:	8f75                	and	a4,a4,a3
    8000127c:	97ae                	add	a5,a5,a1
    8000127e:	8ff5                	and	a5,a5,a3
    80001280:	00f76863          	bltu	a4,a5,80001290 <uvmdealloc+0x30>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
    80001284:	8526                	mv	a0,s1
}
    80001286:	60e2                	ld	ra,24(sp)
    80001288:	6442                	ld	s0,16(sp)
    8000128a:	64a2                	ld	s1,8(sp)
    8000128c:	6105                	addi	sp,sp,32
    8000128e:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    80001290:	8f99                	sub	a5,a5,a4
    80001292:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    80001294:	4685                	li	a3,1
    80001296:	0007861b          	sext.w	a2,a5
    8000129a:	85ba                	mv	a1,a4
    8000129c:	f3bff0ef          	jal	800011d6 <uvmunmap>
    800012a0:	b7d5                	j	80001284 <uvmdealloc+0x24>
    return oldsz;
    800012a2:	852e                	mv	a0,a1
}
    800012a4:	8082                	ret

00000000800012a6 <uvmalloc>:
  if (newsz < oldsz)
    800012a6:	08b66e63          	bltu	a2,a1,80001342 <uvmalloc+0x9c>
{
    800012aa:	715d                	addi	sp,sp,-80
    800012ac:	e486                	sd	ra,72(sp)
    800012ae:	e0a2                	sd	s0,64(sp)
    800012b0:	f052                	sd	s4,32(sp)
    800012b2:	ec56                	sd	s5,24(sp)
    800012b4:	e45e                	sd	s7,8(sp)
    800012b6:	0880                	addi	s0,sp,80
    800012b8:	8aaa                	mv	s5,a0
    800012ba:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800012bc:	6785                	lui	a5,0x1
    800012be:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800012c0:	95be                	add	a1,a1,a5
    800012c2:	77fd                	lui	a5,0xfffff
    800012c4:	8fed                	and	a5,a5,a1
    800012c6:	8bbe                	mv	s7,a5
  for (a = oldsz; a < newsz; a += PGSIZE) {
    800012c8:	04c7f163          	bgeu	a5,a2,8000130a <uvmalloc+0x64>
    800012cc:	fc26                	sd	s1,56(sp)
    800012ce:	f84a                	sd	s2,48(sp)
    800012d0:	f44e                	sd	s3,40(sp)
    800012d2:	e85a                	sd	s6,16(sp)
    800012d4:	893e                	mv	s2,a5
    memset(mem, 0, PGSIZE);
    800012d6:	6985                	lui	s3,0x1
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    800012d8:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800012dc:	843ff0ef          	jal	80000b1e <kalloc>
    800012e0:	84aa                	mv	s1,a0
    if (mem == 0) {
    800012e2:	c515                	beqz	a0,8000130e <uvmalloc+0x68>
    memset(mem, 0, PGSIZE);
    800012e4:	864e                	mv	a2,s3
    800012e6:	4581                	li	a1,0
    800012e8:	9cdff0ef          	jal	80000cb4 <memset>
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    800012ec:	875a                	mv	a4,s6
    800012ee:	86a6                	mv	a3,s1
    800012f0:	864e                	mv	a2,s3
    800012f2:	85ca                	mv	a1,s2
    800012f4:	8556                	mv	a0,s5
    800012f6:	d1bff0ef          	jal	80001010 <mappages>
    800012fa:	e91d                	bnez	a0,80001330 <uvmalloc+0x8a>
  for (a = oldsz; a < newsz; a += PGSIZE) {
    800012fc:	994e                	add	s2,s2,s3
    800012fe:	fd496fe3          	bltu	s2,s4,800012dc <uvmalloc+0x36>
    80001302:	74e2                	ld	s1,56(sp)
    80001304:	7942                	ld	s2,48(sp)
    80001306:	79a2                	ld	s3,40(sp)
    80001308:	6b42                	ld	s6,16(sp)
  return newsz;
    8000130a:	8552                	mv	a0,s4
    8000130c:	a819                	j	80001322 <uvmalloc+0x7c>
      uvmdealloc(pagetable, a, oldsz);
    8000130e:	865e                	mv	a2,s7
    80001310:	85ca                	mv	a1,s2
    80001312:	8556                	mv	a0,s5
    80001314:	f4dff0ef          	jal	80001260 <uvmdealloc>
      return 0;
    80001318:	4501                	li	a0,0
    8000131a:	74e2                	ld	s1,56(sp)
    8000131c:	7942                	ld	s2,48(sp)
    8000131e:	79a2                	ld	s3,40(sp)
    80001320:	6b42                	ld	s6,16(sp)
}
    80001322:	60a6                	ld	ra,72(sp)
    80001324:	6406                	ld	s0,64(sp)
    80001326:	7a02                	ld	s4,32(sp)
    80001328:	6ae2                	ld	s5,24(sp)
    8000132a:	6ba2                	ld	s7,8(sp)
    8000132c:	6161                	addi	sp,sp,80
    8000132e:	8082                	ret
      kfree(mem);
    80001330:	8526                	mv	a0,s1
    80001332:	f04ff0ef          	jal	80000a36 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80001336:	865e                	mv	a2,s7
    80001338:	85ca                	mv	a1,s2
    8000133a:	8556                	mv	a0,s5
    8000133c:	f25ff0ef          	jal	80001260 <uvmdealloc>
      return 0;
    80001340:	bfe1                	j	80001318 <uvmalloc+0x72>
    return oldsz;
    80001342:	852e                	mv	a0,a1
}
    80001344:	8082                	ret

0000000080001346 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    80001346:	7179                	addi	sp,sp,-48
    80001348:	f406                	sd	ra,40(sp)
    8000134a:	f022                	sd	s0,32(sp)
    8000134c:	ec26                	sd	s1,24(sp)
    8000134e:	e84a                	sd	s2,16(sp)
    80001350:	e44e                	sd	s3,8(sp)
    80001352:	1800                	addi	s0,sp,48
    80001354:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for (int i = 0; i < 512; i++) {
    80001356:	84aa                	mv	s1,a0
    80001358:	6905                	lui	s2,0x1
    8000135a:	992a                	add	s2,s2,a0
    8000135c:	a811                	j	80001370 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if (pte & PTE_V) {
      panic("freewalk: leaf");
    8000135e:	00006517          	auipc	a0,0x6
    80001362:	dda50513          	addi	a0,a0,-550 # 80007138 <etext+0x138>
    80001366:	ce2ff0ef          	jal	80000848 <panic>
  for (int i = 0; i < 512; i++) {
    8000136a:	04a1                	addi	s1,s1,8
    8000136c:	03248163          	beq	s1,s2,8000138e <freewalk+0x48>
    pte_t pte = pagetable[i];
    80001370:	609c                	ld	a5,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    80001372:	0017f713          	andi	a4,a5,1
    80001376:	db75                	beqz	a4,8000136a <freewalk+0x24>
    80001378:	00e7f713          	andi	a4,a5,14
    8000137c:	f36d                	bnez	a4,8000135e <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    8000137e:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    80001380:	00c79513          	slli	a0,a5,0xc
    80001384:	fc3ff0ef          	jal	80001346 <freewalk>
      pagetable[i] = 0;
    80001388:	0004b023          	sd	zero,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    8000138c:	bff9                	j	8000136a <freewalk+0x24>
    }
  }
  kfree((void *)pagetable);
    8000138e:	854e                	mv	a0,s3
    80001390:	ea6ff0ef          	jal	80000a36 <kfree>
}
    80001394:	70a2                	ld	ra,40(sp)
    80001396:	7402                	ld	s0,32(sp)
    80001398:	64e2                	ld	s1,24(sp)
    8000139a:	6942                	ld	s2,16(sp)
    8000139c:	69a2                	ld	s3,8(sp)
    8000139e:	6145                	addi	sp,sp,48
    800013a0:	8082                	ret

00000000800013a2 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800013a2:	1101                	addi	sp,sp,-32
    800013a4:	ec06                	sd	ra,24(sp)
    800013a6:	e822                	sd	s0,16(sp)
    800013a8:	e426                	sd	s1,8(sp)
    800013aa:	1000                	addi	s0,sp,32
    800013ac:	84aa                	mv	s1,a0
  if (sz > 0)
    800013ae:	e989                	bnez	a1,800013c0 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
  freewalk(pagetable);
    800013b0:	8526                	mv	a0,s1
    800013b2:	f95ff0ef          	jal	80001346 <freewalk>
}
    800013b6:	60e2                	ld	ra,24(sp)
    800013b8:	6442                	ld	s0,16(sp)
    800013ba:	64a2                	ld	s1,8(sp)
    800013bc:	6105                	addi	sp,sp,32
    800013be:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
    800013c0:	6785                	lui	a5,0x1
    800013c2:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800013c4:	95be                	add	a1,a1,a5
    800013c6:	4685                	li	a3,1
    800013c8:	00c5d613          	srli	a2,a1,0xc
    800013cc:	4581                	li	a1,0
    800013ce:	e09ff0ef          	jal	800011d6 <uvmunmap>
    800013d2:	bff9                	j	800013b0 <uvmfree+0xe>

00000000800013d4 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for (i = 0; i < sz; i += PGSIZE) {
    800013d4:	ca59                	beqz	a2,8000146a <uvmcopy+0x96>
{
    800013d6:	715d                	addi	sp,sp,-80
    800013d8:	e486                	sd	ra,72(sp)
    800013da:	e0a2                	sd	s0,64(sp)
    800013dc:	fc26                	sd	s1,56(sp)
    800013de:	f84a                	sd	s2,48(sp)
    800013e0:	f44e                	sd	s3,40(sp)
    800013e2:	f052                	sd	s4,32(sp)
    800013e4:	ec56                	sd	s5,24(sp)
    800013e6:	e85a                	sd	s6,16(sp)
    800013e8:	e45e                	sd	s7,8(sp)
    800013ea:	0880                	addi	s0,sp,80
    800013ec:	8b2a                	mv	s6,a0
    800013ee:	8bae                	mv	s7,a1
    800013f0:	8ab2                	mv	s5,a2
  for (i = 0; i < sz; i += PGSIZE) {
    800013f2:	4481                	li	s1,0
      continue; // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if ((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char *)pa, PGSIZE);
    800013f4:	6a05                	lui	s4,0x1
    800013f6:	a021                	j	800013fe <uvmcopy+0x2a>
  for (i = 0; i < sz; i += PGSIZE) {
    800013f8:	94d2                	add	s1,s1,s4
    800013fa:	0554fc63          	bgeu	s1,s5,80001452 <uvmcopy+0x7e>
    if ((pte = walk(old, i, 0)) == 0)
    800013fe:	4601                	li	a2,0
    80001400:	85a6                	mv	a1,s1
    80001402:	855a                	mv	a0,s6
    80001404:	b3dff0ef          	jal	80000f40 <walk>
    80001408:	d965                	beqz	a0,800013f8 <uvmcopy+0x24>
    if ((*pte & PTE_V) == 0)
    8000140a:	00053983          	ld	s3,0(a0)
    8000140e:	0019f793          	andi	a5,s3,1
    80001412:	d3fd                	beqz	a5,800013f8 <uvmcopy+0x24>
    if ((mem = kalloc()) == 0)
    80001414:	f0aff0ef          	jal	80000b1e <kalloc>
    80001418:	892a                	mv	s2,a0
    8000141a:	c11d                	beqz	a0,80001440 <uvmcopy+0x6c>
    pa = PTE2PA(*pte);
    8000141c:	00a9d593          	srli	a1,s3,0xa
    memmove(mem, (char *)pa, PGSIZE);
    80001420:	8652                	mv	a2,s4
    80001422:	05b2                	slli	a1,a1,0xc
    80001424:	8edff0ef          	jal	80000d10 <memmove>
    if (mappages(new, i, PGSIZE, (uint64)mem, flags) != 0) {
    80001428:	3ff9f713          	andi	a4,s3,1023
    8000142c:	86ca                	mv	a3,s2
    8000142e:	8652                	mv	a2,s4
    80001430:	85a6                	mv	a1,s1
    80001432:	855e                	mv	a0,s7
    80001434:	bddff0ef          	jal	80001010 <mappages>
    80001438:	d161                	beqz	a0,800013f8 <uvmcopy+0x24>
      kfree(mem);
    8000143a:	854a                	mv	a0,s2
    8000143c:	dfaff0ef          	jal	80000a36 <kfree>
    }
  }
  return 0;

err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80001440:	4685                	li	a3,1
    80001442:	00c4d613          	srli	a2,s1,0xc
    80001446:	4581                	li	a1,0
    80001448:	855e                	mv	a0,s7
    8000144a:	d8dff0ef          	jal	800011d6 <uvmunmap>
  return -1;
    8000144e:	557d                	li	a0,-1
    80001450:	a011                	j	80001454 <uvmcopy+0x80>
  return 0;
    80001452:	4501                	li	a0,0
}
    80001454:	60a6                	ld	ra,72(sp)
    80001456:	6406                	ld	s0,64(sp)
    80001458:	74e2                	ld	s1,56(sp)
    8000145a:	7942                	ld	s2,48(sp)
    8000145c:	79a2                	ld	s3,40(sp)
    8000145e:	7a02                	ld	s4,32(sp)
    80001460:	6ae2                	ld	s5,24(sp)
    80001462:	6b42                	ld	s6,16(sp)
    80001464:	6ba2                	ld	s7,8(sp)
    80001466:	6161                	addi	sp,sp,80
    80001468:	8082                	ret
  return 0;
    8000146a:	4501                	li	a0,0
}
    8000146c:	8082                	ret

000000008000146e <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    8000146e:	1141                	addi	sp,sp,-16
    80001470:	e406                	sd	ra,8(sp)
    80001472:	e022                	sd	s0,0(sp)
    80001474:	0800                	addi	s0,sp,16
  pte_t *pte;

  pte = walk(pagetable, va, 0);
    80001476:	4601                	li	a2,0
    80001478:	ac9ff0ef          	jal	80000f40 <walk>
  if (pte == 0)
    8000147c:	c901                	beqz	a0,8000148c <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    8000147e:	611c                	ld	a5,0(a0)
    80001480:	9bbd                	andi	a5,a5,-17
    80001482:	e11c                	sd	a5,0(a0)
}
    80001484:	60a2                	ld	ra,8(sp)
    80001486:	6402                	ld	s0,0(sp)
    80001488:	0141                	addi	sp,sp,16
    8000148a:	8082                	ret
    panic("uvmclear");
    8000148c:	00006517          	auipc	a0,0x6
    80001490:	cbc50513          	addi	a0,a0,-836 # 80007148 <etext+0x148>
    80001494:	bb4ff0ef          	jal	80000848 <panic>

0000000080001498 <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    80001498:	1141                	addi	sp,sp,-16
    8000149a:	e406                	sd	ra,8(sp)
    8000149c:	e022                	sd	s0,0(sp)
    8000149e:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    800014a0:	4601                	li	a2,0
    800014a2:	a9fff0ef          	jal	80000f40 <walk>
  if (pte == 0) {
    800014a6:	c119                	beqz	a0,800014ac <ismapped+0x14>
    return 0;
  }
  if (*pte & PTE_V) {
    800014a8:	6108                	ld	a0,0(a0)
    800014aa:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    800014ac:	60a2                	ld	ra,8(sp)
    800014ae:	6402                	ld	s0,0(sp)
    800014b0:	0141                	addi	sp,sp,16
    800014b2:	8082                	ret

00000000800014b4 <vmfault>:
{
    800014b4:	7179                	addi	sp,sp,-48
    800014b6:	f406                	sd	ra,40(sp)
    800014b8:	f022                	sd	s0,32(sp)
    800014ba:	e052                	sd	s4,0(sp)
    800014bc:	1800                	addi	s0,sp,48
  if (va >= psz)
    800014be:	00b66d63          	bltu	a2,a1,800014d8 <vmfault+0x24>
    return 0;
    800014c2:	4a01                	li	s4,0
}
    800014c4:	8552                	mv	a0,s4
    800014c6:	70a2                	ld	ra,40(sp)
    800014c8:	7402                	ld	s0,32(sp)
    800014ca:	6a02                	ld	s4,0(sp)
    800014cc:	6145                	addi	sp,sp,48
    800014ce:	8082                	ret
    800014d0:	64e2                	ld	s1,24(sp)
    800014d2:	6942                	ld	s2,16(sp)
    800014d4:	69a2                	ld	s3,8(sp)
    800014d6:	b7f5                	j	800014c2 <vmfault+0xe>
    800014d8:	e84a                	sd	s2,16(sp)
    800014da:	e44e                	sd	s3,8(sp)
  va = PGROUNDDOWN(va);
    800014dc:	77fd                	lui	a5,0xfffff
    800014de:	00f67933          	and	s2,a2,a5
  if (ismapped(pagetable, va)) {
    800014e2:	85ca                	mv	a1,s2
    800014e4:	89aa                	mv	s3,a0
    800014e6:	fb3ff0ef          	jal	80001498 <ismapped>
    800014ea:	c501                	beqz	a0,800014f2 <vmfault+0x3e>
    800014ec:	6942                	ld	s2,16(sp)
    800014ee:	69a2                	ld	s3,8(sp)
    800014f0:	bfc9                	j	800014c2 <vmfault+0xe>
    800014f2:	ec26                	sd	s1,24(sp)
  mem = (uint64)kalloc();
    800014f4:	e2aff0ef          	jal	80000b1e <kalloc>
    800014f8:	84aa                	mv	s1,a0
  if (mem == 0)
    800014fa:	d979                	beqz	a0,800014d0 <vmfault+0x1c>
  mem = (uint64)kalloc();
    800014fc:	8a2a                	mv	s4,a0
  memset((void *)mem, 0, PGSIZE);
    800014fe:	6605                	lui	a2,0x1
    80001500:	4581                	li	a1,0
    80001502:	fb2ff0ef          	jal	80000cb4 <memset>
  if (mappages(pagetable, va, PGSIZE, mem, PTE_W | PTE_U | PTE_R) != 0) {
    80001506:	4759                	li	a4,22
    80001508:	86a6                	mv	a3,s1
    8000150a:	6605                	lui	a2,0x1
    8000150c:	85ca                	mv	a1,s2
    8000150e:	854e                	mv	a0,s3
    80001510:	b01ff0ef          	jal	80001010 <mappages>
    80001514:	e509                	bnez	a0,8000151e <vmfault+0x6a>
    80001516:	64e2                	ld	s1,24(sp)
    80001518:	6942                	ld	s2,16(sp)
    8000151a:	69a2                	ld	s3,8(sp)
    8000151c:	b765                	j	800014c4 <vmfault+0x10>
    kfree((void *)mem);
    8000151e:	8526                	mv	a0,s1
    80001520:	d16ff0ef          	jal	80000a36 <kfree>
    return 0;
    80001524:	64e2                	ld	s1,24(sp)
    80001526:	6942                	ld	s2,16(sp)
    80001528:	69a2                	ld	s3,8(sp)
    8000152a:	bf61                	j	800014c2 <vmfault+0xe>

000000008000152c <copyout>:
  while (len > 0) {
    8000152c:	cf55                	beqz	a4,800015e8 <copyout+0xbc>
{
    8000152e:	7159                	addi	sp,sp,-112
    80001530:	f486                	sd	ra,104(sp)
    80001532:	f0a2                	sd	s0,96(sp)
    80001534:	eca6                	sd	s1,88(sp)
    80001536:	e8ca                	sd	s2,80(sp)
    80001538:	e4ce                	sd	s3,72(sp)
    8000153a:	e0d2                	sd	s4,64(sp)
    8000153c:	fc56                	sd	s5,56(sp)
    8000153e:	f85a                	sd	s6,48(sp)
    80001540:	f45e                	sd	s7,40(sp)
    80001542:	f062                	sd	s8,32(sp)
    80001544:	ec66                	sd	s9,24(sp)
    80001546:	e86a                	sd	s10,16(sp)
    80001548:	e46e                	sd	s11,8(sp)
    8000154a:	1880                	addi	s0,sp,112
    8000154c:	8baa                	mv	s7,a0
    8000154e:	8dae                	mv	s11,a1
    80001550:	84b2                	mv	s1,a2
    80001552:	8b36                	mv	s6,a3
    80001554:	8aba                	mv	s5,a4
    va0 = PGROUNDDOWN(dstva);
    80001556:	7d7d                	lui	s10,0xfffff
    if (va0 >= MAXVA)
    80001558:	5cfd                	li	s9,-1
    8000155a:	01acdc93          	srli	s9,s9,0x1a
    n = PGSIZE - (dstva - va0);
    8000155e:	6c05                	lui	s8,0x1
    80001560:	a089                	j	800015a2 <copyout+0x76>
      return -1;
    80001562:	557d                	li	a0,-1
}
    80001564:	70a6                	ld	ra,104(sp)
    80001566:	7406                	ld	s0,96(sp)
    80001568:	64e6                	ld	s1,88(sp)
    8000156a:	6946                	ld	s2,80(sp)
    8000156c:	69a6                	ld	s3,72(sp)
    8000156e:	6a06                	ld	s4,64(sp)
    80001570:	7ae2                	ld	s5,56(sp)
    80001572:	7b42                	ld	s6,48(sp)
    80001574:	7ba2                	ld	s7,40(sp)
    80001576:	7c02                	ld	s8,32(sp)
    80001578:	6ce2                	ld	s9,24(sp)
    8000157a:	6d42                	ld	s10,16(sp)
    8000157c:	6da2                	ld	s11,8(sp)
    8000157e:	6165                	addi	sp,sp,112
    80001580:	8082                	ret
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001582:	03449513          	slli	a0,s1,0x34
    80001586:	9151                	srli	a0,a0,0x34
    80001588:	0009061b          	sext.w	a2,s2
    8000158c:	85da                	mv	a1,s6
    8000158e:	954e                	add	a0,a0,s3
    80001590:	f80ff0ef          	jal	80000d10 <memmove>
    len -= n;
    80001594:	412a8ab3          	sub	s5,s5,s2
    src += n;
    80001598:	9b4a                	add	s6,s6,s2
    dstva = va0 + PGSIZE;
    8000159a:	018a04b3          	add	s1,s4,s8
  while (len > 0) {
    8000159e:	040a8363          	beqz	s5,800015e4 <copyout+0xb8>
    va0 = PGROUNDDOWN(dstva);
    800015a2:	01a4fa33          	and	s4,s1,s10
    if (va0 >= MAXVA)
    800015a6:	fb4ceee3          	bltu	s9,s4,80001562 <copyout+0x36>
    pa0 = walkaddr(pagetable, va0);
    800015aa:	85d2                	mv	a1,s4
    800015ac:	855e                	mv	a0,s7
    800015ae:	a2bff0ef          	jal	80000fd8 <walkaddr>
    800015b2:	89aa                	mv	s3,a0
    if (pa0 == 0) {
    800015b4:	e909                	bnez	a0,800015c6 <copyout+0x9a>
      if ((pa0 = vmfault(pagetable, psz, va0, 0)) == 0) {
    800015b6:	4681                	li	a3,0
    800015b8:	8652                	mv	a2,s4
    800015ba:	85ee                	mv	a1,s11
    800015bc:	855e                	mv	a0,s7
    800015be:	ef7ff0ef          	jal	800014b4 <vmfault>
    800015c2:	89aa                	mv	s3,a0
    800015c4:	dd59                	beqz	a0,80001562 <copyout+0x36>
    pte = walk(pagetable, va0, 0);
    800015c6:	4601                	li	a2,0
    800015c8:	85d2                	mv	a1,s4
    800015ca:	855e                	mv	a0,s7
    800015cc:	975ff0ef          	jal	80000f40 <walk>
    if ((*pte & PTE_W) == 0)
    800015d0:	611c                	ld	a5,0(a0)
    800015d2:	8b91                	andi	a5,a5,4
    800015d4:	d7d9                	beqz	a5,80001562 <copyout+0x36>
    n = PGSIZE - (dstva - va0);
    800015d6:	409a0933          	sub	s2,s4,s1
    800015da:	9962                	add	s2,s2,s8
    if (n > len)
    800015dc:	fb2af3e3          	bgeu	s5,s2,80001582 <copyout+0x56>
    800015e0:	8956                	mv	s2,s5
    800015e2:	b745                	j	80001582 <copyout+0x56>
  return 0;
    800015e4:	4501                	li	a0,0
    800015e6:	bfbd                	j	80001564 <copyout+0x38>
    800015e8:	4501                	li	a0,0
}
    800015ea:	8082                	ret

00000000800015ec <copyin>:
  while (len > 0) {
    800015ec:	cf49                	beqz	a4,80001686 <copyin+0x9a>
{
    800015ee:	711d                	addi	sp,sp,-96
    800015f0:	ec86                	sd	ra,88(sp)
    800015f2:	e8a2                	sd	s0,80(sp)
    800015f4:	e4a6                	sd	s1,72(sp)
    800015f6:	e0ca                	sd	s2,64(sp)
    800015f8:	fc4e                	sd	s3,56(sp)
    800015fa:	f852                	sd	s4,48(sp)
    800015fc:	f456                	sd	s5,40(sp)
    800015fe:	f05a                	sd	s6,32(sp)
    80001600:	ec5e                	sd	s7,24(sp)
    80001602:	e862                	sd	s8,16(sp)
    80001604:	e466                	sd	s9,8(sp)
    80001606:	e06a                	sd	s10,0(sp)
    80001608:	1080                	addi	s0,sp,96
    8000160a:	8baa                	mv	s7,a0
    8000160c:	8cae                	mv	s9,a1
    8000160e:	8ab2                	mv	s5,a2
    80001610:	84b6                	mv	s1,a3
    80001612:	89ba                	mv	s3,a4
    va0 = PGROUNDDOWN(srcva);
    80001614:	7c7d                	lui	s8,0xfffff
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    80001616:	4d05                	li	s10,1
    n = PGSIZE - (srcva - va0);
    80001618:	6b05                	lui	s6,0x1
    8000161a:	a03d                	j	80001648 <copyin+0x5c>
    8000161c:	409a0933          	sub	s2,s4,s1
    80001620:	995a                	add	s2,s2,s6
    if (n > len)
    80001622:	0129f363          	bgeu	s3,s2,80001628 <copyin+0x3c>
    80001626:	894e                	mv	s2,s3
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80001628:	03449593          	slli	a1,s1,0x34
    8000162c:	91d1                	srli	a1,a1,0x34
    8000162e:	0009061b          	sext.w	a2,s2
    80001632:	95aa                	add	a1,a1,a0
    80001634:	8556                	mv	a0,s5
    80001636:	edaff0ef          	jal	80000d10 <memmove>
    len -= n;
    8000163a:	412989b3          	sub	s3,s3,s2
    dst += n;
    8000163e:	9aca                	add	s5,s5,s2
    srcva = va0 + PGSIZE;
    80001640:	016a04b3          	add	s1,s4,s6
  while (len > 0) {
    80001644:	02098263          	beqz	s3,80001668 <copyin+0x7c>
    va0 = PGROUNDDOWN(srcva);
    80001648:	0184fa33          	and	s4,s1,s8
    pa0 = walkaddr(pagetable, va0);
    8000164c:	85d2                	mv	a1,s4
    8000164e:	855e                	mv	a0,s7
    80001650:	989ff0ef          	jal	80000fd8 <walkaddr>
    if (pa0 == 0) {
    80001654:	f561                	bnez	a0,8000161c <copyin+0x30>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    80001656:	86ea                	mv	a3,s10
    80001658:	8652                	mv	a2,s4
    8000165a:	85e6                	mv	a1,s9
    8000165c:	855e                	mv	a0,s7
    8000165e:	e57ff0ef          	jal	800014b4 <vmfault>
    80001662:	fd4d                	bnez	a0,8000161c <copyin+0x30>
        return -1;
    80001664:	557d                	li	a0,-1
    80001666:	a011                	j	8000166a <copyin+0x7e>
  return 0;
    80001668:	4501                	li	a0,0
}
    8000166a:	60e6                	ld	ra,88(sp)
    8000166c:	6446                	ld	s0,80(sp)
    8000166e:	64a6                	ld	s1,72(sp)
    80001670:	6906                	ld	s2,64(sp)
    80001672:	79e2                	ld	s3,56(sp)
    80001674:	7a42                	ld	s4,48(sp)
    80001676:	7aa2                	ld	s5,40(sp)
    80001678:	7b02                	ld	s6,32(sp)
    8000167a:	6be2                	ld	s7,24(sp)
    8000167c:	6c42                	ld	s8,16(sp)
    8000167e:	6ca2                	ld	s9,8(sp)
    80001680:	6d02                	ld	s10,0(sp)
    80001682:	6125                	addi	sp,sp,96
    80001684:	8082                	ret
  return 0;
    80001686:	4501                	li	a0,0
}
    80001688:	8082                	ret

000000008000168a <copyinstr>:
  while (got_null == 0 && max > 0) {
    8000168a:	c771                	beqz	a4,80001756 <copyinstr+0xcc>
{
    8000168c:	711d                	addi	sp,sp,-96
    8000168e:	ec86                	sd	ra,88(sp)
    80001690:	e8a2                	sd	s0,80(sp)
    80001692:	e4a6                	sd	s1,72(sp)
    80001694:	e0ca                	sd	s2,64(sp)
    80001696:	fc4e                	sd	s3,56(sp)
    80001698:	f852                	sd	s4,48(sp)
    8000169a:	f456                	sd	s5,40(sp)
    8000169c:	f05a                	sd	s6,32(sp)
    8000169e:	ec5e                	sd	s7,24(sp)
    800016a0:	e862                	sd	s8,16(sp)
    800016a2:	e466                	sd	s9,8(sp)
    800016a4:	1080                	addi	s0,sp,96
    800016a6:	8b2a                	mv	s6,a0
    800016a8:	8c2e                	mv	s8,a1
    800016aa:	8932                	mv	s2,a2
    800016ac:	84b6                	mv	s1,a3
    800016ae:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(srcva);
    800016b0:	7bfd                	lui	s7,0xfffff
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    800016b2:	4c85                	li	s9,1
    n = PGSIZE - (srcva - va0);
    800016b4:	6a85                	lui	s5,0x1
    800016b6:	a881                	j	80001706 <copyinstr+0x7c>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    800016b8:	86e6                	mv	a3,s9
    800016ba:	864e                	mv	a2,s3
    800016bc:	85e2                	mv	a1,s8
    800016be:	855a                	mv	a0,s6
    800016c0:	df5ff0ef          	jal	800014b4 <vmfault>
    800016c4:	e921                	bnez	a0,80001714 <copyinstr+0x8a>
        return -1;
    800016c6:	557d                	li	a0,-1
    800016c8:	a801                	j	800016d8 <copyinstr+0x4e>
        *dst = '\0';
    800016ca:	00078023          	sb	zero,0(a5) # fffffffffffff000 <end+0xffffffff7ffdb9d0>
        got_null = 1;
    800016ce:	4785                	li	a5,1
  if (got_null) {
    800016d0:	0017c793          	xori	a5,a5,1
    800016d4:	40f0053b          	negw	a0,a5
}
    800016d8:	60e6                	ld	ra,88(sp)
    800016da:	6446                	ld	s0,80(sp)
    800016dc:	64a6                	ld	s1,72(sp)
    800016de:	6906                	ld	s2,64(sp)
    800016e0:	79e2                	ld	s3,56(sp)
    800016e2:	7a42                	ld	s4,48(sp)
    800016e4:	7aa2                	ld	s5,40(sp)
    800016e6:	7b02                	ld	s6,32(sp)
    800016e8:	6be2                	ld	s7,24(sp)
    800016ea:	6c42                	ld	s8,16(sp)
    800016ec:	6ca2                	ld	s9,8(sp)
    800016ee:	6125                	addi	sp,sp,96
    800016f0:	8082                	ret
    800016f2:	fffa0713          	addi	a4,s4,-1 # fff <_entry-0x7ffff001>
    800016f6:	974a                	add	a4,a4,s2
      --max;
    800016f8:	40a70a33          	sub	s4,a4,a0
    srcva = va0 + PGSIZE;
    800016fc:	015984b3          	add	s1,s3,s5
  while (got_null == 0 && max > 0) {
    80001700:	04e50563          	beq	a0,a4,8000174a <copyinstr+0xc0>
{
    80001704:	893e                	mv	s2,a5
    va0 = PGROUNDDOWN(srcva);
    80001706:	0174f9b3          	and	s3,s1,s7
    pa0 = walkaddr(pagetable, va0);
    8000170a:	85ce                	mv	a1,s3
    8000170c:	855a                	mv	a0,s6
    8000170e:	8cbff0ef          	jal	80000fd8 <walkaddr>
    if (pa0 == 0) {
    80001712:	d15d                	beqz	a0,800016b8 <copyinstr+0x2e>
    n = PGSIZE - (srcva - va0);
    80001714:	40998633          	sub	a2,s3,s1
    80001718:	9656                	add	a2,a2,s5
    if (n > max)
    8000171a:	00ca7363          	bgeu	s4,a2,80001720 <copyinstr+0x96>
    8000171e:	8652                	mv	a2,s4
    while (n > 0) {
    80001720:	c61d                	beqz	a2,8000174e <copyinstr+0xc4>
    char *p = (char *)(pa0 + (srcva - va0));
    80001722:	03449593          	slli	a1,s1,0x34
    80001726:	91d1                	srli	a1,a1,0x34
    80001728:	95aa                	add	a1,a1,a0
    8000172a:	87ca                	mv	a5,s2
      if (*p == '\0') {
    8000172c:	412585b3          	sub	a1,a1,s2
    while (n > 0) {
    80001730:	964a                	add	a2,a2,s2
    80001732:	853e                	mv	a0,a5
      if (*p == '\0') {
    80001734:	00f58733          	add	a4,a1,a5
    80001738:	00074683          	lbu	a3,0(a4)
    8000173c:	d6d9                	beqz	a3,800016ca <copyinstr+0x40>
        *dst = *p;
    8000173e:	00d78023          	sb	a3,0(a5)
      dst++;
    80001742:	0785                	addi	a5,a5,1
    while (n > 0) {
    80001744:	fec797e3          	bne	a5,a2,80001732 <copyinstr+0xa8>
    80001748:	b76d                	j	800016f2 <copyinstr+0x68>
    srcva = va0 + PGSIZE;
    8000174a:	4781                	li	a5,0
    8000174c:	b751                	j	800016d0 <copyinstr+0x46>
    8000174e:	6485                	lui	s1,0x1
    80001750:	94ce                	add	s1,s1,s3
    80001752:	87ca                	mv	a5,s2
    80001754:	bf45                	j	80001704 <copyinstr+0x7a>
    80001756:	4781                	li	a5,0
  if (got_null) {
    80001758:	0017c793          	xori	a5,a5,1
    8000175c:	40f0053b          	negw	a0,a5
}
    80001760:	8082                	ret

0000000080001762 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80001762:	715d                	addi	sp,sp,-80
    80001764:	e486                	sd	ra,72(sp)
    80001766:	e0a2                	sd	s0,64(sp)
    80001768:	fc26                	sd	s1,56(sp)
    8000176a:	f84a                	sd	s2,48(sp)
    8000176c:	f44e                	sd	s3,40(sp)
    8000176e:	f052                	sd	s4,32(sp)
    80001770:	ec56                	sd	s5,24(sp)
    80001772:	e85a                	sd	s6,16(sp)
    80001774:	e45e                	sd	s7,8(sp)
    80001776:	0880                	addi	s0,sp,80
    80001778:	8aaa                	mv	s5,a0
    8000177a:	4481                	li	s1,0

  for (p = proc; p < &proc[NPROC]; p++) {
    char *pa = kalloc();
    if (pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int)(p - proc));
    8000177c:	000a57b7          	lui	a5,0xa5
    80001780:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    80001784:	07b2                	slli	a5,a5,0xc
    80001786:	fa578793          	addi	a5,a5,-91
    8000178a:	4fa50937          	lui	s2,0x4fa50
    8000178e:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    80001792:	1902                	slli	s2,s2,0x20
    80001794:	993e                	add	s2,s2,a5
    80001796:	040009b7          	lui	s3,0x4000
    8000179a:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    8000179c:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    8000179e:	4b99                	li	s7,6
    800017a0:	6b05                	lui	s6,0x1
  for (p = proc; p < &proc[NPROC]; p++) {
    800017a2:	6a19                	lui	s4,0x6
    800017a4:	a00a0a13          	addi	s4,s4,-1536 # 5a00 <_entry-0x7fffa600>
    char *pa = kalloc();
    800017a8:	b76ff0ef          	jal	80000b1e <kalloc>
    800017ac:	862a                	mv	a2,a0
    if (pa == 0)
    800017ae:	cd15                	beqz	a0,800017ea <proc_mapstacks+0x88>
    uint64 va = KSTACK((int)(p - proc));
    800017b0:	4034d593          	srai	a1,s1,0x3
    800017b4:	032585b3          	mul	a1,a1,s2
    800017b8:	05b6                	slli	a1,a1,0xd
    800017ba:	6789                	lui	a5,0x2
    800017bc:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017be:	875e                	mv	a4,s7
    800017c0:	86da                	mv	a3,s6
    800017c2:	40b985b3          	sub	a1,s3,a1
    800017c6:	8556                	mv	a0,s5
    800017c8:	8fbff0ef          	jal	800010c2 <kvmmap>
  for (p = proc; p < &proc[NPROC]; p++) {
    800017cc:	16848493          	addi	s1,s1,360 # 1168 <_entry-0x7fffee98>
    800017d0:	fd449ce3          	bne	s1,s4,800017a8 <proc_mapstacks+0x46>
  }
}
    800017d4:	60a6                	ld	ra,72(sp)
    800017d6:	6406                	ld	s0,64(sp)
    800017d8:	74e2                	ld	s1,56(sp)
    800017da:	7942                	ld	s2,48(sp)
    800017dc:	79a2                	ld	s3,40(sp)
    800017de:	7a02                	ld	s4,32(sp)
    800017e0:	6ae2                	ld	s5,24(sp)
    800017e2:	6b42                	ld	s6,16(sp)
    800017e4:	6ba2                	ld	s7,8(sp)
    800017e6:	6161                	addi	sp,sp,80
    800017e8:	8082                	ret
      panic("kalloc");
    800017ea:	00006517          	auipc	a0,0x6
    800017ee:	96e50513          	addi	a0,a0,-1682 # 80007158 <etext+0x158>
    800017f2:	856ff0ef          	jal	80000848 <panic>

00000000800017f6 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    800017f6:	7139                	addi	sp,sp,-64
    800017f8:	fc06                	sd	ra,56(sp)
    800017fa:	f822                	sd	s0,48(sp)
    800017fc:	f426                	sd	s1,40(sp)
    800017fe:	f04a                	sd	s2,32(sp)
    80001800:	ec4e                	sd	s3,24(sp)
    80001802:	e852                	sd	s4,16(sp)
    80001804:	e456                	sd	s5,8(sp)
    80001806:	e05a                	sd	s6,0(sp)
    80001808:	0080                	addi	s0,sp,64
  struct proc *p;

  initlock(&pid_lock, "nextpid");
    8000180a:	00006597          	auipc	a1,0x6
    8000180e:	95658593          	addi	a1,a1,-1706 # 80007160 <etext+0x160>
    80001812:	00011517          	auipc	a0,0x11
    80001816:	c0e50513          	addi	a0,a0,-1010 # 80012420 <pid_lock>
    8000181a:	b5eff0ef          	jal	80000b78 <initlock>
  initlock(&wait_lock, "wait_lock");
    8000181e:	00006597          	auipc	a1,0x6
    80001822:	94a58593          	addi	a1,a1,-1718 # 80007168 <etext+0x168>
    80001826:	00011517          	auipc	a0,0x11
    8000182a:	c1250513          	addi	a0,a0,-1006 # 80012438 <wait_lock>
    8000182e:	b4aff0ef          	jal	80000b78 <initlock>
    80001832:	4901                	li	s2,0
  for (p = proc; p < &proc[NPROC]; p++) {
    80001834:	00011497          	auipc	s1,0x11
    80001838:	01c48493          	addi	s1,s1,28 # 80012850 <proc>
    initlock(&p->lock, "proc");
    8000183c:	00006a97          	auipc	s5,0x6
    80001840:	93ca8a93          	addi	s5,s5,-1732 # 80007178 <etext+0x178>
    p->state = UNUSED;
    p->kstack = KSTACK((int)(p - proc));
    80001844:	000a57b7          	lui	a5,0xa5
    80001848:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    8000184c:	07b2                	slli	a5,a5,0xc
    8000184e:	fa578793          	addi	a5,a5,-91
    80001852:	4fa509b7          	lui	s3,0x4fa50
    80001856:	a4f98993          	addi	s3,s3,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    8000185a:	1982                	slli	s3,s3,0x20
    8000185c:	99be                	add	s3,s3,a5
    8000185e:	04000a37          	lui	s4,0x4000
    80001862:	1a7d                	addi	s4,s4,-1 # 3ffffff <_entry-0x7c000001>
    80001864:	0a32                	slli	s4,s4,0xc
  for (p = proc; p < &proc[NPROC]; p++) {
    80001866:	00017b17          	auipc	s6,0x17
    8000186a:	9eab0b13          	addi	s6,s6,-1558 # 80018250 <tickslock>
    initlock(&p->lock, "proc");
    8000186e:	85d6                	mv	a1,s5
    80001870:	8526                	mv	a0,s1
    80001872:	b06ff0ef          	jal	80000b78 <initlock>
    p->state = UNUSED;
    80001876:	0004ac23          	sw	zero,24(s1)
    p->kstack = KSTACK((int)(p - proc));
    8000187a:	40395793          	srai	a5,s2,0x3
    8000187e:	033787b3          	mul	a5,a5,s3
    80001882:	07b6                	slli	a5,a5,0xd
    80001884:	6709                	lui	a4,0x2
    80001886:	9fb9                	addw	a5,a5,a4
    80001888:	40fa07b3          	sub	a5,s4,a5
    8000188c:	e0bc                	sd	a5,64(s1)
  for (p = proc; p < &proc[NPROC]; p++) {
    8000188e:	16848493          	addi	s1,s1,360
    80001892:	16890913          	addi	s2,s2,360
    80001896:	fd649ce3          	bne	s1,s6,8000186e <procinit+0x78>
  }
}
    8000189a:	70e2                	ld	ra,56(sp)
    8000189c:	7442                	ld	s0,48(sp)
    8000189e:	74a2                	ld	s1,40(sp)
    800018a0:	7902                	ld	s2,32(sp)
    800018a2:	69e2                	ld	s3,24(sp)
    800018a4:	6a42                	ld	s4,16(sp)
    800018a6:	6aa2                	ld	s5,8(sp)
    800018a8:	6b02                	ld	s6,0(sp)
    800018aa:	6121                	addi	sp,sp,64
    800018ac:	8082                	ret

00000000800018ae <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    800018ae:	1141                	addi	sp,sp,-16
    800018b0:	e406                	sd	ra,8(sp)
    800018b2:	e022                	sd	s0,0(sp)
    800018b4:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r"(x));
    800018b6:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    800018b8:	2501                	sext.w	a0,a0
    800018ba:	60a2                	ld	ra,8(sp)
    800018bc:	6402                	ld	s0,0(sp)
    800018be:	0141                	addi	sp,sp,16
    800018c0:	8082                	ret

00000000800018c2 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu *
mycpu(void)
{
    800018c2:	1141                	addi	sp,sp,-16
    800018c4:	e406                	sd	ra,8(sp)
    800018c6:	e022                	sd	s0,0(sp)
    800018c8:	0800                	addi	s0,sp,16
    800018ca:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    800018cc:	2781                	sext.w	a5,a5
    800018ce:	079e                	slli	a5,a5,0x7
  return c;
}
    800018d0:	00011517          	auipc	a0,0x11
    800018d4:	b8050513          	addi	a0,a0,-1152 # 80012450 <cpus>
    800018d8:	953e                	add	a0,a0,a5
    800018da:	60a2                	ld	ra,8(sp)
    800018dc:	6402                	ld	s0,0(sp)
    800018de:	0141                	addi	sp,sp,16
    800018e0:	8082                	ret

00000000800018e2 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc *
myproc(void)
{
    800018e2:	1101                	addi	sp,sp,-32
    800018e4:	ec06                	sd	ra,24(sp)
    800018e6:	e822                	sd	s0,16(sp)
    800018e8:	e426                	sd	s1,8(sp)
    800018ea:	1000                	addi	s0,sp,32
  push_off();
    800018ec:	ad2ff0ef          	jal	80000bbe <push_off>
    800018f0:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    800018f2:	2781                	sext.w	a5,a5
    800018f4:	079e                	slli	a5,a5,0x7
    800018f6:	00011717          	auipc	a4,0x11
    800018fa:	b2a70713          	addi	a4,a4,-1238 # 80012420 <pid_lock>
    800018fe:	97ba                	add	a5,a5,a4
    80001900:	7b9c                	ld	a5,48(a5)
    80001902:	84be                	mv	s1,a5
  pop_off();
    80001904:	b30ff0ef          	jal	80000c34 <pop_off>
  return p;
}
    80001908:	8526                	mv	a0,s1
    8000190a:	60e2                	ld	ra,24(sp)
    8000190c:	6442                	ld	s0,16(sp)
    8000190e:	64a2                	ld	s1,8(sp)
    80001910:	6105                	addi	sp,sp,32
    80001912:	8082                	ret

0000000080001914 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001914:	7179                	addi	sp,sp,-48
    80001916:	f406                	sd	ra,40(sp)
    80001918:	f022                	sd	s0,32(sp)
    8000191a:	ec26                	sd	s1,24(sp)
    8000191c:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    8000191e:	fc5ff0ef          	jal	800018e2 <myproc>
    80001922:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    80001924:	b58ff0ef          	jal	80000c7c <release>

  if (__atomic_load_n(&first, __ATOMIC_ACQUIRE)) {
    80001928:	00009797          	auipc	a5,0x9
    8000192c:	98878793          	addi	a5,a5,-1656 # 8000a2b0 <first.1>
    80001930:	439c                	lw	a5,0(a5)
    80001932:	0230000f          	fence	r,rw
    80001936:	2781                	sext.w	a5,a5
    80001938:	c3a1                	beqz	a5,80001978 <forkret+0x64>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    8000193a:	4505                	li	a0,1
    8000193c:	489010ef          	jal	800035c4 <fsinit>

    // ensure other cores see first=0.
    __atomic_store_n(&first, 0, __ATOMIC_RELEASE);
    80001940:	00009797          	auipc	a5,0x9
    80001944:	97078793          	addi	a5,a5,-1680 # 8000a2b0 <first.1>
    80001948:	0310000f          	fence	rw,w
    8000194c:	0007a023          	sw	zero,0(a5)

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){"/init", 0});
    80001950:	00006797          	auipc	a5,0x6
    80001954:	83078793          	addi	a5,a5,-2000 # 80007180 <etext+0x180>
    80001958:	fcf43823          	sd	a5,-48(s0)
    8000195c:	fc043c23          	sd	zero,-40(s0)
    80001960:	fd040593          	addi	a1,s0,-48
    80001964:	853e                	mv	a0,a5
    80001966:	6d7020ef          	jal	8000483c <kexec>
    8000196a:	6cbc                	ld	a5,88(s1)
    8000196c:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    8000196e:	6cbc                	ld	a5,88(s1)
    80001970:	7bb8                	ld	a4,112(a5)
    80001972:	57fd                	li	a5,-1
    80001974:	02f70d63          	beq	a4,a5,800019ae <forkret+0x9a>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    80001978:	34d000ef          	jal	800024c4 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    8000197c:	68a8                	ld	a0,80(s1)
    8000197e:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001980:	04000737          	lui	a4,0x4000
    80001984:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80001986:	0732                	slli	a4,a4,0xc
    80001988:	00004797          	auipc	a5,0x4
    8000198c:	71478793          	addi	a5,a5,1812 # 8000609c <userret>
    80001990:	00004697          	auipc	a3,0x4
    80001994:	67068693          	addi	a3,a3,1648 # 80006000 <_trampoline>
    80001998:	8f95                	sub	a5,a5,a3
    8000199a:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    8000199c:	577d                	li	a4,-1
    8000199e:	177e                	slli	a4,a4,0x3f
    800019a0:	8d59                	or	a0,a0,a4
    800019a2:	9782                	jalr	a5
}
    800019a4:	70a2                	ld	ra,40(sp)
    800019a6:	7402                	ld	s0,32(sp)
    800019a8:	64e2                	ld	s1,24(sp)
    800019aa:	6145                	addi	sp,sp,48
    800019ac:	8082                	ret
      panic("exec");
    800019ae:	00005517          	auipc	a0,0x5
    800019b2:	7da50513          	addi	a0,a0,2010 # 80007188 <etext+0x188>
    800019b6:	e93fe0ef          	jal	80000848 <panic>

00000000800019ba <allocpid>:
{
    800019ba:	1101                	addi	sp,sp,-32
    800019bc:	ec06                	sd	ra,24(sp)
    800019be:	e822                	sd	s0,16(sp)
    800019c0:	e426                	sd	s1,8(sp)
    800019c2:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    800019c4:	00011517          	auipc	a0,0x11
    800019c8:	a5c50513          	addi	a0,a0,-1444 # 80012420 <pid_lock>
    800019cc:	a2cff0ef          	jal	80000bf8 <acquire>
  pid = nextpid;
    800019d0:	00009797          	auipc	a5,0x9
    800019d4:	8e478793          	addi	a5,a5,-1820 # 8000a2b4 <nextpid>
    800019d8:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    800019da:	0014871b          	addiw	a4,s1,1
    800019de:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    800019e0:	00011517          	auipc	a0,0x11
    800019e4:	a4050513          	addi	a0,a0,-1472 # 80012420 <pid_lock>
    800019e8:	a94ff0ef          	jal	80000c7c <release>
}
    800019ec:	8526                	mv	a0,s1
    800019ee:	60e2                	ld	ra,24(sp)
    800019f0:	6442                	ld	s0,16(sp)
    800019f2:	64a2                	ld	s1,8(sp)
    800019f4:	6105                	addi	sp,sp,32
    800019f6:	8082                	ret

00000000800019f8 <proc_pagetable>:
{
    800019f8:	1101                	addi	sp,sp,-32
    800019fa:	ec06                	sd	ra,24(sp)
    800019fc:	e822                	sd	s0,16(sp)
    800019fe:	e426                	sd	s1,8(sp)
    80001a00:	e04a                	sd	s2,0(sp)
    80001a02:	1000                	addi	s0,sp,32
    80001a04:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001a06:	faaff0ef          	jal	800011b0 <uvmcreate>
    80001a0a:	84aa                	mv	s1,a0
  if (pagetable == 0)
    80001a0c:	cd05                	beqz	a0,80001a44 <proc_pagetable+0x4c>
  if (mappages(pagetable, TRAMPOLINE, PGSIZE, (uint64)trampoline,
    80001a0e:	4729                	li	a4,10
    80001a10:	00004697          	auipc	a3,0x4
    80001a14:	5f068693          	addi	a3,a3,1520 # 80006000 <_trampoline>
    80001a18:	6605                	lui	a2,0x1
    80001a1a:	040005b7          	lui	a1,0x4000
    80001a1e:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a20:	05b2                	slli	a1,a1,0xc
    80001a22:	deeff0ef          	jal	80001010 <mappages>
    80001a26:	02054663          	bltz	a0,80001a52 <proc_pagetable+0x5a>
  if (mappages(pagetable, TRAPFRAME, PGSIZE, (uint64)(p->trapframe),
    80001a2a:	4719                	li	a4,6
    80001a2c:	05893683          	ld	a3,88(s2)
    80001a30:	6605                	lui	a2,0x1
    80001a32:	020005b7          	lui	a1,0x2000
    80001a36:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a38:	05b6                	slli	a1,a1,0xd
    80001a3a:	8526                	mv	a0,s1
    80001a3c:	dd4ff0ef          	jal	80001010 <mappages>
    80001a40:	00054f63          	bltz	a0,80001a5e <proc_pagetable+0x66>
}
    80001a44:	8526                	mv	a0,s1
    80001a46:	60e2                	ld	ra,24(sp)
    80001a48:	6442                	ld	s0,16(sp)
    80001a4a:	64a2                	ld	s1,8(sp)
    80001a4c:	6902                	ld	s2,0(sp)
    80001a4e:	6105                	addi	sp,sp,32
    80001a50:	8082                	ret
    uvmfree(pagetable, 0);
    80001a52:	4581                	li	a1,0
    80001a54:	8526                	mv	a0,s1
    80001a56:	94dff0ef          	jal	800013a2 <uvmfree>
    return 0;
    80001a5a:	4481                	li	s1,0
    80001a5c:	b7e5                	j	80001a44 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a5e:	4681                	li	a3,0
    80001a60:	4605                	li	a2,1
    80001a62:	040005b7          	lui	a1,0x4000
    80001a66:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a68:	05b2                	slli	a1,a1,0xc
    80001a6a:	8526                	mv	a0,s1
    80001a6c:	f6aff0ef          	jal	800011d6 <uvmunmap>
    uvmfree(pagetable, 0);
    80001a70:	4581                	li	a1,0
    80001a72:	8526                	mv	a0,s1
    80001a74:	92fff0ef          	jal	800013a2 <uvmfree>
    return 0;
    80001a78:	b7cd                	j	80001a5a <proc_pagetable+0x62>

0000000080001a7a <proc_freepagetable>:
{
    80001a7a:	1101                	addi	sp,sp,-32
    80001a7c:	ec06                	sd	ra,24(sp)
    80001a7e:	e822                	sd	s0,16(sp)
    80001a80:	e426                	sd	s1,8(sp)
    80001a82:	e04a                	sd	s2,0(sp)
    80001a84:	1000                	addi	s0,sp,32
    80001a86:	84aa                	mv	s1,a0
    80001a88:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a8a:	4681                	li	a3,0
    80001a8c:	4605                	li	a2,1
    80001a8e:	040005b7          	lui	a1,0x4000
    80001a92:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a94:	05b2                	slli	a1,a1,0xc
    80001a96:	f40ff0ef          	jal	800011d6 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001a9a:	4681                	li	a3,0
    80001a9c:	4605                	li	a2,1
    80001a9e:	020005b7          	lui	a1,0x2000
    80001aa2:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001aa4:	05b6                	slli	a1,a1,0xd
    80001aa6:	8526                	mv	a0,s1
    80001aa8:	f2eff0ef          	jal	800011d6 <uvmunmap>
  uvmfree(pagetable, sz);
    80001aac:	85ca                	mv	a1,s2
    80001aae:	8526                	mv	a0,s1
    80001ab0:	8f3ff0ef          	jal	800013a2 <uvmfree>
}
    80001ab4:	60e2                	ld	ra,24(sp)
    80001ab6:	6442                	ld	s0,16(sp)
    80001ab8:	64a2                	ld	s1,8(sp)
    80001aba:	6902                	ld	s2,0(sp)
    80001abc:	6105                	addi	sp,sp,32
    80001abe:	8082                	ret

0000000080001ac0 <freeproc>:
{
    80001ac0:	1101                	addi	sp,sp,-32
    80001ac2:	ec06                	sd	ra,24(sp)
    80001ac4:	e822                	sd	s0,16(sp)
    80001ac6:	e426                	sd	s1,8(sp)
    80001ac8:	1000                	addi	s0,sp,32
    80001aca:	84aa                	mv	s1,a0
  if (p->trapframe)
    80001acc:	6d28                	ld	a0,88(a0)
    80001ace:	c119                	beqz	a0,80001ad4 <freeproc+0x14>
    kfree((void *)p->trapframe);
    80001ad0:	f67fe0ef          	jal	80000a36 <kfree>
  p->trapframe = 0;
    80001ad4:	0404bc23          	sd	zero,88(s1)
  if (p->pagetable)
    80001ad8:	68a8                	ld	a0,80(s1)
    80001ada:	c501                	beqz	a0,80001ae2 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001adc:	64ac                	ld	a1,72(s1)
    80001ade:	f9dff0ef          	jal	80001a7a <proc_freepagetable>
  p->pagetable = 0;
    80001ae2:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001ae6:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001aea:	0204a823          	sw	zero,48(s1)
  p->name[0] = 0;
    80001aee:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001af2:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001af6:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001afa:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001afe:	0004ac23          	sw	zero,24(s1)
}
    80001b02:	60e2                	ld	ra,24(sp)
    80001b04:	6442                	ld	s0,16(sp)
    80001b06:	64a2                	ld	s1,8(sp)
    80001b08:	6105                	addi	sp,sp,32
    80001b0a:	8082                	ret

0000000080001b0c <allocproc>:
{
    80001b0c:	1101                	addi	sp,sp,-32
    80001b0e:	ec06                	sd	ra,24(sp)
    80001b10:	e822                	sd	s0,16(sp)
    80001b12:	e426                	sd	s1,8(sp)
    80001b14:	e04a                	sd	s2,0(sp)
    80001b16:	1000                	addi	s0,sp,32
  for (p = proc; p < &proc[NPROC]; p++) {
    80001b18:	00011497          	auipc	s1,0x11
    80001b1c:	d3848493          	addi	s1,s1,-712 # 80012850 <proc>
    80001b20:	00016917          	auipc	s2,0x16
    80001b24:	73090913          	addi	s2,s2,1840 # 80018250 <tickslock>
    acquire(&p->lock);
    80001b28:	8526                	mv	a0,s1
    80001b2a:	8ceff0ef          	jal	80000bf8 <acquire>
    if (p->state == UNUSED) {
    80001b2e:	4c9c                	lw	a5,24(s1)
    80001b30:	cb91                	beqz	a5,80001b44 <allocproc+0x38>
      release(&p->lock);
    80001b32:	8526                	mv	a0,s1
    80001b34:	948ff0ef          	jal	80000c7c <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001b38:	16848493          	addi	s1,s1,360
    80001b3c:	ff2496e3          	bne	s1,s2,80001b28 <allocproc+0x1c>
  return 0;
    80001b40:	4481                	li	s1,0
    80001b42:	a089                	j	80001b84 <allocproc+0x78>
  p->pid = allocpid();
    80001b44:	e77ff0ef          	jal	800019ba <allocpid>
    80001b48:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001b4a:	4785                	li	a5,1
    80001b4c:	cc9c                	sw	a5,24(s1)
  if ((p->trapframe = (struct trapframe *)kalloc()) == 0) {
    80001b4e:	fd1fe0ef          	jal	80000b1e <kalloc>
    80001b52:	892a                	mv	s2,a0
    80001b54:	eca8                	sd	a0,88(s1)
    80001b56:	cd15                	beqz	a0,80001b92 <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80001b58:	8526                	mv	a0,s1
    80001b5a:	e9fff0ef          	jal	800019f8 <proc_pagetable>
    80001b5e:	892a                	mv	s2,a0
    80001b60:	e8a8                	sd	a0,80(s1)
  if (p->pagetable == 0) {
    80001b62:	c121                	beqz	a0,80001ba2 <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80001b64:	07000613          	li	a2,112
    80001b68:	4581                	li	a1,0
    80001b6a:	06048513          	addi	a0,s1,96
    80001b6e:	946ff0ef          	jal	80000cb4 <memset>
  p->context.ra = (uint64)forkret;
    80001b72:	00000797          	auipc	a5,0x0
    80001b76:	da278793          	addi	a5,a5,-606 # 80001914 <forkret>
    80001b7a:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001b7c:	60bc                	ld	a5,64(s1)
    80001b7e:	6705                	lui	a4,0x1
    80001b80:	97ba                	add	a5,a5,a4
    80001b82:	f4bc                	sd	a5,104(s1)
}
    80001b84:	8526                	mv	a0,s1
    80001b86:	60e2                	ld	ra,24(sp)
    80001b88:	6442                	ld	s0,16(sp)
    80001b8a:	64a2                	ld	s1,8(sp)
    80001b8c:	6902                	ld	s2,0(sp)
    80001b8e:	6105                	addi	sp,sp,32
    80001b90:	8082                	ret
    freeproc(p);
    80001b92:	8526                	mv	a0,s1
    80001b94:	f2dff0ef          	jal	80001ac0 <freeproc>
    release(&p->lock);
    80001b98:	8526                	mv	a0,s1
    80001b9a:	8e2ff0ef          	jal	80000c7c <release>
    return 0;
    80001b9e:	84ca                	mv	s1,s2
    80001ba0:	b7d5                	j	80001b84 <allocproc+0x78>
    freeproc(p);
    80001ba2:	8526                	mv	a0,s1
    80001ba4:	f1dff0ef          	jal	80001ac0 <freeproc>
    release(&p->lock);
    80001ba8:	8526                	mv	a0,s1
    80001baa:	8d2ff0ef          	jal	80000c7c <release>
    return 0;
    80001bae:	84ca                	mv	s1,s2
    80001bb0:	bfd1                	j	80001b84 <allocproc+0x78>

0000000080001bb2 <userinit>:
{
    80001bb2:	1101                	addi	sp,sp,-32
    80001bb4:	ec06                	sd	ra,24(sp)
    80001bb6:	e822                	sd	s0,16(sp)
    80001bb8:	e426                	sd	s1,8(sp)
    80001bba:	1000                	addi	s0,sp,32
  p = allocproc();
    80001bbc:	f51ff0ef          	jal	80001b0c <allocproc>
    80001bc0:	84aa                	mv	s1,a0
  initproc = p;
    80001bc2:	00008797          	auipc	a5,0x8
    80001bc6:	72a7bb23          	sd	a0,1846(a5) # 8000a2f8 <initproc>
  p->cwd = namei("/");
    80001bca:	00005517          	auipc	a0,0x5
    80001bce:	5c650513          	addi	a0,a0,1478 # 80007190 <etext+0x190>
    80001bd2:	74b010ef          	jal	80003b1c <namei>
    80001bd6:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001bda:	478d                	li	a5,3
    80001bdc:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001bde:	8526                	mv	a0,s1
    80001be0:	89cff0ef          	jal	80000c7c <release>
}
    80001be4:	60e2                	ld	ra,24(sp)
    80001be6:	6442                	ld	s0,16(sp)
    80001be8:	64a2                	ld	s1,8(sp)
    80001bea:	6105                	addi	sp,sp,32
    80001bec:	8082                	ret

0000000080001bee <growproc>:
{
    80001bee:	1101                	addi	sp,sp,-32
    80001bf0:	ec06                	sd	ra,24(sp)
    80001bf2:	e822                	sd	s0,16(sp)
    80001bf4:	e426                	sd	s1,8(sp)
    80001bf6:	e04a                	sd	s2,0(sp)
    80001bf8:	1000                	addi	s0,sp,32
    80001bfa:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001bfc:	ce7ff0ef          	jal	800018e2 <myproc>
    80001c00:	892a                	mv	s2,a0
  sz = p->sz;
    80001c02:	652c                	ld	a1,72(a0)
  if (n > 0) {
    80001c04:	02905b63          	blez	s1,80001c3a <growproc+0x4c>
    if (sz + n > TRAPFRAME) {
    80001c08:	00b48633          	add	a2,s1,a1
    80001c0c:	020007b7          	lui	a5,0x2000
    80001c10:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80001c12:	07b6                	slli	a5,a5,0xd
    80001c14:	02c7e163          	bltu	a5,a2,80001c36 <growproc+0x48>
    if ((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001c18:	4691                	li	a3,4
    80001c1a:	6928                	ld	a0,80(a0)
    80001c1c:	e8aff0ef          	jal	800012a6 <uvmalloc>
    80001c20:	85aa                	mv	a1,a0
    80001c22:	c911                	beqz	a0,80001c36 <growproc+0x48>
  p->sz = sz;
    80001c24:	04b93423          	sd	a1,72(s2)
  return 0;
    80001c28:	4501                	li	a0,0
}
    80001c2a:	60e2                	ld	ra,24(sp)
    80001c2c:	6442                	ld	s0,16(sp)
    80001c2e:	64a2                	ld	s1,8(sp)
    80001c30:	6902                	ld	s2,0(sp)
    80001c32:	6105                	addi	sp,sp,32
    80001c34:	8082                	ret
      return -1;
    80001c36:	557d                	li	a0,-1
    80001c38:	bfcd                	j	80001c2a <growproc+0x3c>
  } else if (n < 0) {
    80001c3a:	fe04d5e3          	bgez	s1,80001c24 <growproc+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001c3e:	00b48633          	add	a2,s1,a1
    80001c42:	6928                	ld	a0,80(a0)
    80001c44:	e1cff0ef          	jal	80001260 <uvmdealloc>
    80001c48:	85aa                	mv	a1,a0
    80001c4a:	bfe9                	j	80001c24 <growproc+0x36>

0000000080001c4c <kfork>:
{
    80001c4c:	7139                	addi	sp,sp,-64
    80001c4e:	fc06                	sd	ra,56(sp)
    80001c50:	f822                	sd	s0,48(sp)
    80001c52:	f426                	sd	s1,40(sp)
    80001c54:	e456                	sd	s5,8(sp)
    80001c56:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c58:	c8bff0ef          	jal	800018e2 <myproc>
    80001c5c:	8aaa                	mv	s5,a0
  if ((np = allocproc()) == 0) {
    80001c5e:	eafff0ef          	jal	80001b0c <allocproc>
    80001c62:	c92d                	beqz	a0,80001cd4 <kfork+0x88>
    80001c64:	e852                	sd	s4,16(sp)
    80001c66:	8a2a                	mv	s4,a0
  if (uvmcopy(p->pagetable, np->pagetable, p->sz) < 0) {
    80001c68:	048ab603          	ld	a2,72(s5)
    80001c6c:	692c                	ld	a1,80(a0)
    80001c6e:	050ab503          	ld	a0,80(s5)
    80001c72:	f62ff0ef          	jal	800013d4 <uvmcopy>
    80001c76:	04054863          	bltz	a0,80001cc6 <kfork+0x7a>
    80001c7a:	f04a                	sd	s2,32(sp)
    80001c7c:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001c7e:	048ab783          	ld	a5,72(s5)
    80001c82:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001c86:	058ab683          	ld	a3,88(s5)
    80001c8a:	87b6                	mv	a5,a3
    80001c8c:	058a3703          	ld	a4,88(s4)
    80001c90:	12068693          	addi	a3,a3,288
    80001c94:	6388                	ld	a0,0(a5)
    80001c96:	678c                	ld	a1,8(a5)
    80001c98:	6b90                	ld	a2,16(a5)
    80001c9a:	e308                	sd	a0,0(a4)
    80001c9c:	e70c                	sd	a1,8(a4)
    80001c9e:	eb10                	sd	a2,16(a4)
    80001ca0:	6f90                	ld	a2,24(a5)
    80001ca2:	ef10                	sd	a2,24(a4)
    80001ca4:	02078793          	addi	a5,a5,32
    80001ca8:	02070713          	addi	a4,a4,32 # 1020 <_entry-0x7fffefe0>
    80001cac:	fed794e3          	bne	a5,a3,80001c94 <kfork+0x48>
  np->trapframe->a0 = 0;
    80001cb0:	058a3783          	ld	a5,88(s4)
    80001cb4:	0607b823          	sd	zero,112(a5)
  for (i = 0; i < NOFILE; i++)
    80001cb8:	0d0a8493          	addi	s1,s5,208
    80001cbc:	0d0a0913          	addi	s2,s4,208
    80001cc0:	150a8993          	addi	s3,s5,336
    80001cc4:	a831                	j	80001ce0 <kfork+0x94>
    freeproc(np);
    80001cc6:	8552                	mv	a0,s4
    80001cc8:	df9ff0ef          	jal	80001ac0 <freeproc>
    release(&np->lock);
    80001ccc:	8552                	mv	a0,s4
    80001cce:	faffe0ef          	jal	80000c7c <release>
    return -1;
    80001cd2:	6a42                	ld	s4,16(sp)
    return -1;
    80001cd4:	54fd                	li	s1,-1
    80001cd6:	a885                	j	80001d46 <kfork+0xfa>
  for (i = 0; i < NOFILE; i++)
    80001cd8:	04a1                	addi	s1,s1,8
    80001cda:	0921                	addi	s2,s2,8
    80001cdc:	01348963          	beq	s1,s3,80001cee <kfork+0xa2>
    if (p->ofile[i])
    80001ce0:	6088                	ld	a0,0(s1)
    80001ce2:	d97d                	beqz	a0,80001cd8 <kfork+0x8c>
      np->ofile[i] = filedup(p->ofile[i]);
    80001ce4:	486020ef          	jal	8000416a <filedup>
    80001ce8:	00a93023          	sd	a0,0(s2)
    80001cec:	b7f5                	j	80001cd8 <kfork+0x8c>
  np->cwd = idup(p->cwd);
    80001cee:	150ab503          	ld	a0,336(s5)
    80001cf2:	560010ef          	jal	80003252 <idup>
    80001cf6:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001cfa:	4641                	li	a2,16
    80001cfc:	158a8593          	addi	a1,s5,344
    80001d00:	158a0513          	addi	a0,s4,344
    80001d04:	8faff0ef          	jal	80000dfe <safestrcpy>
  pid = np->pid;
    80001d08:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    80001d0c:	8552                	mv	a0,s4
    80001d0e:	f6ffe0ef          	jal	80000c7c <release>
  acquire(&wait_lock);
    80001d12:	00010517          	auipc	a0,0x10
    80001d16:	72650513          	addi	a0,a0,1830 # 80012438 <wait_lock>
    80001d1a:	edffe0ef          	jal	80000bf8 <acquire>
  np->parent = p;
    80001d1e:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001d22:	00010517          	auipc	a0,0x10
    80001d26:	71650513          	addi	a0,a0,1814 # 80012438 <wait_lock>
    80001d2a:	f53fe0ef          	jal	80000c7c <release>
  acquire(&np->lock);
    80001d2e:	8552                	mv	a0,s4
    80001d30:	ec9fe0ef          	jal	80000bf8 <acquire>
  np->state = RUNNABLE;
    80001d34:	478d                	li	a5,3
    80001d36:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001d3a:	8552                	mv	a0,s4
    80001d3c:	f41fe0ef          	jal	80000c7c <release>
    80001d40:	7902                	ld	s2,32(sp)
    80001d42:	69e2                	ld	s3,24(sp)
    80001d44:	6a42                	ld	s4,16(sp)
}
    80001d46:	8526                	mv	a0,s1
    80001d48:	70e2                	ld	ra,56(sp)
    80001d4a:	7442                	ld	s0,48(sp)
    80001d4c:	74a2                	ld	s1,40(sp)
    80001d4e:	6aa2                	ld	s5,8(sp)
    80001d50:	6121                	addi	sp,sp,64
    80001d52:	8082                	ret

0000000080001d54 <scheduler>:
{
    80001d54:	711d                	addi	sp,sp,-96
    80001d56:	ec86                	sd	ra,88(sp)
    80001d58:	e8a2                	sd	s0,80(sp)
    80001d5a:	e4a6                	sd	s1,72(sp)
    80001d5c:	e0ca                	sd	s2,64(sp)
    80001d5e:	fc4e                	sd	s3,56(sp)
    80001d60:	f852                	sd	s4,48(sp)
    80001d62:	f456                	sd	s5,40(sp)
    80001d64:	f05a                	sd	s6,32(sp)
    80001d66:	ec5e                	sd	s7,24(sp)
    80001d68:	e862                	sd	s8,16(sp)
    80001d6a:	e466                	sd	s9,8(sp)
    80001d6c:	1080                	addi	s0,sp,96
    80001d6e:	8792                	mv	a5,tp
  int id = r_tp();
    80001d70:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001d72:	00779693          	slli	a3,a5,0x7
    80001d76:	00010717          	auipc	a4,0x10
    80001d7a:	6aa70713          	addi	a4,a4,1706 # 80012420 <pid_lock>
    80001d7e:	9736                	add	a4,a4,a3
    80001d80:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001d84:	00010a97          	auipc	s5,0x10
    80001d88:	6d4a8a93          	addi	s5,s5,1748 # 80012458 <cpus+0x8>
    80001d8c:	9ab6                	add	s5,s5,a3
        p->state = RUNNING;
    80001d8e:	4c11                	li	s8,4
        c->proc = p;
    80001d90:	00010b17          	auipc	s6,0x10
    80001d94:	690b0b13          	addi	s6,s6,1680 # 80012420 <pid_lock>
    80001d98:	8a3a                	mv	s4,a4
        found = 1;
    80001d9a:	4b85                	li	s7,1
    80001d9c:	a0a9                	j	80001de6 <scheduler+0x92>
      release(&p->lock);
    80001d9e:	8526                	mv	a0,s1
    80001da0:	eddfe0ef          	jal	80000c7c <release>
    for (p = proc; p < &proc[NPROC]; p++) {
    80001da4:	16848493          	addi	s1,s1,360
    80001da8:	03248b63          	beq	s1,s2,80001dde <scheduler+0x8a>
      acquire(&p->lock);
    80001dac:	8526                	mv	a0,s1
    80001dae:	e4bfe0ef          	jal	80000bf8 <acquire>
      if (p->state == RUNNABLE) {
    80001db2:	4c9c                	lw	a5,24(s1)
    80001db4:	ff3795e3          	bne	a5,s3,80001d9e <scheduler+0x4a>
        p->state = RUNNING;
    80001db8:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001dbc:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001dc0:	06048593          	addi	a1,s1,96
    80001dc4:	8556                	mv	a0,s5
    80001dc6:	654000ef          	jal	8000241a <swtch>
    80001dca:	8792                	mv	a5,tp
        mycpu()->intena = 0;
    80001dcc:	2781                	sext.w	a5,a5
    80001dce:	079e                	slli	a5,a5,0x7
    80001dd0:	97da                	add	a5,a5,s6
    80001dd2:	0a07a623          	sw	zero,172(a5)
        c->proc = 0;
    80001dd6:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001dda:	8cde                	mv	s9,s7
    80001ddc:	b7c9                	j	80001d9e <scheduler+0x4a>
    if (found == 0) {
    80001dde:	000c9463          	bnez	s9,80001de6 <scheduler+0x92>
      asm volatile("wfi");
    80001de2:	10500073          	wfi
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80001de6:	10016073          	csrsi	sstatus,2
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    80001dea:	10017073          	csrci	sstatus,2
    int found = 0;
    80001dee:	4c81                	li	s9,0
    for (p = proc; p < &proc[NPROC]; p++) {
    80001df0:	00011497          	auipc	s1,0x11
    80001df4:	a6048493          	addi	s1,s1,-1440 # 80012850 <proc>
      if (p->state == RUNNABLE) {
    80001df8:	498d                	li	s3,3
    for (p = proc; p < &proc[NPROC]; p++) {
    80001dfa:	00016917          	auipc	s2,0x16
    80001dfe:	45690913          	addi	s2,s2,1110 # 80018250 <tickslock>
    80001e02:	b76d                	j	80001dac <scheduler+0x58>

0000000080001e04 <sched>:
{
    80001e04:	7179                	addi	sp,sp,-48
    80001e06:	f406                	sd	ra,40(sp)
    80001e08:	f022                	sd	s0,32(sp)
    80001e0a:	ec26                	sd	s1,24(sp)
    80001e0c:	e84a                	sd	s2,16(sp)
    80001e0e:	e44e                	sd	s3,8(sp)
    80001e10:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001e12:	ad1ff0ef          	jal	800018e2 <myproc>
    80001e16:	84aa                	mv	s1,a0
  if (!holding(&p->lock))
    80001e18:	d7bfe0ef          	jal	80000b92 <holding>
    80001e1c:	c92d                	beqz	a0,80001e8e <sched+0x8a>
  asm volatile("mv %0, tp" : "=r"(x));
    80001e1e:	8792                	mv	a5,tp
  if (mycpu()->noff != 1)
    80001e20:	2781                	sext.w	a5,a5
    80001e22:	079e                	slli	a5,a5,0x7
    80001e24:	00010717          	auipc	a4,0x10
    80001e28:	5fc70713          	addi	a4,a4,1532 # 80012420 <pid_lock>
    80001e2c:	97ba                	add	a5,a5,a4
    80001e2e:	0a87a703          	lw	a4,168(a5)
    80001e32:	4785                	li	a5,1
    80001e34:	06f71363          	bne	a4,a5,80001e9a <sched+0x96>
  if (p->state == RUNNING)
    80001e38:	4c98                	lw	a4,24(s1)
    80001e3a:	4791                	li	a5,4
    80001e3c:	06f70563          	beq	a4,a5,80001ea6 <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80001e40:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001e44:	8b89                	andi	a5,a5,2
  if (intr_get())
    80001e46:	e7b5                	bnez	a5,80001eb2 <sched+0xae>
  asm volatile("mv %0, tp" : "=r"(x));
    80001e48:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001e4a:	00010917          	auipc	s2,0x10
    80001e4e:	5d690913          	addi	s2,s2,1494 # 80012420 <pid_lock>
    80001e52:	2781                	sext.w	a5,a5
    80001e54:	079e                	slli	a5,a5,0x7
    80001e56:	97ca                	add	a5,a5,s2
    80001e58:	0ac7a983          	lw	s3,172(a5)
    80001e5c:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001e5e:	2781                	sext.w	a5,a5
    80001e60:	079e                	slli	a5,a5,0x7
    80001e62:	00010597          	auipc	a1,0x10
    80001e66:	5f658593          	addi	a1,a1,1526 # 80012458 <cpus+0x8>
    80001e6a:	95be                	add	a1,a1,a5
    80001e6c:	06048513          	addi	a0,s1,96
    80001e70:	5aa000ef          	jal	8000241a <swtch>
    80001e74:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001e76:	2781                	sext.w	a5,a5
    80001e78:	079e                	slli	a5,a5,0x7
    80001e7a:	993e                	add	s2,s2,a5
    80001e7c:	0b392623          	sw	s3,172(s2)
}
    80001e80:	70a2                	ld	ra,40(sp)
    80001e82:	7402                	ld	s0,32(sp)
    80001e84:	64e2                	ld	s1,24(sp)
    80001e86:	6942                	ld	s2,16(sp)
    80001e88:	69a2                	ld	s3,8(sp)
    80001e8a:	6145                	addi	sp,sp,48
    80001e8c:	8082                	ret
    panic("sched p->lock");
    80001e8e:	00005517          	auipc	a0,0x5
    80001e92:	30a50513          	addi	a0,a0,778 # 80007198 <etext+0x198>
    80001e96:	9b3fe0ef          	jal	80000848 <panic>
    panic("sched locks");
    80001e9a:	00005517          	auipc	a0,0x5
    80001e9e:	30e50513          	addi	a0,a0,782 # 800071a8 <etext+0x1a8>
    80001ea2:	9a7fe0ef          	jal	80000848 <panic>
    panic("sched RUNNING");
    80001ea6:	00005517          	auipc	a0,0x5
    80001eaa:	31250513          	addi	a0,a0,786 # 800071b8 <etext+0x1b8>
    80001eae:	99bfe0ef          	jal	80000848 <panic>
    panic("sched interruptible");
    80001eb2:	00005517          	auipc	a0,0x5
    80001eb6:	31650513          	addi	a0,a0,790 # 800071c8 <etext+0x1c8>
    80001eba:	98ffe0ef          	jal	80000848 <panic>

0000000080001ebe <yield>:
{
    80001ebe:	1101                	addi	sp,sp,-32
    80001ec0:	ec06                	sd	ra,24(sp)
    80001ec2:	e822                	sd	s0,16(sp)
    80001ec4:	e426                	sd	s1,8(sp)
    80001ec6:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001ec8:	a1bff0ef          	jal	800018e2 <myproc>
    80001ecc:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001ece:	d2bfe0ef          	jal	80000bf8 <acquire>
  p->state = RUNNABLE;
    80001ed2:	478d                	li	a5,3
    80001ed4:	cc9c                	sw	a5,24(s1)
  sched();
    80001ed6:	f2fff0ef          	jal	80001e04 <sched>
  release(&p->lock);
    80001eda:	8526                	mv	a0,s1
    80001edc:	da1fe0ef          	jal	80000c7c <release>
}
    80001ee0:	60e2                	ld	ra,24(sp)
    80001ee2:	6442                	ld	s0,16(sp)
    80001ee4:	64a2                	ld	s1,8(sp)
    80001ee6:	6105                	addi	sp,sp,32
    80001ee8:	8082                	ret

0000000080001eea <sleep_prepare>:

// Register current process as waiting for wakeups on chan.
void
sleep_prepare(void *chan)
{
    80001eea:	1101                	addi	sp,sp,-32
    80001eec:	ec06                	sd	ra,24(sp)
    80001eee:	e822                	sd	s0,16(sp)
    80001ef0:	e426                	sd	s1,8(sp)
    80001ef2:	e04a                	sd	s2,0(sp)
    80001ef4:	1000                	addi	s0,sp,32
    80001ef6:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001ef8:	9ebff0ef          	jal	800018e2 <myproc>
    80001efc:	892a                	mv	s2,a0

  acquire(&p->lock);
    80001efe:	cfbfe0ef          	jal	80000bf8 <acquire>
  if (chan == 0)
    80001f02:	cc81                	beqz	s1,80001f1a <sleep_prepare+0x30>
    panic("sleep_prepare: zero chan");
  p->chan = chan;
    80001f04:	02993023          	sd	s1,32(s2)
  release(&p->lock);
    80001f08:	854a                	mv	a0,s2
    80001f0a:	d73fe0ef          	jal	80000c7c <release>
}
    80001f0e:	60e2                	ld	ra,24(sp)
    80001f10:	6442                	ld	s0,16(sp)
    80001f12:	64a2                	ld	s1,8(sp)
    80001f14:	6902                	ld	s2,0(sp)
    80001f16:	6105                	addi	sp,sp,32
    80001f18:	8082                	ret
    panic("sleep_prepare: zero chan");
    80001f1a:	00005517          	auipc	a0,0x5
    80001f1e:	2c650513          	addi	a0,a0,710 # 800071e0 <etext+0x1e0>
    80001f22:	927fe0ef          	jal	80000848 <panic>

0000000080001f26 <sleep>:
// Put the thread to sleep.  Assumes sleep_prepare() was called before.
// If the channel registered by sleep_prepare() has been woken up in
// the meantime, do not go to sleep, and instead return immediately.
void
sleep(void)
{
    80001f26:	1101                	addi	sp,sp,-32
    80001f28:	ec06                	sd	ra,24(sp)
    80001f2a:	e822                	sd	s0,16(sp)
    80001f2c:	e426                	sd	s1,8(sp)
    80001f2e:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001f30:	9b3ff0ef          	jal	800018e2 <myproc>
    80001f34:	84aa                	mv	s1,a0

  acquire(&p->lock);
    80001f36:	cc3fe0ef          	jal	80000bf8 <acquire>
  if (p->chan != 0) {
    80001f3a:	709c                	ld	a5,32(s1)
    80001f3c:	c789                	beqz	a5,80001f46 <sleep+0x20>
    p->state = SLEEPING;
    80001f3e:	4789                	li	a5,2
    80001f40:	cc9c                	sw	a5,24(s1)
    sched();
    80001f42:	ec3ff0ef          	jal	80001e04 <sched>
  }
  release(&p->lock);
    80001f46:	8526                	mv	a0,s1
    80001f48:	d35fe0ef          	jal	80000c7c <release>
}
    80001f4c:	60e2                	ld	ra,24(sp)
    80001f4e:	6442                	ld	s0,16(sp)
    80001f50:	64a2                	ld	s1,8(sp)
    80001f52:	6105                	addi	sp,sp,32
    80001f54:	8082                	ret

0000000080001f56 <wakeup>:

// Wake up all processes sleeping on channel chan.
void
wakeup(void *chan)
{
    80001f56:	7139                	addi	sp,sp,-64
    80001f58:	fc06                	sd	ra,56(sp)
    80001f5a:	f822                	sd	s0,48(sp)
    80001f5c:	f426                	sd	s1,40(sp)
    80001f5e:	f04a                	sd	s2,32(sp)
    80001f60:	ec4e                	sd	s3,24(sp)
    80001f62:	e852                	sd	s4,16(sp)
    80001f64:	e456                	sd	s5,8(sp)
    80001f66:	0080                	addi	s0,sp,64
    80001f68:	892a                	mv	s2,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    80001f6a:	00011497          	auipc	s1,0x11
    80001f6e:	8e648493          	addi	s1,s1,-1818 # 80012850 <proc>
      // signal that the wakeup happened by clearing p->chan.
      p->chan = 0;

      // If this waiting process has gotten so far as to actually
      // go to sleep, also set it back to RUNNING.
      if (p->state == SLEEPING) {
    80001f72:	4a09                	li	s4,2
        p->state = RUNNABLE;
    80001f74:	4a8d                	li	s5,3
  for (p = proc; p < &proc[NPROC]; p++) {
    80001f76:	00016997          	auipc	s3,0x16
    80001f7a:	2da98993          	addi	s3,s3,730 # 80018250 <tickslock>
    80001f7e:	a801                	j	80001f8e <wakeup+0x38>
      }
    }
    release(&p->lock);
    80001f80:	8526                	mv	a0,s1
    80001f82:	cfbfe0ef          	jal	80000c7c <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001f86:	16848493          	addi	s1,s1,360
    80001f8a:	03348063          	beq	s1,s3,80001faa <wakeup+0x54>
    acquire(&p->lock);
    80001f8e:	8526                	mv	a0,s1
    80001f90:	c69fe0ef          	jal	80000bf8 <acquire>
    if (p->chan == chan) {
    80001f94:	709c                	ld	a5,32(s1)
    80001f96:	ff2795e3          	bne	a5,s2,80001f80 <wakeup+0x2a>
      p->chan = 0;
    80001f9a:	0204b023          	sd	zero,32(s1)
      if (p->state == SLEEPING) {
    80001f9e:	4c9c                	lw	a5,24(s1)
    80001fa0:	ff4790e3          	bne	a5,s4,80001f80 <wakeup+0x2a>
        p->state = RUNNABLE;
    80001fa4:	0154ac23          	sw	s5,24(s1)
    80001fa8:	bfe1                	j	80001f80 <wakeup+0x2a>
  }
}
    80001faa:	70e2                	ld	ra,56(sp)
    80001fac:	7442                	ld	s0,48(sp)
    80001fae:	74a2                	ld	s1,40(sp)
    80001fb0:	7902                	ld	s2,32(sp)
    80001fb2:	69e2                	ld	s3,24(sp)
    80001fb4:	6a42                	ld	s4,16(sp)
    80001fb6:	6aa2                	ld	s5,8(sp)
    80001fb8:	6121                	addi	sp,sp,64
    80001fba:	8082                	ret

0000000080001fbc <reparent>:
{
    80001fbc:	7179                	addi	sp,sp,-48
    80001fbe:	f406                	sd	ra,40(sp)
    80001fc0:	f022                	sd	s0,32(sp)
    80001fc2:	ec26                	sd	s1,24(sp)
    80001fc4:	e84a                	sd	s2,16(sp)
    80001fc6:	e44e                	sd	s3,8(sp)
    80001fc8:	e052                	sd	s4,0(sp)
    80001fca:	1800                	addi	s0,sp,48
    80001fcc:	892a                	mv	s2,a0
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    80001fce:	00011497          	auipc	s1,0x11
    80001fd2:	88248493          	addi	s1,s1,-1918 # 80012850 <proc>
      pp->parent = initproc;
    80001fd6:	00008a17          	auipc	s4,0x8
    80001fda:	322a0a13          	addi	s4,s4,802 # 8000a2f8 <initproc>
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    80001fde:	00016997          	auipc	s3,0x16
    80001fe2:	27298993          	addi	s3,s3,626 # 80018250 <tickslock>
    80001fe6:	a029                	j	80001ff0 <reparent+0x34>
    80001fe8:	16848493          	addi	s1,s1,360
    80001fec:	01348b63          	beq	s1,s3,80002002 <reparent+0x46>
    if (pp->parent == p) {
    80001ff0:	7c9c                	ld	a5,56(s1)
    80001ff2:	ff279be3          	bne	a5,s2,80001fe8 <reparent+0x2c>
      pp->parent = initproc;
    80001ff6:	000a3503          	ld	a0,0(s4)
    80001ffa:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80001ffc:	f5bff0ef          	jal	80001f56 <wakeup>
    80002000:	b7e5                	j	80001fe8 <reparent+0x2c>
}
    80002002:	70a2                	ld	ra,40(sp)
    80002004:	7402                	ld	s0,32(sp)
    80002006:	64e2                	ld	s1,24(sp)
    80002008:	6942                	ld	s2,16(sp)
    8000200a:	69a2                	ld	s3,8(sp)
    8000200c:	6a02                	ld	s4,0(sp)
    8000200e:	6145                	addi	sp,sp,48
    80002010:	8082                	ret

0000000080002012 <kexit>:
{
    80002012:	7179                	addi	sp,sp,-48
    80002014:	f406                	sd	ra,40(sp)
    80002016:	f022                	sd	s0,32(sp)
    80002018:	ec26                	sd	s1,24(sp)
    8000201a:	e84a                	sd	s2,16(sp)
    8000201c:	e44e                	sd	s3,8(sp)
    8000201e:	e052                	sd	s4,0(sp)
    80002020:	1800                	addi	s0,sp,48
    80002022:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80002024:	8bfff0ef          	jal	800018e2 <myproc>
    80002028:	89aa                	mv	s3,a0
  if (p == initproc)
    8000202a:	00008797          	auipc	a5,0x8
    8000202e:	2ce7b783          	ld	a5,718(a5) # 8000a2f8 <initproc>
    80002032:	0d050493          	addi	s1,a0,208
    80002036:	15050913          	addi	s2,a0,336
    8000203a:	00a79b63          	bne	a5,a0,80002050 <kexit+0x3e>
    panic("init exiting");
    8000203e:	00005517          	auipc	a0,0x5
    80002042:	1c250513          	addi	a0,a0,450 # 80007200 <etext+0x200>
    80002046:	803fe0ef          	jal	80000848 <panic>
  for (int fd = 0; fd < NOFILE; fd++) {
    8000204a:	04a1                	addi	s1,s1,8
    8000204c:	01248963          	beq	s1,s2,8000205e <kexit+0x4c>
    if (p->ofile[fd]) {
    80002050:	6088                	ld	a0,0(s1)
    80002052:	dd65                	beqz	a0,8000204a <kexit+0x38>
      fileclose(f);
    80002054:	15c020ef          	jal	800041b0 <fileclose>
      p->ofile[fd] = 0;
    80002058:	0004b023          	sd	zero,0(s1)
    8000205c:	b7fd                	j	8000204a <kexit+0x38>
  begin_op();
    8000205e:	49d010ef          	jal	80003cfa <begin_op>
  iput(p->cwd);
    80002062:	1509b503          	ld	a0,336(s3)
    80002066:	3a4010ef          	jal	8000340a <iput>
  end_op();
    8000206a:	51d010ef          	jal	80003d86 <end_op>
  p->cwd = 0;
    8000206e:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    80002072:	00010517          	auipc	a0,0x10
    80002076:	3c650513          	addi	a0,a0,966 # 80012438 <wait_lock>
    8000207a:	b7ffe0ef          	jal	80000bf8 <acquire>
  reparent(p);
    8000207e:	854e                	mv	a0,s3
    80002080:	f3dff0ef          	jal	80001fbc <reparent>
  wakeup(p->parent);
    80002084:	0389b503          	ld	a0,56(s3)
    80002088:	ecfff0ef          	jal	80001f56 <wakeup>
  acquire(&p->lock);
    8000208c:	854e                	mv	a0,s3
    8000208e:	b6bfe0ef          	jal	80000bf8 <acquire>
  p->xstate = status;
    80002092:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    80002096:	4795                	li	a5,5
    80002098:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    8000209c:	00010517          	auipc	a0,0x10
    800020a0:	39c50513          	addi	a0,a0,924 # 80012438 <wait_lock>
    800020a4:	bd9fe0ef          	jal	80000c7c <release>
  sched();
    800020a8:	d5dff0ef          	jal	80001e04 <sched>
  panic("zombie exit");
    800020ac:	00005517          	auipc	a0,0x5
    800020b0:	16450513          	addi	a0,a0,356 # 80007210 <etext+0x210>
    800020b4:	f94fe0ef          	jal	80000848 <panic>

00000000800020b8 <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    800020b8:	7179                	addi	sp,sp,-48
    800020ba:	f406                	sd	ra,40(sp)
    800020bc:	f022                	sd	s0,32(sp)
    800020be:	ec26                	sd	s1,24(sp)
    800020c0:	e84a                	sd	s2,16(sp)
    800020c2:	e44e                	sd	s3,8(sp)
    800020c4:	1800                	addi	s0,sp,48
    800020c6:	892a                	mv	s2,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    800020c8:	00010497          	auipc	s1,0x10
    800020cc:	78848493          	addi	s1,s1,1928 # 80012850 <proc>
    800020d0:	00016997          	auipc	s3,0x16
    800020d4:	18098993          	addi	s3,s3,384 # 80018250 <tickslock>
    acquire(&p->lock);
    800020d8:	8526                	mv	a0,s1
    800020da:	b1ffe0ef          	jal	80000bf8 <acquire>
    if (p->pid == pid) {
    800020de:	589c                	lw	a5,48(s1)
    800020e0:	01278b63          	beq	a5,s2,800020f6 <kkill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    800020e4:	8526                	mv	a0,s1
    800020e6:	b97fe0ef          	jal	80000c7c <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    800020ea:	16848493          	addi	s1,s1,360
    800020ee:	ff3495e3          	bne	s1,s3,800020d8 <kkill+0x20>
  }
  return -1;
    800020f2:	557d                	li	a0,-1
    800020f4:	a819                	j	8000210a <kkill+0x52>
      p->killed = 1;
    800020f6:	4785                	li	a5,1
    800020f8:	d49c                	sw	a5,40(s1)
      if (p->state == SLEEPING) {
    800020fa:	4c98                	lw	a4,24(s1)
    800020fc:	4789                	li	a5,2
    800020fe:	00f70d63          	beq	a4,a5,80002118 <kkill+0x60>
      release(&p->lock);
    80002102:	8526                	mv	a0,s1
    80002104:	b79fe0ef          	jal	80000c7c <release>
      return 0;
    80002108:	4501                	li	a0,0
}
    8000210a:	70a2                	ld	ra,40(sp)
    8000210c:	7402                	ld	s0,32(sp)
    8000210e:	64e2                	ld	s1,24(sp)
    80002110:	6942                	ld	s2,16(sp)
    80002112:	69a2                	ld	s3,8(sp)
    80002114:	6145                	addi	sp,sp,48
    80002116:	8082                	ret
        p->state = RUNNABLE;
    80002118:	478d                	li	a5,3
    8000211a:	cc9c                	sw	a5,24(s1)
    8000211c:	b7dd                	j	80002102 <kkill+0x4a>

000000008000211e <getfilenum>:

int
getfilenum(int pid)
{
    8000211e:	7179                	addi	sp,sp,-48
    80002120:	f406                	sd	ra,40(sp)
    80002122:	f022                	sd	s0,32(sp)
    80002124:	ec26                	sd	s1,24(sp)
    80002126:	e84a                	sd	s2,16(sp)
    80002128:	e44e                	sd	s3,8(sp)
    8000212a:	1800                	addi	s0,sp,48
    8000212c:	892a                	mv	s2,a0
  struct proc *p;
  int n;

  for (p = proc; p < &proc[NPROC]; p++) {
    8000212e:	00010497          	auipc	s1,0x10
    80002132:	72248493          	addi	s1,s1,1826 # 80012850 <proc>
    80002136:	00016997          	auipc	s3,0x16
    8000213a:	11a98993          	addi	s3,s3,282 # 80018250 <tickslock>
    acquire(&p->lock);
    8000213e:	8526                	mv	a0,s1
    80002140:	ab9fe0ef          	jal	80000bf8 <acquire>
    if (p->pid == pid) {
    80002144:	589c                	lw	a5,48(s1)
    80002146:	01278b63          	beq	a5,s2,8000215c <getfilenum+0x3e>
          n++;
      }
      release(&p->lock);
      return n;
    }
    release(&p->lock);
    8000214a:	8526                	mv	a0,s1
    8000214c:	b31fe0ef          	jal	80000c7c <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002150:	16848493          	addi	s1,s1,360
    80002154:	ff3495e3          	bne	s1,s3,8000213e <getfilenum+0x20>
  }
  return -1;
    80002158:	597d                	li	s2,-1
    8000215a:	a00d                	j	8000217c <getfilenum+0x5e>
    8000215c:	0d048793          	addi	a5,s1,208
    80002160:	15048693          	addi	a3,s1,336
      n = 0;
    80002164:	4901                	li	s2,0
    80002166:	a021                	j	8000216e <getfilenum+0x50>
      for (int i = 0; i < NOFILE; i++) {
    80002168:	07a1                	addi	a5,a5,8
    8000216a:	00d78663          	beq	a5,a3,80002176 <getfilenum+0x58>
        if (p->ofile[i] != 0)
    8000216e:	6398                	ld	a4,0(a5)
    80002170:	df65                	beqz	a4,80002168 <getfilenum+0x4a>
          n++;
    80002172:	2905                	addiw	s2,s2,1
    80002174:	bfd5                	j	80002168 <getfilenum+0x4a>
      release(&p->lock);
    80002176:	8526                	mv	a0,s1
    80002178:	b05fe0ef          	jal	80000c7c <release>
}
    8000217c:	854a                	mv	a0,s2
    8000217e:	70a2                	ld	ra,40(sp)
    80002180:	7402                	ld	s0,32(sp)
    80002182:	64e2                	ld	s1,24(sp)
    80002184:	6942                	ld	s2,16(sp)
    80002186:	69a2                	ld	s3,8(sp)
    80002188:	6145                	addi	sp,sp,48
    8000218a:	8082                	ret

000000008000218c <setkilled>:

void
setkilled(struct proc *p)
{
    8000218c:	1101                	addi	sp,sp,-32
    8000218e:	ec06                	sd	ra,24(sp)
    80002190:	e822                	sd	s0,16(sp)
    80002192:	e426                	sd	s1,8(sp)
    80002194:	1000                	addi	s0,sp,32
    80002196:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002198:	a61fe0ef          	jal	80000bf8 <acquire>
  p->killed = 1;
    8000219c:	4785                	li	a5,1
    8000219e:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800021a0:	8526                	mv	a0,s1
    800021a2:	adbfe0ef          	jal	80000c7c <release>
}
    800021a6:	60e2                	ld	ra,24(sp)
    800021a8:	6442                	ld	s0,16(sp)
    800021aa:	64a2                	ld	s1,8(sp)
    800021ac:	6105                	addi	sp,sp,32
    800021ae:	8082                	ret

00000000800021b0 <killed>:

int
killed(struct proc *p)
{
    800021b0:	1101                	addi	sp,sp,-32
    800021b2:	ec06                	sd	ra,24(sp)
    800021b4:	e822                	sd	s0,16(sp)
    800021b6:	e426                	sd	s1,8(sp)
    800021b8:	e04a                	sd	s2,0(sp)
    800021ba:	1000                	addi	s0,sp,32
    800021bc:	84aa                	mv	s1,a0
  int k;

  acquire(&p->lock);
    800021be:	a3bfe0ef          	jal	80000bf8 <acquire>
  k = p->killed;
    800021c2:	549c                	lw	a5,40(s1)
    800021c4:	893e                	mv	s2,a5
  release(&p->lock);
    800021c6:	8526                	mv	a0,s1
    800021c8:	ab5fe0ef          	jal	80000c7c <release>
  return k;
}
    800021cc:	854a                	mv	a0,s2
    800021ce:	60e2                	ld	ra,24(sp)
    800021d0:	6442                	ld	s0,16(sp)
    800021d2:	64a2                	ld	s1,8(sp)
    800021d4:	6902                	ld	s2,0(sp)
    800021d6:	6105                	addi	sp,sp,32
    800021d8:	8082                	ret

00000000800021da <kwait>:
{
    800021da:	715d                	addi	sp,sp,-80
    800021dc:	e486                	sd	ra,72(sp)
    800021de:	e0a2                	sd	s0,64(sp)
    800021e0:	fc26                	sd	s1,56(sp)
    800021e2:	f84a                	sd	s2,48(sp)
    800021e4:	f44e                	sd	s3,40(sp)
    800021e6:	f052                	sd	s4,32(sp)
    800021e8:	ec56                	sd	s5,24(sp)
    800021ea:	e85a                	sd	s6,16(sp)
    800021ec:	e45e                	sd	s7,8(sp)
    800021ee:	0880                	addi	s0,sp,80
    800021f0:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    800021f2:	ef0ff0ef          	jal	800018e2 <myproc>
    800021f6:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800021f8:	00010517          	auipc	a0,0x10
    800021fc:	24050513          	addi	a0,a0,576 # 80012438 <wait_lock>
    80002200:	9f9fe0ef          	jal	80000bf8 <acquire>
        if (pp->state == ZOMBIE) {
    80002204:	4a15                	li	s4,5
        havekids = 1;
    80002206:	4a85                	li	s5,1
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    80002208:	00016997          	auipc	s3,0x16
    8000220c:	04898993          	addi	s3,s3,72 # 80018250 <tickslock>
    release(&wait_lock);
    80002210:	00010b17          	auipc	s6,0x10
    80002214:	228b0b13          	addi	s6,s6,552 # 80012438 <wait_lock>
    80002218:	a07d                	j	800022c6 <kwait+0xec>
          pid = pp->pid;
    8000221a:	0304a983          	lw	s3,48(s1)
          if (addr != 0 &&
    8000221e:	000b8e63          	beqz	s7,8000223a <kwait+0x60>
              copyout(p->pagetable, p->sz, addr, (char *)&pp->xstate,
    80002222:	4711                	li	a4,4
    80002224:	02c48693          	addi	a3,s1,44
    80002228:	865e                	mv	a2,s7
    8000222a:	04893583          	ld	a1,72(s2)
    8000222e:	05093503          	ld	a0,80(s2)
    80002232:	afaff0ef          	jal	8000152c <copyout>
          if (addr != 0 &&
    80002236:	02054c63          	bltz	a0,8000226e <kwait+0x94>
          pp->parent = 0;
    8000223a:	0204bc23          	sd	zero,56(s1)
          freeproc(pp);
    8000223e:	8526                	mv	a0,s1
    80002240:	881ff0ef          	jal	80001ac0 <freeproc>
          release(&pp->lock);
    80002244:	8526                	mv	a0,s1
    80002246:	a37fe0ef          	jal	80000c7c <release>
          release(&wait_lock);
    8000224a:	00010517          	auipc	a0,0x10
    8000224e:	1ee50513          	addi	a0,a0,494 # 80012438 <wait_lock>
    80002252:	a2bfe0ef          	jal	80000c7c <release>
}
    80002256:	854e                	mv	a0,s3
    80002258:	60a6                	ld	ra,72(sp)
    8000225a:	6406                	ld	s0,64(sp)
    8000225c:	74e2                	ld	s1,56(sp)
    8000225e:	7942                	ld	s2,48(sp)
    80002260:	79a2                	ld	s3,40(sp)
    80002262:	7a02                	ld	s4,32(sp)
    80002264:	6ae2                	ld	s5,24(sp)
    80002266:	6b42                	ld	s6,16(sp)
    80002268:	6ba2                	ld	s7,8(sp)
    8000226a:	6161                	addi	sp,sp,80
    8000226c:	8082                	ret
            release(&pp->lock);
    8000226e:	8526                	mv	a0,s1
    80002270:	a0dfe0ef          	jal	80000c7c <release>
            release(&wait_lock);
    80002274:	00010517          	auipc	a0,0x10
    80002278:	1c450513          	addi	a0,a0,452 # 80012438 <wait_lock>
    8000227c:	a01fe0ef          	jal	80000c7c <release>
            return -1;
    80002280:	a8b9                	j	800022de <kwait+0x104>
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    80002282:	16848493          	addi	s1,s1,360
    80002286:	03348063          	beq	s1,s3,800022a6 <kwait+0xcc>
      if (pp->parent == p) {
    8000228a:	7c9c                	ld	a5,56(s1)
    8000228c:	ff279be3          	bne	a5,s2,80002282 <kwait+0xa8>
        acquire(&pp->lock);
    80002290:	8526                	mv	a0,s1
    80002292:	967fe0ef          	jal	80000bf8 <acquire>
        if (pp->state == ZOMBIE) {
    80002296:	4c9c                	lw	a5,24(s1)
    80002298:	f94781e3          	beq	a5,s4,8000221a <kwait+0x40>
        release(&pp->lock);
    8000229c:	8526                	mv	a0,s1
    8000229e:	9dffe0ef          	jal	80000c7c <release>
        havekids = 1;
    800022a2:	8756                	mv	a4,s5
    800022a4:	bff9                	j	80002282 <kwait+0xa8>
    if (!havekids || killed(p)) {
    800022a6:	c715                	beqz	a4,800022d2 <kwait+0xf8>
    800022a8:	854a                	mv	a0,s2
    800022aa:	f07ff0ef          	jal	800021b0 <killed>
    800022ae:	e115                	bnez	a0,800022d2 <kwait+0xf8>
    sleep_prepare(p); //DOC: wait-sleep
    800022b0:	854a                	mv	a0,s2
    800022b2:	c39ff0ef          	jal	80001eea <sleep_prepare>
    release(&wait_lock);
    800022b6:	855a                	mv	a0,s6
    800022b8:	9c5fe0ef          	jal	80000c7c <release>
    sleep();
    800022bc:	c6bff0ef          	jal	80001f26 <sleep>
    acquire(&wait_lock);
    800022c0:	855a                	mv	a0,s6
    800022c2:	937fe0ef          	jal	80000bf8 <acquire>
    havekids = 0;
    800022c6:	4701                	li	a4,0
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    800022c8:	00010497          	auipc	s1,0x10
    800022cc:	58848493          	addi	s1,s1,1416 # 80012850 <proc>
    800022d0:	bf6d                	j	8000228a <kwait+0xb0>
      release(&wait_lock);
    800022d2:	00010517          	auipc	a0,0x10
    800022d6:	16650513          	addi	a0,a0,358 # 80012438 <wait_lock>
    800022da:	9a3fe0ef          	jal	80000c7c <release>
            return -1;
    800022de:	59fd                	li	s3,-1
    800022e0:	bf9d                	j	80002256 <kwait+0x7c>

00000000800022e2 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    800022e2:	7179                	addi	sp,sp,-48
    800022e4:	f406                	sd	ra,40(sp)
    800022e6:	f022                	sd	s0,32(sp)
    800022e8:	ec26                	sd	s1,24(sp)
    800022ea:	e84a                	sd	s2,16(sp)
    800022ec:	e44e                	sd	s3,8(sp)
    800022ee:	e052                	sd	s4,0(sp)
    800022f0:	1800                	addi	s0,sp,48
    800022f2:	84aa                	mv	s1,a0
    800022f4:	8a2e                	mv	s4,a1
    800022f6:	89b2                	mv	s3,a2
    800022f8:	8936                	mv	s2,a3
  struct proc *p = myproc();
    800022fa:	de8ff0ef          	jal	800018e2 <myproc>
  if (user_dst) {
    800022fe:	c085                	beqz	s1,8000231e <either_copyout+0x3c>
    return copyout(p->pagetable, p->sz, dst, src, len);
    80002300:	874a                	mv	a4,s2
    80002302:	86ce                	mv	a3,s3
    80002304:	8652                	mv	a2,s4
    80002306:	652c                	ld	a1,72(a0)
    80002308:	6928                	ld	a0,80(a0)
    8000230a:	a22ff0ef          	jal	8000152c <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    8000230e:	70a2                	ld	ra,40(sp)
    80002310:	7402                	ld	s0,32(sp)
    80002312:	64e2                	ld	s1,24(sp)
    80002314:	6942                	ld	s2,16(sp)
    80002316:	69a2                	ld	s3,8(sp)
    80002318:	6a02                	ld	s4,0(sp)
    8000231a:	6145                	addi	sp,sp,48
    8000231c:	8082                	ret
    memmove((char *)dst, src, len);
    8000231e:	0009061b          	sext.w	a2,s2
    80002322:	85ce                	mv	a1,s3
    80002324:	8552                	mv	a0,s4
    80002326:	9ebfe0ef          	jal	80000d10 <memmove>
    return 0;
    8000232a:	8526                	mv	a0,s1
    8000232c:	b7cd                	j	8000230e <either_copyout+0x2c>

000000008000232e <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    8000232e:	7179                	addi	sp,sp,-48
    80002330:	f406                	sd	ra,40(sp)
    80002332:	f022                	sd	s0,32(sp)
    80002334:	ec26                	sd	s1,24(sp)
    80002336:	e84a                	sd	s2,16(sp)
    80002338:	e44e                	sd	s3,8(sp)
    8000233a:	e052                	sd	s4,0(sp)
    8000233c:	1800                	addi	s0,sp,48
    8000233e:	8a2a                	mv	s4,a0
    80002340:	84ae                	mv	s1,a1
    80002342:	89b2                	mv	s3,a2
    80002344:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80002346:	d9cff0ef          	jal	800018e2 <myproc>
  if (user_src) {
    8000234a:	c085                	beqz	s1,8000236a <either_copyin+0x3c>
    return copyin(p->pagetable, p->sz, dst, src, len);
    8000234c:	874a                	mv	a4,s2
    8000234e:	86ce                	mv	a3,s3
    80002350:	8652                	mv	a2,s4
    80002352:	652c                	ld	a1,72(a0)
    80002354:	6928                	ld	a0,80(a0)
    80002356:	a96ff0ef          	jal	800015ec <copyin>
  } else {
    memmove(dst, (char *)src, len);
    return 0;
  }
}
    8000235a:	70a2                	ld	ra,40(sp)
    8000235c:	7402                	ld	s0,32(sp)
    8000235e:	64e2                	ld	s1,24(sp)
    80002360:	6942                	ld	s2,16(sp)
    80002362:	69a2                	ld	s3,8(sp)
    80002364:	6a02                	ld	s4,0(sp)
    80002366:	6145                	addi	sp,sp,48
    80002368:	8082                	ret
    memmove(dst, (char *)src, len);
    8000236a:	0009061b          	sext.w	a2,s2
    8000236e:	85ce                	mv	a1,s3
    80002370:	8552                	mv	a0,s4
    80002372:	99ffe0ef          	jal	80000d10 <memmove>
    return 0;
    80002376:	8526                	mv	a0,s1
    80002378:	b7cd                	j	8000235a <either_copyin+0x2c>

000000008000237a <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    8000237a:	715d                	addi	sp,sp,-80
    8000237c:	e486                	sd	ra,72(sp)
    8000237e:	e0a2                	sd	s0,64(sp)
    80002380:	fc26                	sd	s1,56(sp)
    80002382:	f84a                	sd	s2,48(sp)
    80002384:	f44e                	sd	s3,40(sp)
    80002386:	f052                	sd	s4,32(sp)
    80002388:	ec56                	sd	s5,24(sp)
    8000238a:	e85a                	sd	s6,16(sp)
    8000238c:	e45e                	sd	s7,8(sp)
    8000238e:	0880                	addi	s0,sp,80
    // clang-format on
  };
  struct proc *p;
  char *state;

  printk("\n");
    80002390:	00005517          	auipc	a0,0x5
    80002394:	ce850513          	addi	a0,a0,-792 # 80007078 <etext+0x78>
    80002398:	978fe0ef          	jal	80000510 <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    8000239c:	00010497          	auipc	s1,0x10
    800023a0:	60c48493          	addi	s1,s1,1548 # 800129a8 <proc+0x158>
    800023a4:	00016917          	auipc	s2,0x16
    800023a8:	00490913          	addi	s2,s2,4 # 800183a8 <bcache+0x140>
    if (p->state == UNUSED)
      continue;
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800023ac:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    800023ae:	00005a97          	auipc	s5,0x5
    800023b2:	e72a8a93          	addi	s5,s5,-398 # 80007220 <etext+0x220>
    printk("%d %s %s", p->pid, state, p->name);
    800023b6:	00005a17          	auipc	s4,0x5
    800023ba:	e72a0a13          	addi	s4,s4,-398 # 80007228 <etext+0x228>
    printk("\n");
    800023be:	00005997          	auipc	s3,0x5
    800023c2:	cba98993          	addi	s3,s3,-838 # 80007078 <etext+0x78>
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800023c6:	00005b97          	auipc	s7,0x5
    800023ca:	382b8b93          	addi	s7,s7,898 # 80007748 <states.0>
    800023ce:	a829                	j	800023e8 <procdump+0x6e>
    printk("%d %s %s", p->pid, state, p->name);
    800023d0:	ed86a583          	lw	a1,-296(a3)
    800023d4:	8552                	mv	a0,s4
    800023d6:	93afe0ef          	jal	80000510 <printk>
    printk("\n");
    800023da:	854e                	mv	a0,s3
    800023dc:	934fe0ef          	jal	80000510 <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    800023e0:	16848493          	addi	s1,s1,360
    800023e4:	03248063          	beq	s1,s2,80002404 <procdump+0x8a>
    if (p->state == UNUSED)
    800023e8:	86a6                	mv	a3,s1
    800023ea:	ec04a783          	lw	a5,-320(s1)
    800023ee:	dbed                	beqz	a5,800023e0 <procdump+0x66>
      state = "???";
    800023f0:	8656                	mv	a2,s5
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800023f2:	fcfb6fe3          	bltu	s6,a5,800023d0 <procdump+0x56>
    800023f6:	02079713          	slli	a4,a5,0x20
    800023fa:	01d75793          	srli	a5,a4,0x1d
    800023fe:	97de                	add	a5,a5,s7
    80002400:	6390                	ld	a2,0(a5)
      state = states[p->state];
    80002402:	b7f9                	j	800023d0 <procdump+0x56>
  }
}
    80002404:	60a6                	ld	ra,72(sp)
    80002406:	6406                	ld	s0,64(sp)
    80002408:	74e2                	ld	s1,56(sp)
    8000240a:	7942                	ld	s2,48(sp)
    8000240c:	79a2                	ld	s3,40(sp)
    8000240e:	7a02                	ld	s4,32(sp)
    80002410:	6ae2                	ld	s5,24(sp)
    80002412:	6b42                	ld	s6,16(sp)
    80002414:	6ba2                	ld	s7,8(sp)
    80002416:	6161                	addi	sp,sp,80
    80002418:	8082                	ret

000000008000241a <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    8000241a:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    8000241e:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    80002422:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    80002424:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    80002426:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    8000242a:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    8000242e:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    80002432:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    80002436:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    8000243a:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    8000243e:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    80002442:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    80002446:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    8000244a:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    8000244e:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    80002452:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    80002456:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    80002458:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    8000245a:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    8000245e:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    80002462:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    80002466:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    8000246a:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    8000246e:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    80002472:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    80002476:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    8000247a:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    8000247e:	0685bd83          	ld	s11,104(a1)
        
        ret
    80002482:	8082                	ret

0000000080002484 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80002484:	1141                	addi	sp,sp,-16
    80002486:	e406                	sd	ra,8(sp)
    80002488:	e022                	sd	s0,0(sp)
    8000248a:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    8000248c:	00005597          	auipc	a1,0x5
    80002490:	ddc58593          	addi	a1,a1,-548 # 80007268 <etext+0x268>
    80002494:	00016517          	auipc	a0,0x16
    80002498:	dbc50513          	addi	a0,a0,-580 # 80018250 <tickslock>
    8000249c:	edcfe0ef          	jal	80000b78 <initlock>
}
    800024a0:	60a2                	ld	ra,8(sp)
    800024a2:	6402                	ld	s0,0(sp)
    800024a4:	0141                	addi	sp,sp,16
    800024a6:	8082                	ret

00000000800024a8 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    800024a8:	1141                	addi	sp,sp,-16
    800024aa:	e406                	sd	ra,8(sp)
    800024ac:	e022                	sd	s0,0(sp)
    800024ae:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r"(x));
    800024b0:	00003797          	auipc	a5,0x3
    800024b4:	0d078793          	addi	a5,a5,208 # 80005580 <kernelvec>
    800024b8:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    800024bc:	60a2                	ld	ra,8(sp)
    800024be:	6402                	ld	s0,0(sp)
    800024c0:	0141                	addi	sp,sp,16
    800024c2:	8082                	ret

00000000800024c4 <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    800024c4:	1141                	addi	sp,sp,-16
    800024c6:	e406                	sd	ra,8(sp)
    800024c8:	e022                	sd	s0,0(sp)
    800024ca:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    800024cc:	c16ff0ef          	jal	800018e2 <myproc>
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    800024d0:	10017073          	csrci	sstatus,2
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    800024d4:	04000737          	lui	a4,0x4000
    800024d8:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    800024da:	0732                	slli	a4,a4,0xc
    800024dc:	00004797          	auipc	a5,0x4
    800024e0:	b2478793          	addi	a5,a5,-1244 # 80006000 <_trampoline>
    800024e4:	00004697          	auipc	a3,0x4
    800024e8:	b1c68693          	addi	a3,a3,-1252 # 80006000 <_trampoline>
    800024ec:	8f95                	sub	a5,a5,a3
    800024ee:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r"(x));
    800024f0:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800024f4:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r"(x));
    800024f6:	18002773          	csrr	a4,satp
    800024fa:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    800024fc:	6d38                	ld	a4,88(a0)
    800024fe:	613c                	ld	a5,64(a0)
    80002500:	6685                	lui	a3,0x1
    80002502:	97b6                	add	a5,a5,a3
    80002504:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002506:	6d3c                	ld	a5,88(a0)
    80002508:	00000717          	auipc	a4,0x0
    8000250c:	0f470713          	addi	a4,a4,244 # 800025fc <usertrap>
    80002510:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp(); // hartid for cpuid()
    80002512:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r"(x));
    80002514:	8712                	mv	a4,tp
    80002516:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002518:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.

  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    8000251c:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002520:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r"(x));
    80002524:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80002528:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r"(x));
    8000252a:	6f9c                	ld	a5,24(a5)
    8000252c:	14179073          	csrw	sepc,a5
}
    80002530:	60a2                	ld	ra,8(sp)
    80002532:	6402                	ld	s0,0(sp)
    80002534:	0141                	addi	sp,sp,16
    80002536:	8082                	ret

0000000080002538 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80002538:	1141                	addi	sp,sp,-16
    8000253a:	e406                	sd	ra,8(sp)
    8000253c:	e022                	sd	s0,0(sp)
    8000253e:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    80002540:	b6eff0ef          	jal	800018ae <cpuid>
    80002544:	cd11                	beqz	a0,80002560 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r"(x));
    80002546:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    8000254a:	000f4737          	lui	a4,0xf4
    8000254e:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80002552:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    80002554:	14d79073          	csrw	stimecmp,a5
}
    80002558:	60a2                	ld	ra,8(sp)
    8000255a:	6402                	ld	s0,0(sp)
    8000255c:	0141                	addi	sp,sp,16
    8000255e:	8082                	ret
    acquire(&tickslock);
    80002560:	00016517          	auipc	a0,0x16
    80002564:	cf050513          	addi	a0,a0,-784 # 80018250 <tickslock>
    80002568:	e90fe0ef          	jal	80000bf8 <acquire>
    ticks++;
    8000256c:	00008717          	auipc	a4,0x8
    80002570:	d9470713          	addi	a4,a4,-620 # 8000a300 <ticks>
    80002574:	431c                	lw	a5,0(a4)
    80002576:	2785                	addiw	a5,a5,1
    80002578:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    8000257a:	853a                	mv	a0,a4
    8000257c:	9dbff0ef          	jal	80001f56 <wakeup>
    release(&tickslock);
    80002580:	00016517          	auipc	a0,0x16
    80002584:	cd050513          	addi	a0,a0,-816 # 80018250 <tickslock>
    80002588:	ef4fe0ef          	jal	80000c7c <release>
    8000258c:	bf6d                	j	80002546 <clockintr+0xe>

000000008000258e <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    8000258e:	1101                	addi	sp,sp,-32
    80002590:	ec06                	sd	ra,24(sp)
    80002592:	e822                	sd	s0,16(sp)
    80002594:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r"(x));
    80002596:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if (scause == 0x8000000000000009L) {
    8000259a:	57fd                	li	a5,-1
    8000259c:	17fe                	slli	a5,a5,0x3f
    8000259e:	07a5                	addi	a5,a5,9
    800025a0:	00f70c63          	beq	a4,a5,800025b8 <devintr+0x2a>
    // now allowed to interrupt again.
    if (irq)
      plic_complete(irq);

    return 1;
  } else if (scause == 0x8000000000000005L) {
    800025a4:	57fd                	li	a5,-1
    800025a6:	17fe                	slli	a5,a5,0x3f
    800025a8:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    800025aa:	4501                	li	a0,0
  } else if (scause == 0x8000000000000005L) {
    800025ac:	04f70463          	beq	a4,a5,800025f4 <devintr+0x66>
  }
}
    800025b0:	60e2                	ld	ra,24(sp)
    800025b2:	6442                	ld	s0,16(sp)
    800025b4:	6105                	addi	sp,sp,32
    800025b6:	8082                	ret
    800025b8:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    800025ba:	072030ef          	jal	8000562c <plic_claim>
    800025be:	84aa                	mv	s1,a0
    if (irq == UART0_IRQ) {
    800025c0:	47a9                	li	a5,10
    800025c2:	02f50363          	beq	a0,a5,800025e8 <devintr+0x5a>
    } else if (irq == VIRTIO0_IRQ) {
    800025c6:	4785                	li	a5,1
    800025c8:	02f50363          	beq	a0,a5,800025ee <devintr+0x60>
    } else if (irq) {
    800025cc:	c919                	beqz	a0,800025e2 <devintr+0x54>
      printk("unexpected interrupt irq=%d\n", irq);
    800025ce:	85aa                	mv	a1,a0
    800025d0:	00005517          	auipc	a0,0x5
    800025d4:	ca050513          	addi	a0,a0,-864 # 80007270 <etext+0x270>
    800025d8:	f39fd0ef          	jal	80000510 <printk>
      plic_complete(irq);
    800025dc:	8526                	mv	a0,s1
    800025de:	06e030ef          	jal	8000564c <plic_complete>
    return 1;
    800025e2:	4505                	li	a0,1
    800025e4:	64a2                	ld	s1,8(sp)
    800025e6:	b7e9                	j	800025b0 <devintr+0x22>
      uartintr();
    800025e8:	bf6fe0ef          	jal	800009de <uartintr>
    if (irq)
    800025ec:	bfc5                	j	800025dc <devintr+0x4e>
      virtio_disk_intr();
    800025ee:	4e4030ef          	jal	80005ad2 <virtio_disk_intr>
    if (irq)
    800025f2:	b7ed                	j	800025dc <devintr+0x4e>
    clockintr();
    800025f4:	f45ff0ef          	jal	80002538 <clockintr>
    return 2;
    800025f8:	4509                	li	a0,2
    800025fa:	bf5d                	j	800025b0 <devintr+0x22>

00000000800025fc <usertrap>:
{
    800025fc:	1101                	addi	sp,sp,-32
    800025fe:	ec06                	sd	ra,24(sp)
    80002600:	e822                	sd	s0,16(sp)
    80002602:	e426                	sd	s1,8(sp)
    80002604:	e04a                	sd	s2,0(sp)
    80002606:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002608:	100027f3          	csrr	a5,sstatus
  if ((r_sstatus() & SSTATUS_SPP) != 0)
    8000260c:	1007f793          	andi	a5,a5,256
    80002610:	eba5                	bnez	a5,80002680 <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002612:	00003797          	auipc	a5,0x3
    80002616:	f6e78793          	addi	a5,a5,-146 # 80005580 <kernelvec>
    8000261a:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    8000261e:	ac4ff0ef          	jal	800018e2 <myproc>
    80002622:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002624:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002626:	14102773          	csrr	a4,sepc
    8000262a:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r"(x));
    8000262c:	14202773          	csrr	a4,scause
  if (r_scause() == 8) {
    80002630:	47a1                	li	a5,8
    80002632:	04f70d63          	beq	a4,a5,8000268c <usertrap+0x90>
  } else if ((which_dev = devintr()) != 0) {
    80002636:	f59ff0ef          	jal	8000258e <devintr>
    8000263a:	892a                	mv	s2,a0
    8000263c:	e54d                	bnez	a0,800026e6 <usertrap+0xea>
    8000263e:	14202773          	csrr	a4,scause
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    80002642:	47bd                	li	a5,15
    80002644:	08f70463          	beq	a4,a5,800026cc <usertrap+0xd0>
    80002648:	14202773          	csrr	a4,scause
    8000264c:	47b5                	li	a5,13
    8000264e:	06f70f63          	beq	a4,a5,800026cc <usertrap+0xd0>
    80002652:	142025f3          	csrr	a1,scause
    printk("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80002656:	5890                	lw	a2,48(s1)
    80002658:	00005517          	auipc	a0,0x5
    8000265c:	c5850513          	addi	a0,a0,-936 # 800072b0 <etext+0x2b0>
    80002660:	eb1fd0ef          	jal	80000510 <printk>
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002664:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    80002668:	14302673          	csrr	a2,stval
    printk("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    8000266c:	00005517          	auipc	a0,0x5
    80002670:	c7450513          	addi	a0,a0,-908 # 800072e0 <etext+0x2e0>
    80002674:	e9dfd0ef          	jal	80000510 <printk>
    setkilled(p);
    80002678:	8526                	mv	a0,s1
    8000267a:	b13ff0ef          	jal	8000218c <setkilled>
    8000267e:	a015                	j	800026a2 <usertrap+0xa6>
    panic("usertrap: not from user mode");
    80002680:	00005517          	auipc	a0,0x5
    80002684:	c1050513          	addi	a0,a0,-1008 # 80007290 <etext+0x290>
    80002688:	9c0fe0ef          	jal	80000848 <panic>
    if (killed(p))
    8000268c:	b25ff0ef          	jal	800021b0 <killed>
    80002690:	e915                	bnez	a0,800026c4 <usertrap+0xc8>
    p->trapframe->epc += 4;
    80002692:	6cb8                	ld	a4,88(s1)
    80002694:	6f1c                	ld	a5,24(a4)
    80002696:	0791                	addi	a5,a5,4
    80002698:	ef1c                	sd	a5,24(a4)
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    8000269a:	10016073          	csrsi	sstatus,2
    syscall();
    8000269e:	240000ef          	jal	800028de <syscall>
  if (killed(p))
    800026a2:	8526                	mv	a0,s1
    800026a4:	b0dff0ef          	jal	800021b0 <killed>
    800026a8:	e521                	bnez	a0,800026f0 <usertrap+0xf4>
  prepare_return();
    800026aa:	e1bff0ef          	jal	800024c4 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    800026ae:	68a8                	ld	a0,80(s1)
    800026b0:	8131                	srli	a0,a0,0xc
    800026b2:	57fd                	li	a5,-1
    800026b4:	17fe                	slli	a5,a5,0x3f
    800026b6:	8d5d                	or	a0,a0,a5
}
    800026b8:	60e2                	ld	ra,24(sp)
    800026ba:	6442                	ld	s0,16(sp)
    800026bc:	64a2                	ld	s1,8(sp)
    800026be:	6902                	ld	s2,0(sp)
    800026c0:	6105                	addi	sp,sp,32
    800026c2:	8082                	ret
      kexit(-1);
    800026c4:	557d                	li	a0,-1
    800026c6:	94dff0ef          	jal	80002012 <kexit>
    800026ca:	b7e1                	j	80002692 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r"(x));
    800026cc:	14302673          	csrr	a2,stval
  asm volatile("csrr %0, scause" : "=r"(x));
    800026d0:	142026f3          	csrr	a3,scause
             vmfault(p->pagetable, p->sz, r_stval(),
    800026d4:	16cd                	addi	a3,a3,-13 # ff3 <_entry-0x7ffff00d>
    800026d6:	0016b693          	seqz	a3,a3
    800026da:	64ac                	ld	a1,72(s1)
    800026dc:	68a8                	ld	a0,80(s1)
    800026de:	dd7fe0ef          	jal	800014b4 <vmfault>
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    800026e2:	f161                	bnez	a0,800026a2 <usertrap+0xa6>
    800026e4:	b7bd                	j	80002652 <usertrap+0x56>
  if (killed(p))
    800026e6:	8526                	mv	a0,s1
    800026e8:	ac9ff0ef          	jal	800021b0 <killed>
    800026ec:	c511                	beqz	a0,800026f8 <usertrap+0xfc>
    800026ee:	a011                	j	800026f2 <usertrap+0xf6>
    800026f0:	4901                	li	s2,0
    kexit(-1);
    800026f2:	557d                	li	a0,-1
    800026f4:	91fff0ef          	jal	80002012 <kexit>
  if (which_dev == 2)
    800026f8:	4789                	li	a5,2
    800026fa:	faf918e3          	bne	s2,a5,800026aa <usertrap+0xae>
    yield();
    800026fe:	fc0ff0ef          	jal	80001ebe <yield>
    80002702:	b765                	j	800026aa <usertrap+0xae>

0000000080002704 <kerneltrap>:
{
    80002704:	7179                	addi	sp,sp,-48
    80002706:	f406                	sd	ra,40(sp)
    80002708:	f022                	sd	s0,32(sp)
    8000270a:	ec26                	sd	s1,24(sp)
    8000270c:	e84a                	sd	s2,16(sp)
    8000270e:	e44e                	sd	s3,8(sp)
    80002710:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002712:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002716:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r"(x));
    8000271a:	142027f3          	csrr	a5,scause
    8000271e:	89be                	mv	s3,a5
  if ((sstatus & SSTATUS_SPP) == 0)
    80002720:	1004f793          	andi	a5,s1,256
    80002724:	c795                	beqz	a5,80002750 <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002726:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000272a:	8b89                	andi	a5,a5,2
  if (intr_get() != 0)
    8000272c:	eb85                	bnez	a5,8000275c <kerneltrap+0x58>
  if ((which_dev = devintr()) == 0) {
    8000272e:	e61ff0ef          	jal	8000258e <devintr>
    80002732:	c91d                	beqz	a0,80002768 <kerneltrap+0x64>
  if (which_dev == 2 && myproc() != 0)
    80002734:	4789                	li	a5,2
    80002736:	04f50a63          	beq	a0,a5,8000278a <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r"(x));
    8000273a:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r"(x));
    8000273e:	10049073          	csrw	sstatus,s1
}
    80002742:	70a2                	ld	ra,40(sp)
    80002744:	7402                	ld	s0,32(sp)
    80002746:	64e2                	ld	s1,24(sp)
    80002748:	6942                	ld	s2,16(sp)
    8000274a:	69a2                	ld	s3,8(sp)
    8000274c:	6145                	addi	sp,sp,48
    8000274e:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002750:	00005517          	auipc	a0,0x5
    80002754:	bb850513          	addi	a0,a0,-1096 # 80007308 <etext+0x308>
    80002758:	8f0fe0ef          	jal	80000848 <panic>
    panic("kerneltrap: interrupts enabled");
    8000275c:	00005517          	auipc	a0,0x5
    80002760:	bd450513          	addi	a0,a0,-1068 # 80007330 <etext+0x330>
    80002764:	8e4fe0ef          	jal	80000848 <panic>
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002768:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    8000276c:	143026f3          	csrr	a3,stval
    printk("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(),
    80002770:	85ce                	mv	a1,s3
    80002772:	00005517          	auipc	a0,0x5
    80002776:	bde50513          	addi	a0,a0,-1058 # 80007350 <etext+0x350>
    8000277a:	d97fd0ef          	jal	80000510 <printk>
    panic("kerneltrap");
    8000277e:	00005517          	auipc	a0,0x5
    80002782:	bfa50513          	addi	a0,a0,-1030 # 80007378 <etext+0x378>
    80002786:	8c2fe0ef          	jal	80000848 <panic>
  if (which_dev == 2 && myproc() != 0)
    8000278a:	958ff0ef          	jal	800018e2 <myproc>
    8000278e:	d555                	beqz	a0,8000273a <kerneltrap+0x36>
    yield();
    80002790:	f2eff0ef          	jal	80001ebe <yield>
    80002794:	b75d                	j	8000273a <kerneltrap+0x36>

0000000080002796 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002796:	1101                	addi	sp,sp,-32
    80002798:	ec06                	sd	ra,24(sp)
    8000279a:	e822                	sd	s0,16(sp)
    8000279c:	e426                	sd	s1,8(sp)
    8000279e:	1000                	addi	s0,sp,32
    800027a0:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    800027a2:	940ff0ef          	jal	800018e2 <myproc>
  switch (n) {
    800027a6:	4795                	li	a5,5
    800027a8:	0497e163          	bltu	a5,s1,800027ea <argraw+0x54>
    800027ac:	048a                	slli	s1,s1,0x2
    800027ae:	00005717          	auipc	a4,0x5
    800027b2:	fca70713          	addi	a4,a4,-54 # 80007778 <states.0+0x30>
    800027b6:	94ba                	add	s1,s1,a4
    800027b8:	409c                	lw	a5,0(s1)
    800027ba:	97ba                	add	a5,a5,a4
    800027bc:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    800027be:	6d3c                	ld	a5,88(a0)
    800027c0:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    800027c2:	60e2                	ld	ra,24(sp)
    800027c4:	6442                	ld	s0,16(sp)
    800027c6:	64a2                	ld	s1,8(sp)
    800027c8:	6105                	addi	sp,sp,32
    800027ca:	8082                	ret
    return p->trapframe->a1;
    800027cc:	6d3c                	ld	a5,88(a0)
    800027ce:	7fa8                	ld	a0,120(a5)
    800027d0:	bfcd                	j	800027c2 <argraw+0x2c>
    return p->trapframe->a2;
    800027d2:	6d3c                	ld	a5,88(a0)
    800027d4:	63c8                	ld	a0,128(a5)
    800027d6:	b7f5                	j	800027c2 <argraw+0x2c>
    return p->trapframe->a3;
    800027d8:	6d3c                	ld	a5,88(a0)
    800027da:	67c8                	ld	a0,136(a5)
    800027dc:	b7dd                	j	800027c2 <argraw+0x2c>
    return p->trapframe->a4;
    800027de:	6d3c                	ld	a5,88(a0)
    800027e0:	6bc8                	ld	a0,144(a5)
    800027e2:	b7c5                	j	800027c2 <argraw+0x2c>
    return p->trapframe->a5;
    800027e4:	6d3c                	ld	a5,88(a0)
    800027e6:	6fc8                	ld	a0,152(a5)
    800027e8:	bfe9                	j	800027c2 <argraw+0x2c>
  panic("argraw");
    800027ea:	00005517          	auipc	a0,0x5
    800027ee:	b9e50513          	addi	a0,a0,-1122 # 80007388 <etext+0x388>
    800027f2:	856fe0ef          	jal	80000848 <panic>

00000000800027f6 <fetchaddr>:
{
    800027f6:	1101                	addi	sp,sp,-32
    800027f8:	ec06                	sd	ra,24(sp)
    800027fa:	e822                	sd	s0,16(sp)
    800027fc:	e426                	sd	s1,8(sp)
    800027fe:	e04a                	sd	s2,0(sp)
    80002800:	1000                	addi	s0,sp,32
    80002802:	84aa                	mv	s1,a0
    80002804:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002806:	8dcff0ef          	jal	800018e2 <myproc>
  if (addr >= p->sz ||
    8000280a:	652c                	ld	a1,72(a0)
    8000280c:	02b4f663          	bgeu	s1,a1,80002838 <fetchaddr+0x42>
      addr + sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002810:	00848793          	addi	a5,s1,8
  if (addr >= p->sz ||
    80002814:	02f5e263          	bltu	a1,a5,80002838 <fetchaddr+0x42>
  if (copyin(p->pagetable, p->sz, (char *)ip, addr, sizeof(*ip)) != 0)
    80002818:	4721                	li	a4,8
    8000281a:	86a6                	mv	a3,s1
    8000281c:	864a                	mv	a2,s2
    8000281e:	6928                	ld	a0,80(a0)
    80002820:	dcdfe0ef          	jal	800015ec <copyin>
    80002824:	00a03533          	snez	a0,a0
    80002828:	40a0053b          	negw	a0,a0
}
    8000282c:	60e2                	ld	ra,24(sp)
    8000282e:	6442                	ld	s0,16(sp)
    80002830:	64a2                	ld	s1,8(sp)
    80002832:	6902                	ld	s2,0(sp)
    80002834:	6105                	addi	sp,sp,32
    80002836:	8082                	ret
    return -1;
    80002838:	557d                	li	a0,-1
    8000283a:	bfcd                	j	8000282c <fetchaddr+0x36>

000000008000283c <fetchstr>:
{
    8000283c:	7179                	addi	sp,sp,-48
    8000283e:	f406                	sd	ra,40(sp)
    80002840:	f022                	sd	s0,32(sp)
    80002842:	ec26                	sd	s1,24(sp)
    80002844:	e84a                	sd	s2,16(sp)
    80002846:	e44e                	sd	s3,8(sp)
    80002848:	1800                	addi	s0,sp,48
    8000284a:	89aa                	mv	s3,a0
    8000284c:	84ae                	mv	s1,a1
    8000284e:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80002850:	892ff0ef          	jal	800018e2 <myproc>
  if (copyinstr(p->pagetable, p->sz, buf, addr, max) < 0)
    80002854:	874a                	mv	a4,s2
    80002856:	86ce                	mv	a3,s3
    80002858:	8626                	mv	a2,s1
    8000285a:	652c                	ld	a1,72(a0)
    8000285c:	6928                	ld	a0,80(a0)
    8000285e:	e2dfe0ef          	jal	8000168a <copyinstr>
    80002862:	00054c63          	bltz	a0,8000287a <fetchstr+0x3e>
  return strlen(buf);
    80002866:	8526                	mv	a0,s1
    80002868:	dccfe0ef          	jal	80000e34 <strlen>
}
    8000286c:	70a2                	ld	ra,40(sp)
    8000286e:	7402                	ld	s0,32(sp)
    80002870:	64e2                	ld	s1,24(sp)
    80002872:	6942                	ld	s2,16(sp)
    80002874:	69a2                	ld	s3,8(sp)
    80002876:	6145                	addi	sp,sp,48
    80002878:	8082                	ret
    return -1;
    8000287a:	557d                	li	a0,-1
    8000287c:	bfc5                	j	8000286c <fetchstr+0x30>

000000008000287e <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    8000287e:	1101                	addi	sp,sp,-32
    80002880:	ec06                	sd	ra,24(sp)
    80002882:	e822                	sd	s0,16(sp)
    80002884:	e426                	sd	s1,8(sp)
    80002886:	1000                	addi	s0,sp,32
    80002888:	84ae                	mv	s1,a1
  *ip = argraw(n);
    8000288a:	f0dff0ef          	jal	80002796 <argraw>
    8000288e:	c088                	sw	a0,0(s1)
}
    80002890:	60e2                	ld	ra,24(sp)
    80002892:	6442                	ld	s0,16(sp)
    80002894:	64a2                	ld	s1,8(sp)
    80002896:	6105                	addi	sp,sp,32
    80002898:	8082                	ret

000000008000289a <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    8000289a:	1101                	addi	sp,sp,-32
    8000289c:	ec06                	sd	ra,24(sp)
    8000289e:	e822                	sd	s0,16(sp)
    800028a0:	e426                	sd	s1,8(sp)
    800028a2:	1000                	addi	s0,sp,32
    800028a4:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800028a6:	ef1ff0ef          	jal	80002796 <argraw>
    800028aa:	e088                	sd	a0,0(s1)
}
    800028ac:	60e2                	ld	ra,24(sp)
    800028ae:	6442                	ld	s0,16(sp)
    800028b0:	64a2                	ld	s1,8(sp)
    800028b2:	6105                	addi	sp,sp,32
    800028b4:	8082                	ret

00000000800028b6 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (not including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    800028b6:	1101                	addi	sp,sp,-32
    800028b8:	ec06                	sd	ra,24(sp)
    800028ba:	e822                	sd	s0,16(sp)
    800028bc:	e426                	sd	s1,8(sp)
    800028be:	e04a                	sd	s2,0(sp)
    800028c0:	1000                	addi	s0,sp,32
    800028c2:	892e                	mv	s2,a1
    800028c4:	84b2                	mv	s1,a2
  *ip = argraw(n);
    800028c6:	ed1ff0ef          	jal	80002796 <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    800028ca:	8626                	mv	a2,s1
    800028cc:	85ca                	mv	a1,s2
    800028ce:	f6fff0ef          	jal	8000283c <fetchstr>
}
    800028d2:	60e2                	ld	ra,24(sp)
    800028d4:	6442                	ld	s0,16(sp)
    800028d6:	64a2                	ld	s1,8(sp)
    800028d8:	6902                	ld	s2,0(sp)
    800028da:	6105                	addi	sp,sp,32
    800028dc:	8082                	ret

00000000800028de <syscall>:
  // clang-format on
};

void
syscall(void)
{
    800028de:	1101                	addi	sp,sp,-32
    800028e0:	ec06                	sd	ra,24(sp)
    800028e2:	e822                	sd	s0,16(sp)
    800028e4:	e426                	sd	s1,8(sp)
    800028e6:	e04a                	sd	s2,0(sp)
    800028e8:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    800028ea:	ff9fe0ef          	jal	800018e2 <myproc>
    800028ee:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    800028f0:	05853903          	ld	s2,88(a0)
    800028f4:	0a893783          	ld	a5,168(s2)
    800028f8:	0007869b          	sext.w	a3,a5
  if (num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    800028fc:	37fd                	addiw	a5,a5,-1
    800028fe:	4759                	li	a4,22
    80002900:	00f76f63          	bltu	a4,a5,8000291e <syscall+0x40>
    80002904:	00369713          	slli	a4,a3,0x3
    80002908:	00005797          	auipc	a5,0x5
    8000290c:	e8878793          	addi	a5,a5,-376 # 80007790 <syscalls>
    80002910:	97ba                	add	a5,a5,a4
    80002912:	639c                	ld	a5,0(a5)
    80002914:	c789                	beqz	a5,8000291e <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002916:	9782                	jalr	a5
    80002918:	06a93823          	sd	a0,112(s2)
    8000291c:	a829                	j	80002936 <syscall+0x58>
  } else {
    printk("%d %s: unknown sys call %d\n", p->pid, p->name, num);
    8000291e:	15848613          	addi	a2,s1,344
    80002922:	588c                	lw	a1,48(s1)
    80002924:	00005517          	auipc	a0,0x5
    80002928:	a6c50513          	addi	a0,a0,-1428 # 80007390 <etext+0x390>
    8000292c:	be5fd0ef          	jal	80000510 <printk>
    p->trapframe->a0 = -1;
    80002930:	6cbc                	ld	a5,88(s1)
    80002932:	577d                	li	a4,-1
    80002934:	fbb8                	sd	a4,112(a5)
  }
}
    80002936:	60e2                	ld	ra,24(sp)
    80002938:	6442                	ld	s0,16(sp)
    8000293a:	64a2                	ld	s1,8(sp)
    8000293c:	6902                	ld	s2,0(sp)
    8000293e:	6105                	addi	sp,sp,32
    80002940:	8082                	ret

0000000080002942 <sys_exit>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    80002942:	1101                	addi	sp,sp,-32
    80002944:	ec06                	sd	ra,24(sp)
    80002946:	e822                	sd	s0,16(sp)
    80002948:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    8000294a:	fec40593          	addi	a1,s0,-20
    8000294e:	4501                	li	a0,0
    80002950:	f2fff0ef          	jal	8000287e <argint>
  kexit(n);
    80002954:	fec42503          	lw	a0,-20(s0)
    80002958:	ebaff0ef          	jal	80002012 <kexit>
  return 0; // not reached
}
    8000295c:	4501                	li	a0,0
    8000295e:	60e2                	ld	ra,24(sp)
    80002960:	6442                	ld	s0,16(sp)
    80002962:	6105                	addi	sp,sp,32
    80002964:	8082                	ret

0000000080002966 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002966:	1141                	addi	sp,sp,-16
    80002968:	e406                	sd	ra,8(sp)
    8000296a:	e022                	sd	s0,0(sp)
    8000296c:	0800                	addi	s0,sp,16
  return myproc()->pid;
    8000296e:	f75fe0ef          	jal	800018e2 <myproc>
}
    80002972:	5908                	lw	a0,48(a0)
    80002974:	60a2                	ld	ra,8(sp)
    80002976:	6402                	ld	s0,0(sp)
    80002978:	0141                	addi	sp,sp,16
    8000297a:	8082                	ret

000000008000297c <sys_fork>:

uint64
sys_fork(void)
{
    8000297c:	1141                	addi	sp,sp,-16
    8000297e:	e406                	sd	ra,8(sp)
    80002980:	e022                	sd	s0,0(sp)
    80002982:	0800                	addi	s0,sp,16
  return kfork();
    80002984:	ac8ff0ef          	jal	80001c4c <kfork>
}
    80002988:	60a2                	ld	ra,8(sp)
    8000298a:	6402                	ld	s0,0(sp)
    8000298c:	0141                	addi	sp,sp,16
    8000298e:	8082                	ret

0000000080002990 <sys_wait>:

uint64
sys_wait(void)
{
    80002990:	1101                	addi	sp,sp,-32
    80002992:	ec06                	sd	ra,24(sp)
    80002994:	e822                	sd	s0,16(sp)
    80002996:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002998:	fe840593          	addi	a1,s0,-24
    8000299c:	4501                	li	a0,0
    8000299e:	efdff0ef          	jal	8000289a <argaddr>
  return kwait(p);
    800029a2:	fe843503          	ld	a0,-24(s0)
    800029a6:	835ff0ef          	jal	800021da <kwait>
}
    800029aa:	60e2                	ld	ra,24(sp)
    800029ac:	6442                	ld	s0,16(sp)
    800029ae:	6105                	addi	sp,sp,32
    800029b0:	8082                	ret

00000000800029b2 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    800029b2:	7179                	addi	sp,sp,-48
    800029b4:	f406                	sd	ra,40(sp)
    800029b6:	f022                	sd	s0,32(sp)
    800029b8:	ec26                	sd	s1,24(sp)
    800029ba:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    800029bc:	fd840593          	addi	a1,s0,-40
    800029c0:	4501                	li	a0,0
    800029c2:	ebdff0ef          	jal	8000287e <argint>
  argint(1, &t);
    800029c6:	fdc40593          	addi	a1,s0,-36
    800029ca:	4505                	li	a0,1
    800029cc:	eb3ff0ef          	jal	8000287e <argint>
  addr = myproc()->sz;
    800029d0:	f13fe0ef          	jal	800018e2 <myproc>
    800029d4:	6524                	ld	s1,72(a0)

  if (t == SBRK_EAGER || n < 0) {
    800029d6:	fdc42703          	lw	a4,-36(s0)
    800029da:	4785                	li	a5,1
    800029dc:	02f70a63          	beq	a4,a5,80002a10 <sys_sbrk+0x5e>
    800029e0:	fd842783          	lw	a5,-40(s0)
    800029e4:	0207c663          	bltz	a5,80002a10 <sys_sbrk+0x5e>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if (addr + n < addr)
    800029e8:	00978733          	add	a4,a5,s1
      return -1;
    if (addr + n > TRAPFRAME)
    800029ec:	020007b7          	lui	a5,0x2000
    800029f0:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    800029f2:	07b6                	slli	a5,a5,0xd
    800029f4:	00e7b7b3          	sltu	a5,a5,a4
    if (addr + n < addr)
    800029f8:	00973733          	sltu	a4,a4,s1
    if (addr + n > TRAPFRAME)
    800029fc:	8fd9                	or	a5,a5,a4
    800029fe:	e79d                	bnez	a5,80002a2c <sys_sbrk+0x7a>
      return -1;
    myproc()->sz += n;
    80002a00:	ee3fe0ef          	jal	800018e2 <myproc>
    80002a04:	fd842703          	lw	a4,-40(s0)
    80002a08:	653c                	ld	a5,72(a0)
    80002a0a:	97ba                	add	a5,a5,a4
    80002a0c:	e53c                	sd	a5,72(a0)
    80002a0e:	a039                	j	80002a1c <sys_sbrk+0x6a>
    if (growproc(n) < 0) {
    80002a10:	fd842503          	lw	a0,-40(s0)
    80002a14:	9daff0ef          	jal	80001bee <growproc>
    80002a18:	00054863          	bltz	a0,80002a28 <sys_sbrk+0x76>
  }
  return addr;
}
    80002a1c:	8526                	mv	a0,s1
    80002a1e:	70a2                	ld	ra,40(sp)
    80002a20:	7402                	ld	s0,32(sp)
    80002a22:	64e2                	ld	s1,24(sp)
    80002a24:	6145                	addi	sp,sp,48
    80002a26:	8082                	ret
      return -1;
    80002a28:	54fd                	li	s1,-1
    80002a2a:	bfcd                	j	80002a1c <sys_sbrk+0x6a>
      return -1;
    80002a2c:	54fd                	li	s1,-1
    80002a2e:	b7fd                	j	80002a1c <sys_sbrk+0x6a>

0000000080002a30 <sys_pause>:

uint64
sys_pause(void)
{
    80002a30:	7139                	addi	sp,sp,-64
    80002a32:	fc06                	sd	ra,56(sp)
    80002a34:	f822                	sd	s0,48(sp)
    80002a36:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002a38:	fcc40593          	addi	a1,s0,-52
    80002a3c:	4501                	li	a0,0
    80002a3e:	e41ff0ef          	jal	8000287e <argint>
  if (n < 0)
    80002a42:	fcc42783          	lw	a5,-52(s0)
    80002a46:	0807c063          	bltz	a5,80002ac6 <sys_pause+0x96>
    n = 0;
  acquire(&tickslock);
    80002a4a:	00016517          	auipc	a0,0x16
    80002a4e:	80650513          	addi	a0,a0,-2042 # 80018250 <tickslock>
    80002a52:	9a6fe0ef          	jal	80000bf8 <acquire>
  ticks0 = ticks;
  while (ticks - ticks0 < n) {
    80002a56:	fcc42783          	lw	a5,-52(s0)
    80002a5a:	cbb9                	beqz	a5,80002ab0 <sys_pause+0x80>
    80002a5c:	f426                	sd	s1,40(sp)
    80002a5e:	f04a                	sd	s2,32(sp)
    80002a60:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80002a62:	00008997          	auipc	s3,0x8
    80002a66:	89e9a983          	lw	s3,-1890(s3) # 8000a300 <ticks>
    if (killed(myproc())) {
      release(&tickslock);
      return -1;
    }
    sleep_prepare(&ticks);
    80002a6a:	00008917          	auipc	s2,0x8
    80002a6e:	89690913          	addi	s2,s2,-1898 # 8000a300 <ticks>
    release(&tickslock);
    80002a72:	00015497          	auipc	s1,0x15
    80002a76:	7de48493          	addi	s1,s1,2014 # 80018250 <tickslock>
    if (killed(myproc())) {
    80002a7a:	e69fe0ef          	jal	800018e2 <myproc>
    80002a7e:	f32ff0ef          	jal	800021b0 <killed>
    80002a82:	e529                	bnez	a0,80002acc <sys_pause+0x9c>
    sleep_prepare(&ticks);
    80002a84:	854a                	mv	a0,s2
    80002a86:	c64ff0ef          	jal	80001eea <sleep_prepare>
    release(&tickslock);
    80002a8a:	8526                	mv	a0,s1
    80002a8c:	9f0fe0ef          	jal	80000c7c <release>
    sleep();
    80002a90:	c96ff0ef          	jal	80001f26 <sleep>
    acquire(&tickslock);
    80002a94:	8526                	mv	a0,s1
    80002a96:	962fe0ef          	jal	80000bf8 <acquire>
  while (ticks - ticks0 < n) {
    80002a9a:	00092783          	lw	a5,0(s2)
    80002a9e:	413787bb          	subw	a5,a5,s3
    80002aa2:	fcc42703          	lw	a4,-52(s0)
    80002aa6:	fce7eae3          	bltu	a5,a4,80002a7a <sys_pause+0x4a>
    80002aaa:	74a2                	ld	s1,40(sp)
    80002aac:	7902                	ld	s2,32(sp)
    80002aae:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002ab0:	00015517          	auipc	a0,0x15
    80002ab4:	7a050513          	addi	a0,a0,1952 # 80018250 <tickslock>
    80002ab8:	9c4fe0ef          	jal	80000c7c <release>
  return 0;
    80002abc:	4501                	li	a0,0
}
    80002abe:	70e2                	ld	ra,56(sp)
    80002ac0:	7442                	ld	s0,48(sp)
    80002ac2:	6121                	addi	sp,sp,64
    80002ac4:	8082                	ret
    n = 0;
    80002ac6:	fc042623          	sw	zero,-52(s0)
    80002aca:	b741                	j	80002a4a <sys_pause+0x1a>
      release(&tickslock);
    80002acc:	00015517          	auipc	a0,0x15
    80002ad0:	78450513          	addi	a0,a0,1924 # 80018250 <tickslock>
    80002ad4:	9a8fe0ef          	jal	80000c7c <release>
      return -1;
    80002ad8:	557d                	li	a0,-1
    80002ada:	74a2                	ld	s1,40(sp)
    80002adc:	7902                	ld	s2,32(sp)
    80002ade:	69e2                	ld	s3,24(sp)
    80002ae0:	bff9                	j	80002abe <sys_pause+0x8e>

0000000080002ae2 <sys_kill>:

uint64
sys_kill(void)
{
    80002ae2:	1101                	addi	sp,sp,-32
    80002ae4:	ec06                	sd	ra,24(sp)
    80002ae6:	e822                	sd	s0,16(sp)
    80002ae8:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002aea:	fec40593          	addi	a1,s0,-20
    80002aee:	4501                	li	a0,0
    80002af0:	d8fff0ef          	jal	8000287e <argint>
  return kkill(pid);
    80002af4:	fec42503          	lw	a0,-20(s0)
    80002af8:	dc0ff0ef          	jal	800020b8 <kkill>
}
    80002afc:	60e2                	ld	ra,24(sp)
    80002afe:	6442                	ld	s0,16(sp)
    80002b00:	6105                	addi	sp,sp,32
    80002b02:	8082                	ret

0000000080002b04 <sys_getfilenum>:

uint64
sys_getfilenum(void)
{
    80002b04:	1101                	addi	sp,sp,-32
    80002b06:	ec06                	sd	ra,24(sp)
    80002b08:	e822                	sd	s0,16(sp)
    80002b0a:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002b0c:	fec40593          	addi	a1,s0,-20
    80002b10:	4501                	li	a0,0
    80002b12:	d6dff0ef          	jal	8000287e <argint>
  return getfilenum(pid);
    80002b16:	fec42503          	lw	a0,-20(s0)
    80002b1a:	e04ff0ef          	jal	8000211e <getfilenum>
}
    80002b1e:	60e2                	ld	ra,24(sp)
    80002b20:	6442                	ld	s0,16(sp)
    80002b22:	6105                	addi	sp,sp,32
    80002b24:	8082                	ret

0000000080002b26 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002b26:	1101                	addi	sp,sp,-32
    80002b28:	ec06                	sd	ra,24(sp)
    80002b2a:	e822                	sd	s0,16(sp)
    80002b2c:	e426                	sd	s1,8(sp)
    80002b2e:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002b30:	00015517          	auipc	a0,0x15
    80002b34:	72050513          	addi	a0,a0,1824 # 80018250 <tickslock>
    80002b38:	8c0fe0ef          	jal	80000bf8 <acquire>
  xticks = ticks;
    80002b3c:	00007797          	auipc	a5,0x7
    80002b40:	7c47a783          	lw	a5,1988(a5) # 8000a300 <ticks>
    80002b44:	84be                	mv	s1,a5
  release(&tickslock);
    80002b46:	00015517          	auipc	a0,0x15
    80002b4a:	70a50513          	addi	a0,a0,1802 # 80018250 <tickslock>
    80002b4e:	92efe0ef          	jal	80000c7c <release>
  return xticks;
}
    80002b52:	02049513          	slli	a0,s1,0x20
    80002b56:	9101                	srli	a0,a0,0x20
    80002b58:	60e2                	ld	ra,24(sp)
    80002b5a:	6442                	ld	s0,16(sp)
    80002b5c:	64a2                	ld	s1,8(sp)
    80002b5e:	6105                	addi	sp,sp,32
    80002b60:	8082                	ret

0000000080002b62 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002b62:	7179                	addi	sp,sp,-48
    80002b64:	f406                	sd	ra,40(sp)
    80002b66:	f022                	sd	s0,32(sp)
    80002b68:	ec26                	sd	s1,24(sp)
    80002b6a:	e84a                	sd	s2,16(sp)
    80002b6c:	e44e                	sd	s3,8(sp)
    80002b6e:	e052                	sd	s4,0(sp)
    80002b70:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002b72:	00005597          	auipc	a1,0x5
    80002b76:	83e58593          	addi	a1,a1,-1986 # 800073b0 <etext+0x3b0>
    80002b7a:	00015517          	auipc	a0,0x15
    80002b7e:	6ee50513          	addi	a0,a0,1774 # 80018268 <bcache>
    80002b82:	ff7fd0ef          	jal	80000b78 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002b86:	0001d797          	auipc	a5,0x1d
    80002b8a:	6e278793          	addi	a5,a5,1762 # 80020268 <bcache+0x8000>
    80002b8e:	0001e717          	auipc	a4,0x1e
    80002b92:	94270713          	addi	a4,a4,-1726 # 800204d0 <bcache+0x8268>
    80002b96:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002b9a:	2ae7bc23          	sd	a4,696(a5)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002b9e:	00015497          	auipc	s1,0x15
    80002ba2:	6e248493          	addi	s1,s1,1762 # 80018280 <bcache+0x18>
    b->next = bcache.head.next;
    80002ba6:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002ba8:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002baa:	00005a17          	auipc	s4,0x5
    80002bae:	80ea0a13          	addi	s4,s4,-2034 # 800073b8 <etext+0x3b8>
    b->next = bcache.head.next;
    80002bb2:	2b893783          	ld	a5,696(s2)
    80002bb6:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002bb8:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002bbc:	85d2                	mv	a1,s4
    80002bbe:	01048513          	addi	a0,s1,16
    80002bc2:	41a010ef          	jal	80003fdc <initsleeplock>
    bcache.head.next->prev = b;
    80002bc6:	2b893783          	ld	a5,696(s2)
    80002bca:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002bcc:	2a993c23          	sd	s1,696(s2)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002bd0:	45848493          	addi	s1,s1,1112
    80002bd4:	fd349fe3          	bne	s1,s3,80002bb2 <binit+0x50>
  }
}
    80002bd8:	70a2                	ld	ra,40(sp)
    80002bda:	7402                	ld	s0,32(sp)
    80002bdc:	64e2                	ld	s1,24(sp)
    80002bde:	6942                	ld	s2,16(sp)
    80002be0:	69a2                	ld	s3,8(sp)
    80002be2:	6a02                	ld	s4,0(sp)
    80002be4:	6145                	addi	sp,sp,48
    80002be6:	8082                	ret

0000000080002be8 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf *
bread(uint dev, uint blockno)
{
    80002be8:	7179                	addi	sp,sp,-48
    80002bea:	f406                	sd	ra,40(sp)
    80002bec:	f022                	sd	s0,32(sp)
    80002bee:	ec26                	sd	s1,24(sp)
    80002bf0:	e84a                	sd	s2,16(sp)
    80002bf2:	e44e                	sd	s3,8(sp)
    80002bf4:	1800                	addi	s0,sp,48
    80002bf6:	892a                	mv	s2,a0
    80002bf8:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002bfa:	00015517          	auipc	a0,0x15
    80002bfe:	66e50513          	addi	a0,a0,1646 # 80018268 <bcache>
    80002c02:	ff7fd0ef          	jal	80000bf8 <acquire>
  for (b = bcache.head.next; b != &bcache.head; b = b->next) {
    80002c06:	0001e497          	auipc	s1,0x1e
    80002c0a:	91a4b483          	ld	s1,-1766(s1) # 80020520 <bcache+0x82b8>
    80002c0e:	0001e797          	auipc	a5,0x1e
    80002c12:	8c278793          	addi	a5,a5,-1854 # 800204d0 <bcache+0x8268>
    80002c16:	02f48b63          	beq	s1,a5,80002c4c <bread+0x64>
    80002c1a:	873e                	mv	a4,a5
    80002c1c:	a021                	j	80002c24 <bread+0x3c>
    80002c1e:	68a4                	ld	s1,80(s1)
    80002c20:	02e48663          	beq	s1,a4,80002c4c <bread+0x64>
    if (b->dev == dev && b->blockno == blockno) {
    80002c24:	449c                	lw	a5,8(s1)
    80002c26:	ff279ce3          	bne	a5,s2,80002c1e <bread+0x36>
    80002c2a:	44dc                	lw	a5,12(s1)
    80002c2c:	ff3799e3          	bne	a5,s3,80002c1e <bread+0x36>
      b->refcnt++;
    80002c30:	40bc                	lw	a5,64(s1)
    80002c32:	2785                	addiw	a5,a5,1
    80002c34:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002c36:	00015517          	auipc	a0,0x15
    80002c3a:	63250513          	addi	a0,a0,1586 # 80018268 <bcache>
    80002c3e:	83efe0ef          	jal	80000c7c <release>
      acquiresleep(&b->lock);
    80002c42:	01048513          	addi	a0,s1,16
    80002c46:	3cc010ef          	jal	80004012 <acquiresleep>
      return b;
    80002c4a:	a889                	j	80002c9c <bread+0xb4>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002c4c:	0001e497          	auipc	s1,0x1e
    80002c50:	8cc4b483          	ld	s1,-1844(s1) # 80020518 <bcache+0x82b0>
    80002c54:	0001e797          	auipc	a5,0x1e
    80002c58:	87c78793          	addi	a5,a5,-1924 # 800204d0 <bcache+0x8268>
    80002c5c:	00f48863          	beq	s1,a5,80002c6c <bread+0x84>
    80002c60:	873e                	mv	a4,a5
    if (b->refcnt == 0) {
    80002c62:	40bc                	lw	a5,64(s1)
    80002c64:	cb91                	beqz	a5,80002c78 <bread+0x90>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002c66:	64a4                	ld	s1,72(s1)
    80002c68:	fee49de3          	bne	s1,a4,80002c62 <bread+0x7a>
  panic("bget: no buffers");
    80002c6c:	00004517          	auipc	a0,0x4
    80002c70:	75450513          	addi	a0,a0,1876 # 800073c0 <etext+0x3c0>
    80002c74:	bd5fd0ef          	jal	80000848 <panic>
      b->dev = dev;
    80002c78:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002c7c:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002c80:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002c84:	4785                	li	a5,1
    80002c86:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002c88:	00015517          	auipc	a0,0x15
    80002c8c:	5e050513          	addi	a0,a0,1504 # 80018268 <bcache>
    80002c90:	fedfd0ef          	jal	80000c7c <release>
      acquiresleep(&b->lock);
    80002c94:	01048513          	addi	a0,s1,16
    80002c98:	37a010ef          	jal	80004012 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if (!b->valid) {
    80002c9c:	409c                	lw	a5,0(s1)
    80002c9e:	cb89                	beqz	a5,80002cb0 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002ca0:	8526                	mv	a0,s1
    80002ca2:	70a2                	ld	ra,40(sp)
    80002ca4:	7402                	ld	s0,32(sp)
    80002ca6:	64e2                	ld	s1,24(sp)
    80002ca8:	6942                	ld	s2,16(sp)
    80002caa:	69a2                	ld	s3,8(sp)
    80002cac:	6145                	addi	sp,sp,48
    80002cae:	8082                	ret
    virtio_disk_rw(b, 0);
    80002cb0:	4581                	li	a1,0
    80002cb2:	8526                	mv	a0,s1
    80002cb4:	3ef020ef          	jal	800058a2 <virtio_disk_rw>
    b->valid = 1;
    80002cb8:	4785                	li	a5,1
    80002cba:	c09c                	sw	a5,0(s1)
  return b;
    80002cbc:	b7d5                	j	80002ca0 <bread+0xb8>

0000000080002cbe <bwrite>:

// Write b's contents to disk.  Must be locked.
// Only the log calls bwrite.
void
bwrite(struct buf *b)
{
    80002cbe:	1101                	addi	sp,sp,-32
    80002cc0:	ec06                	sd	ra,24(sp)
    80002cc2:	e822                	sd	s0,16(sp)
    80002cc4:	e426                	sd	s1,8(sp)
    80002cc6:	1000                	addi	s0,sp,32
    80002cc8:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002cca:	0541                	addi	a0,a0,16
    80002ccc:	3d2010ef          	jal	8000409e <holdingsleep>
    80002cd0:	c911                	beqz	a0,80002ce4 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002cd2:	4585                	li	a1,1
    80002cd4:	8526                	mv	a0,s1
    80002cd6:	3cd020ef          	jal	800058a2 <virtio_disk_rw>
}
    80002cda:	60e2                	ld	ra,24(sp)
    80002cdc:	6442                	ld	s0,16(sp)
    80002cde:	64a2                	ld	s1,8(sp)
    80002ce0:	6105                	addi	sp,sp,32
    80002ce2:	8082                	ret
    panic("bwrite");
    80002ce4:	00004517          	auipc	a0,0x4
    80002ce8:	6f450513          	addi	a0,a0,1780 # 800073d8 <etext+0x3d8>
    80002cec:	b5dfd0ef          	jal	80000848 <panic>

0000000080002cf0 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002cf0:	1101                	addi	sp,sp,-32
    80002cf2:	ec06                	sd	ra,24(sp)
    80002cf4:	e822                	sd	s0,16(sp)
    80002cf6:	e426                	sd	s1,8(sp)
    80002cf8:	e04a                	sd	s2,0(sp)
    80002cfa:	1000                	addi	s0,sp,32
    80002cfc:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002cfe:	01050913          	addi	s2,a0,16
    80002d02:	854a                	mv	a0,s2
    80002d04:	39a010ef          	jal	8000409e <holdingsleep>
    80002d08:	c125                	beqz	a0,80002d68 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    80002d0a:	854a                	mv	a0,s2
    80002d0c:	35a010ef          	jal	80004066 <releasesleep>

  acquire(&bcache.lock);
    80002d10:	00015517          	auipc	a0,0x15
    80002d14:	55850513          	addi	a0,a0,1368 # 80018268 <bcache>
    80002d18:	ee1fd0ef          	jal	80000bf8 <acquire>
  b->refcnt--;
    80002d1c:	40bc                	lw	a5,64(s1)
    80002d1e:	37fd                	addiw	a5,a5,-1
    80002d20:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002d22:	e79d                	bnez	a5,80002d50 <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002d24:	68b8                	ld	a4,80(s1)
    80002d26:	64bc                	ld	a5,72(s1)
    80002d28:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002d2a:	68b8                	ld	a4,80(s1)
    80002d2c:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002d2e:	0001d797          	auipc	a5,0x1d
    80002d32:	53a78793          	addi	a5,a5,1338 # 80020268 <bcache+0x8000>
    80002d36:	2b87b703          	ld	a4,696(a5)
    80002d3a:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002d3c:	0001d717          	auipc	a4,0x1d
    80002d40:	79470713          	addi	a4,a4,1940 # 800204d0 <bcache+0x8268>
    80002d44:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002d46:	2b87b703          	ld	a4,696(a5)
    80002d4a:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002d4c:	2a97bc23          	sd	s1,696(a5)
  }

  release(&bcache.lock);
    80002d50:	00015517          	auipc	a0,0x15
    80002d54:	51850513          	addi	a0,a0,1304 # 80018268 <bcache>
    80002d58:	f25fd0ef          	jal	80000c7c <release>
}
    80002d5c:	60e2                	ld	ra,24(sp)
    80002d5e:	6442                	ld	s0,16(sp)
    80002d60:	64a2                	ld	s1,8(sp)
    80002d62:	6902                	ld	s2,0(sp)
    80002d64:	6105                	addi	sp,sp,32
    80002d66:	8082                	ret
    panic("brelse");
    80002d68:	00004517          	auipc	a0,0x4
    80002d6c:	67850513          	addi	a0,a0,1656 # 800073e0 <etext+0x3e0>
    80002d70:	ad9fd0ef          	jal	80000848 <panic>

0000000080002d74 <bpin>:

void
bpin(struct buf *b)
{
    80002d74:	1101                	addi	sp,sp,-32
    80002d76:	ec06                	sd	ra,24(sp)
    80002d78:	e822                	sd	s0,16(sp)
    80002d7a:	e426                	sd	s1,8(sp)
    80002d7c:	1000                	addi	s0,sp,32
    80002d7e:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002d80:	00015517          	auipc	a0,0x15
    80002d84:	4e850513          	addi	a0,a0,1256 # 80018268 <bcache>
    80002d88:	e71fd0ef          	jal	80000bf8 <acquire>
  b->refcnt++;
    80002d8c:	40bc                	lw	a5,64(s1)
    80002d8e:	2785                	addiw	a5,a5,1
    80002d90:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002d92:	00015517          	auipc	a0,0x15
    80002d96:	4d650513          	addi	a0,a0,1238 # 80018268 <bcache>
    80002d9a:	ee3fd0ef          	jal	80000c7c <release>
}
    80002d9e:	60e2                	ld	ra,24(sp)
    80002da0:	6442                	ld	s0,16(sp)
    80002da2:	64a2                	ld	s1,8(sp)
    80002da4:	6105                	addi	sp,sp,32
    80002da6:	8082                	ret

0000000080002da8 <bunpin>:

void
bunpin(struct buf *b)
{
    80002da8:	1101                	addi	sp,sp,-32
    80002daa:	ec06                	sd	ra,24(sp)
    80002dac:	e822                	sd	s0,16(sp)
    80002dae:	e426                	sd	s1,8(sp)
    80002db0:	1000                	addi	s0,sp,32
    80002db2:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002db4:	00015517          	auipc	a0,0x15
    80002db8:	4b450513          	addi	a0,a0,1204 # 80018268 <bcache>
    80002dbc:	e3dfd0ef          	jal	80000bf8 <acquire>
  b->refcnt--;
    80002dc0:	40bc                	lw	a5,64(s1)
    80002dc2:	37fd                	addiw	a5,a5,-1
    80002dc4:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002dc6:	00015517          	auipc	a0,0x15
    80002dca:	4a250513          	addi	a0,a0,1186 # 80018268 <bcache>
    80002dce:	eaffd0ef          	jal	80000c7c <release>
}
    80002dd2:	60e2                	ld	ra,24(sp)
    80002dd4:	6442                	ld	s0,16(sp)
    80002dd6:	64a2                	ld	s1,8(sp)
    80002dd8:	6105                	addi	sp,sp,32
    80002dda:	8082                	ret

0000000080002ddc <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002ddc:	1101                	addi	sp,sp,-32
    80002dde:	ec06                	sd	ra,24(sp)
    80002de0:	e822                	sd	s0,16(sp)
    80002de2:	e426                	sd	s1,8(sp)
    80002de4:	e04a                	sd	s2,0(sp)
    80002de6:	1000                	addi	s0,sp,32
    80002de8:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002dea:	00d5d79b          	srliw	a5,a1,0xd
    80002dee:	0001e597          	auipc	a1,0x1e
    80002df2:	b565a583          	lw	a1,-1194(a1) # 80020944 <sb+0x1c>
    80002df6:	9dbd                	addw	a1,a1,a5
    80002df8:	df1ff0ef          	jal	80002be8 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002dfc:	0074f713          	andi	a4,s1,7
    80002e00:	4785                	li	a5,1
    80002e02:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80002e06:	14ce                	slli	s1,s1,0x33
  if ((bp->data[bi / 8] & m) == 0)
    80002e08:	90d9                	srli	s1,s1,0x36
    80002e0a:	00950733          	add	a4,a0,s1
    80002e0e:	05874703          	lbu	a4,88(a4)
    80002e12:	00e7f6b3          	and	a3,a5,a4
    80002e16:	c29d                	beqz	a3,80002e3c <bfree+0x60>
    80002e18:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi / 8] &= ~m;
    80002e1a:	94aa                	add	s1,s1,a0
    80002e1c:	fff7c793          	not	a5,a5
    80002e20:	8f7d                	and	a4,a4,a5
    80002e22:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002e26:	082010ef          	jal	80003ea8 <log_write>
  brelse(bp);
    80002e2a:	854a                	mv	a0,s2
    80002e2c:	ec5ff0ef          	jal	80002cf0 <brelse>
}
    80002e30:	60e2                	ld	ra,24(sp)
    80002e32:	6442                	ld	s0,16(sp)
    80002e34:	64a2                	ld	s1,8(sp)
    80002e36:	6902                	ld	s2,0(sp)
    80002e38:	6105                	addi	sp,sp,32
    80002e3a:	8082                	ret
    panic("freeing free block");
    80002e3c:	00004517          	auipc	a0,0x4
    80002e40:	5ac50513          	addi	a0,a0,1452 # 800073e8 <etext+0x3e8>
    80002e44:	a05fd0ef          	jal	80000848 <panic>

0000000080002e48 <balloc>:
{
    80002e48:	715d                	addi	sp,sp,-80
    80002e4a:	e486                	sd	ra,72(sp)
    80002e4c:	e0a2                	sd	s0,64(sp)
    80002e4e:	fc26                	sd	s1,56(sp)
    80002e50:	0880                	addi	s0,sp,80
  for (b = 0; b < sb.size; b += BPB) {
    80002e52:	0001e797          	auipc	a5,0x1e
    80002e56:	ada7a783          	lw	a5,-1318(a5) # 8002092c <sb+0x4>
    80002e5a:	0e078263          	beqz	a5,80002f3e <balloc+0xf6>
    80002e5e:	f84a                	sd	s2,48(sp)
    80002e60:	f44e                	sd	s3,40(sp)
    80002e62:	f052                	sd	s4,32(sp)
    80002e64:	ec56                	sd	s5,24(sp)
    80002e66:	e85a                	sd	s6,16(sp)
    80002e68:	e45e                	sd	s7,8(sp)
    80002e6a:	e062                	sd	s8,0(sp)
    80002e6c:	8baa                	mv	s7,a0
    80002e6e:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002e70:	0001eb17          	auipc	s6,0x1e
    80002e74:	ab8b0b13          	addi	s6,s6,-1352 # 80020928 <sb>
      m = 1 << (bi % 8);
    80002e78:	4985                	li	s3,1
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002e7a:	6a09                	lui	s4,0x2
  for (b = 0; b < sb.size; b += BPB) {
    80002e7c:	6c09                	lui	s8,0x2
    80002e7e:	a09d                	j	80002ee4 <balloc+0x9c>
        bp->data[bi / 8] |= m;           // Mark block in use.
    80002e80:	97ca                	add	a5,a5,s2
    80002e82:	8e55                	or	a2,a2,a3
    80002e84:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80002e88:	854a                	mv	a0,s2
    80002e8a:	01e010ef          	jal	80003ea8 <log_write>
        brelse(bp);
    80002e8e:	854a                	mv	a0,s2
    80002e90:	e61ff0ef          	jal	80002cf0 <brelse>
  bp = bread(dev, bno);
    80002e94:	85a6                	mv	a1,s1
    80002e96:	855e                	mv	a0,s7
    80002e98:	d51ff0ef          	jal	80002be8 <bread>
    80002e9c:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002e9e:	40000613          	li	a2,1024
    80002ea2:	4581                	li	a1,0
    80002ea4:	05850513          	addi	a0,a0,88
    80002ea8:	e0dfd0ef          	jal	80000cb4 <memset>
  log_write(bp);
    80002eac:	854a                	mv	a0,s2
    80002eae:	7fb000ef          	jal	80003ea8 <log_write>
  brelse(bp);
    80002eb2:	854a                	mv	a0,s2
    80002eb4:	e3dff0ef          	jal	80002cf0 <brelse>
        return b + bi;
    80002eb8:	7942                	ld	s2,48(sp)
    80002eba:	79a2                	ld	s3,40(sp)
    80002ebc:	7a02                	ld	s4,32(sp)
    80002ebe:	6ae2                	ld	s5,24(sp)
    80002ec0:	6b42                	ld	s6,16(sp)
    80002ec2:	6ba2                	ld	s7,8(sp)
    80002ec4:	6c02                	ld	s8,0(sp)
}
    80002ec6:	8526                	mv	a0,s1
    80002ec8:	60a6                	ld	ra,72(sp)
    80002eca:	6406                	ld	s0,64(sp)
    80002ecc:	74e2                	ld	s1,56(sp)
    80002ece:	6161                	addi	sp,sp,80
    80002ed0:	8082                	ret
    brelse(bp);
    80002ed2:	854a                	mv	a0,s2
    80002ed4:	e1dff0ef          	jal	80002cf0 <brelse>
  for (b = 0; b < sb.size; b += BPB) {
    80002ed8:	015c0abb          	addw	s5,s8,s5
    80002edc:	004b2783          	lw	a5,4(s6)
    80002ee0:	04faf863          	bgeu	s5,a5,80002f30 <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    80002ee4:	40dad59b          	sraiw	a1,s5,0xd
    80002ee8:	01cb2783          	lw	a5,28(s6)
    80002eec:	9dbd                	addw	a1,a1,a5
    80002eee:	855e                	mv	a0,s7
    80002ef0:	cf9ff0ef          	jal	80002be8 <bread>
    80002ef4:	892a                	mv	s2,a0
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002ef6:	004b2503          	lw	a0,4(s6)
    80002efa:	84d6                	mv	s1,s5
    80002efc:	4701                	li	a4,0
    80002efe:	fca4fae3          	bgeu	s1,a0,80002ed2 <balloc+0x8a>
      m = 1 << (bi % 8);
    80002f02:	00777693          	andi	a3,a4,7
    80002f06:	00d996bb          	sllw	a3,s3,a3
      if ((bp->data[bi / 8] & m) == 0) { // Is block free?
    80002f0a:	41f7579b          	sraiw	a5,a4,0x1f
    80002f0e:	01d7d79b          	srliw	a5,a5,0x1d
    80002f12:	9fb9                	addw	a5,a5,a4
    80002f14:	4037d79b          	sraiw	a5,a5,0x3
    80002f18:	00f90633          	add	a2,s2,a5
    80002f1c:	05864603          	lbu	a2,88(a2) # 1058 <_entry-0x7fffefa8>
    80002f20:	00c6f5b3          	and	a1,a3,a2
    80002f24:	ddb1                	beqz	a1,80002e80 <balloc+0x38>
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002f26:	2705                	addiw	a4,a4,1
    80002f28:	2485                	addiw	s1,s1,1
    80002f2a:	fd471ae3          	bne	a4,s4,80002efe <balloc+0xb6>
    80002f2e:	b755                	j	80002ed2 <balloc+0x8a>
    80002f30:	7942                	ld	s2,48(sp)
    80002f32:	79a2                	ld	s3,40(sp)
    80002f34:	7a02                	ld	s4,32(sp)
    80002f36:	6ae2                	ld	s5,24(sp)
    80002f38:	6b42                	ld	s6,16(sp)
    80002f3a:	6ba2                	ld	s7,8(sp)
    80002f3c:	6c02                	ld	s8,0(sp)
  printk("balloc: out of blocks\n");
    80002f3e:	00004517          	auipc	a0,0x4
    80002f42:	4c250513          	addi	a0,a0,1218 # 80007400 <etext+0x400>
    80002f46:	dcafd0ef          	jal	80000510 <printk>
  return 0;
    80002f4a:	4481                	li	s1,0
    80002f4c:	bfad                	j	80002ec6 <balloc+0x7e>

0000000080002f4e <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80002f4e:	7179                	addi	sp,sp,-48
    80002f50:	f406                	sd	ra,40(sp)
    80002f52:	f022                	sd	s0,32(sp)
    80002f54:	ec26                	sd	s1,24(sp)
    80002f56:	e84a                	sd	s2,16(sp)
    80002f58:	e44e                	sd	s3,8(sp)
    80002f5a:	1800                	addi	s0,sp,48
    80002f5c:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if (bn < NDIRECT) {
    80002f5e:	47ad                	li	a5,11
    80002f60:	02b7e363          	bltu	a5,a1,80002f86 <bmap+0x38>
    if ((addr = ip->addrs[bn]) == 0) {
    80002f64:	02059793          	slli	a5,a1,0x20
    80002f68:	01e7d593          	srli	a1,a5,0x1e
    80002f6c:	00b509b3          	add	s3,a0,a1
    80002f70:	0509a483          	lw	s1,80(s3)
    80002f74:	e0b5                	bnez	s1,80002fd8 <bmap+0x8a>
      addr = balloc(ip->dev);
    80002f76:	4108                	lw	a0,0(a0)
    80002f78:	ed1ff0ef          	jal	80002e48 <balloc>
    80002f7c:	84aa                	mv	s1,a0
      if (addr == 0)
    80002f7e:	cd29                	beqz	a0,80002fd8 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    80002f80:	04a9a823          	sw	a0,80(s3)
    80002f84:	a891                	j	80002fd8 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80002f86:	ff45879b          	addiw	a5,a1,-12
    80002f8a:	873e                	mv	a4,a5
    80002f8c:	89be                	mv	s3,a5

  if (bn < NINDIRECT) {
    80002f8e:	0ff00793          	li	a5,255
    80002f92:	06e7e763          	bltu	a5,a4,80003000 <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if ((addr = ip->addrs[NDIRECT]) == 0) {
    80002f96:	08052483          	lw	s1,128(a0)
    80002f9a:	e891                	bnez	s1,80002fae <bmap+0x60>
      addr = balloc(ip->dev);
    80002f9c:	4108                	lw	a0,0(a0)
    80002f9e:	eabff0ef          	jal	80002e48 <balloc>
    80002fa2:	84aa                	mv	s1,a0
      if (addr == 0)
    80002fa4:	c915                	beqz	a0,80002fd8 <bmap+0x8a>
    80002fa6:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002fa8:	08a92023          	sw	a0,128(s2)
    80002fac:	a011                	j	80002fb0 <bmap+0x62>
    80002fae:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80002fb0:	85a6                	mv	a1,s1
    80002fb2:	00092503          	lw	a0,0(s2)
    80002fb6:	c33ff0ef          	jal	80002be8 <bread>
    80002fba:	8a2a                	mv	s4,a0
    a = (uint *)bp->data;
    80002fbc:	05850793          	addi	a5,a0,88
    if ((addr = a[bn]) == 0) {
    80002fc0:	02099713          	slli	a4,s3,0x20
    80002fc4:	01e75593          	srli	a1,a4,0x1e
    80002fc8:	97ae                	add	a5,a5,a1
    80002fca:	89be                	mv	s3,a5
    80002fcc:	4384                	lw	s1,0(a5)
    80002fce:	cc89                	beqz	s1,80002fe8 <bmap+0x9a>
      if (addr) {
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80002fd0:	8552                	mv	a0,s4
    80002fd2:	d1fff0ef          	jal	80002cf0 <brelse>
    return addr;
    80002fd6:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80002fd8:	8526                	mv	a0,s1
    80002fda:	70a2                	ld	ra,40(sp)
    80002fdc:	7402                	ld	s0,32(sp)
    80002fde:	64e2                	ld	s1,24(sp)
    80002fe0:	6942                	ld	s2,16(sp)
    80002fe2:	69a2                	ld	s3,8(sp)
    80002fe4:	6145                	addi	sp,sp,48
    80002fe6:	8082                	ret
      addr = balloc(ip->dev);
    80002fe8:	00092503          	lw	a0,0(s2)
    80002fec:	e5dff0ef          	jal	80002e48 <balloc>
    80002ff0:	84aa                	mv	s1,a0
      if (addr) {
    80002ff2:	dd79                	beqz	a0,80002fd0 <bmap+0x82>
        a[bn] = addr;
    80002ff4:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    80002ff8:	8552                	mv	a0,s4
    80002ffa:	6af000ef          	jal	80003ea8 <log_write>
    80002ffe:	bfc9                	j	80002fd0 <bmap+0x82>
    80003000:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80003002:	00004517          	auipc	a0,0x4
    80003006:	41650513          	addi	a0,a0,1046 # 80007418 <etext+0x418>
    8000300a:	83ffd0ef          	jal	80000848 <panic>

000000008000300e <iget>:
{
    8000300e:	7179                	addi	sp,sp,-48
    80003010:	f406                	sd	ra,40(sp)
    80003012:	f022                	sd	s0,32(sp)
    80003014:	ec26                	sd	s1,24(sp)
    80003016:	e84a                	sd	s2,16(sp)
    80003018:	e44e                	sd	s3,8(sp)
    8000301a:	e052                	sd	s4,0(sp)
    8000301c:	1800                	addi	s0,sp,48
    8000301e:	89aa                	mv	s3,a0
    80003020:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80003022:	0001e517          	auipc	a0,0x1e
    80003026:	92650513          	addi	a0,a0,-1754 # 80020948 <itable>
    8000302a:	bcffd0ef          	jal	80000bf8 <acquire>
  empty = 0;
    8000302e:	4901                	li	s2,0
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    80003030:	0001e497          	auipc	s1,0x1e
    80003034:	93048493          	addi	s1,s1,-1744 # 80020960 <itable+0x18>
    80003038:	0001f697          	auipc	a3,0x1f
    8000303c:	3b868693          	addi	a3,a3,952 # 800223f0 <log>
    80003040:	a819                	j	80003056 <iget+0x48>
    if (empty == 0 && ip->ref == 0) // Remember empty slot.
    80003042:	0017b793          	seqz	a5,a5
    80003046:	00193713          	seqz	a4,s2
    8000304a:	8ff9                	and	a5,a5,a4
    8000304c:	eb85                	bnez	a5,8000307c <iget+0x6e>
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    8000304e:	08848493          	addi	s1,s1,136
    80003052:	02d48763          	beq	s1,a3,80003080 <iget+0x72>
    if (ip->ref > 0 && ip->dev == dev && ip->inum == inum) {
    80003056:	449c                	lw	a5,8(s1)
    80003058:	fef055e3          	blez	a5,80003042 <iget+0x34>
    8000305c:	4098                	lw	a4,0(s1)
    8000305e:	ff3718e3          	bne	a4,s3,8000304e <iget+0x40>
    80003062:	40d8                	lw	a4,4(s1)
    80003064:	ff4715e3          	bne	a4,s4,8000304e <iget+0x40>
      ip->ref++;
    80003068:	2785                	addiw	a5,a5,1
    8000306a:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    8000306c:	0001e517          	auipc	a0,0x1e
    80003070:	8dc50513          	addi	a0,a0,-1828 # 80020948 <itable>
    80003074:	c09fd0ef          	jal	80000c7c <release>
      return ip;
    80003078:	8926                	mv	s2,s1
    8000307a:	a025                	j	800030a2 <iget+0x94>
      empty = ip;
    8000307c:	8926                	mv	s2,s1
    8000307e:	bfc1                	j	8000304e <iget+0x40>
  if (empty == 0)
    80003080:	02090a63          	beqz	s2,800030b4 <iget+0xa6>
  ip->dev = dev;
    80003084:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    80003088:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    8000308c:	4785                	li	a5,1
    8000308e:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    80003092:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    80003096:	0001e517          	auipc	a0,0x1e
    8000309a:	8b250513          	addi	a0,a0,-1870 # 80020948 <itable>
    8000309e:	bdffd0ef          	jal	80000c7c <release>
}
    800030a2:	854a                	mv	a0,s2
    800030a4:	70a2                	ld	ra,40(sp)
    800030a6:	7402                	ld	s0,32(sp)
    800030a8:	64e2                	ld	s1,24(sp)
    800030aa:	6942                	ld	s2,16(sp)
    800030ac:	69a2                	ld	s3,8(sp)
    800030ae:	6a02                	ld	s4,0(sp)
    800030b0:	6145                	addi	sp,sp,48
    800030b2:	8082                	ret
    panic("iget: no inodes");
    800030b4:	00004517          	auipc	a0,0x4
    800030b8:	37c50513          	addi	a0,a0,892 # 80007430 <etext+0x430>
    800030bc:	f8cfd0ef          	jal	80000848 <panic>

00000000800030c0 <iinit>:
{
    800030c0:	7179                	addi	sp,sp,-48
    800030c2:	f406                	sd	ra,40(sp)
    800030c4:	f022                	sd	s0,32(sp)
    800030c6:	ec26                	sd	s1,24(sp)
    800030c8:	e84a                	sd	s2,16(sp)
    800030ca:	e44e                	sd	s3,8(sp)
    800030cc:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    800030ce:	00004597          	auipc	a1,0x4
    800030d2:	37258593          	addi	a1,a1,882 # 80007440 <etext+0x440>
    800030d6:	0001e517          	auipc	a0,0x1e
    800030da:	87250513          	addi	a0,a0,-1934 # 80020948 <itable>
    800030de:	a9bfd0ef          	jal	80000b78 <initlock>
  for (i = 0; i < NINODE; i++) {
    800030e2:	0001e497          	auipc	s1,0x1e
    800030e6:	88e48493          	addi	s1,s1,-1906 # 80020970 <itable+0x28>
    800030ea:	0001f997          	auipc	s3,0x1f
    800030ee:	31698993          	addi	s3,s3,790 # 80022400 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800030f2:	00004917          	auipc	s2,0x4
    800030f6:	35690913          	addi	s2,s2,854 # 80007448 <etext+0x448>
    800030fa:	85ca                	mv	a1,s2
    800030fc:	8526                	mv	a0,s1
    800030fe:	6df000ef          	jal	80003fdc <initsleeplock>
  for (i = 0; i < NINODE; i++) {
    80003102:	08848493          	addi	s1,s1,136
    80003106:	ff349ae3          	bne	s1,s3,800030fa <iinit+0x3a>
}
    8000310a:	70a2                	ld	ra,40(sp)
    8000310c:	7402                	ld	s0,32(sp)
    8000310e:	64e2                	ld	s1,24(sp)
    80003110:	6942                	ld	s2,16(sp)
    80003112:	69a2                	ld	s3,8(sp)
    80003114:	6145                	addi	sp,sp,48
    80003116:	8082                	ret

0000000080003118 <ialloc>:
{
    80003118:	7139                	addi	sp,sp,-64
    8000311a:	fc06                	sd	ra,56(sp)
    8000311c:	f822                	sd	s0,48(sp)
    8000311e:	0080                	addi	s0,sp,64
  for (inum = 1; inum < sb.ninodes; inum++) {
    80003120:	0001e717          	auipc	a4,0x1e
    80003124:	81472703          	lw	a4,-2028(a4) # 80020934 <sb+0xc>
    80003128:	4785                	li	a5,1
    8000312a:	06e7f063          	bgeu	a5,a4,8000318a <ialloc+0x72>
    8000312e:	f426                	sd	s1,40(sp)
    80003130:	f04a                	sd	s2,32(sp)
    80003132:	ec4e                	sd	s3,24(sp)
    80003134:	e852                	sd	s4,16(sp)
    80003136:	e456                	sd	s5,8(sp)
    80003138:	e05a                	sd	s6,0(sp)
    8000313a:	8aaa                	mv	s5,a0
    8000313c:	8b2e                	mv	s6,a1
    8000313e:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    80003140:	0001da17          	auipc	s4,0x1d
    80003144:	7e8a0a13          	addi	s4,s4,2024 # 80020928 <sb>
    80003148:	00495593          	srli	a1,s2,0x4
    8000314c:	018a2783          	lw	a5,24(s4)
    80003150:	9dbd                	addw	a1,a1,a5
    80003152:	8556                	mv	a0,s5
    80003154:	a95ff0ef          	jal	80002be8 <bread>
    80003158:	84aa                	mv	s1,a0
    dip = (struct dinode *)bp->data + inum % IPB;
    8000315a:	05850993          	addi	s3,a0,88
    8000315e:	00f97793          	andi	a5,s2,15
    80003162:	079a                	slli	a5,a5,0x6
    80003164:	99be                	add	s3,s3,a5
    if (dip->type == 0) { // a free inode
    80003166:	00099783          	lh	a5,0(s3)
    8000316a:	cb9d                	beqz	a5,800031a0 <ialloc+0x88>
    brelse(bp);
    8000316c:	b85ff0ef          	jal	80002cf0 <brelse>
  for (inum = 1; inum < sb.ninodes; inum++) {
    80003170:	0905                	addi	s2,s2,1
    80003172:	00ca2703          	lw	a4,12(s4)
    80003176:	0009079b          	sext.w	a5,s2
    8000317a:	fce7e7e3          	bltu	a5,a4,80003148 <ialloc+0x30>
    8000317e:	74a2                	ld	s1,40(sp)
    80003180:	7902                	ld	s2,32(sp)
    80003182:	69e2                	ld	s3,24(sp)
    80003184:	6a42                	ld	s4,16(sp)
    80003186:	6aa2                	ld	s5,8(sp)
    80003188:	6b02                	ld	s6,0(sp)
  printk("ialloc: no inodes\n");
    8000318a:	00004517          	auipc	a0,0x4
    8000318e:	2c650513          	addi	a0,a0,710 # 80007450 <etext+0x450>
    80003192:	b7efd0ef          	jal	80000510 <printk>
  return 0;
    80003196:	4501                	li	a0,0
}
    80003198:	70e2                	ld	ra,56(sp)
    8000319a:	7442                	ld	s0,48(sp)
    8000319c:	6121                	addi	sp,sp,64
    8000319e:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    800031a0:	04000613          	li	a2,64
    800031a4:	4581                	li	a1,0
    800031a6:	854e                	mv	a0,s3
    800031a8:	b0dfd0ef          	jal	80000cb4 <memset>
      dip->type = type;
    800031ac:	01699023          	sh	s6,0(s3)
      log_write(bp); // mark it allocated on the disk
    800031b0:	8526                	mv	a0,s1
    800031b2:	4f7000ef          	jal	80003ea8 <log_write>
      brelse(bp);
    800031b6:	8526                	mv	a0,s1
    800031b8:	b39ff0ef          	jal	80002cf0 <brelse>
      return iget(dev, inum);
    800031bc:	0009059b          	sext.w	a1,s2
    800031c0:	8556                	mv	a0,s5
    800031c2:	e4dff0ef          	jal	8000300e <iget>
    800031c6:	74a2                	ld	s1,40(sp)
    800031c8:	7902                	ld	s2,32(sp)
    800031ca:	69e2                	ld	s3,24(sp)
    800031cc:	6a42                	ld	s4,16(sp)
    800031ce:	6aa2                	ld	s5,8(sp)
    800031d0:	6b02                	ld	s6,0(sp)
    800031d2:	b7d9                	j	80003198 <ialloc+0x80>

00000000800031d4 <iupdate>:
{
    800031d4:	1101                	addi	sp,sp,-32
    800031d6:	ec06                	sd	ra,24(sp)
    800031d8:	e822                	sd	s0,16(sp)
    800031da:	e426                	sd	s1,8(sp)
    800031dc:	e04a                	sd	s2,0(sp)
    800031de:	1000                	addi	s0,sp,32
    800031e0:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800031e2:	415c                	lw	a5,4(a0)
    800031e4:	0047d79b          	srliw	a5,a5,0x4
    800031e8:	0001d597          	auipc	a1,0x1d
    800031ec:	7585a583          	lw	a1,1880(a1) # 80020940 <sb+0x18>
    800031f0:	9dbd                	addw	a1,a1,a5
    800031f2:	4108                	lw	a0,0(a0)
    800031f4:	9f5ff0ef          	jal	80002be8 <bread>
    800031f8:	892a                	mv	s2,a0
  dip = (struct dinode *)bp->data + ip->inum % IPB;
    800031fa:	05850793          	addi	a5,a0,88
    800031fe:	40d8                	lw	a4,4(s1)
    80003200:	8b3d                	andi	a4,a4,15
    80003202:	071a                	slli	a4,a4,0x6
    80003204:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80003206:	04449703          	lh	a4,68(s1)
    8000320a:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    8000320e:	04649703          	lh	a4,70(s1)
    80003212:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80003216:	04849703          	lh	a4,72(s1)
    8000321a:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    8000321e:	04a49703          	lh	a4,74(s1)
    80003222:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80003226:	44f8                	lw	a4,76(s1)
    80003228:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    8000322a:	03400613          	li	a2,52
    8000322e:	05048593          	addi	a1,s1,80
    80003232:	00c78513          	addi	a0,a5,12
    80003236:	adbfd0ef          	jal	80000d10 <memmove>
  log_write(bp);
    8000323a:	854a                	mv	a0,s2
    8000323c:	46d000ef          	jal	80003ea8 <log_write>
  brelse(bp);
    80003240:	854a                	mv	a0,s2
    80003242:	aafff0ef          	jal	80002cf0 <brelse>
}
    80003246:	60e2                	ld	ra,24(sp)
    80003248:	6442                	ld	s0,16(sp)
    8000324a:	64a2                	ld	s1,8(sp)
    8000324c:	6902                	ld	s2,0(sp)
    8000324e:	6105                	addi	sp,sp,32
    80003250:	8082                	ret

0000000080003252 <idup>:
{
    80003252:	1101                	addi	sp,sp,-32
    80003254:	ec06                	sd	ra,24(sp)
    80003256:	e822                	sd	s0,16(sp)
    80003258:	e426                	sd	s1,8(sp)
    8000325a:	1000                	addi	s0,sp,32
    8000325c:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000325e:	0001d517          	auipc	a0,0x1d
    80003262:	6ea50513          	addi	a0,a0,1770 # 80020948 <itable>
    80003266:	993fd0ef          	jal	80000bf8 <acquire>
  ip->ref++;
    8000326a:	449c                	lw	a5,8(s1)
    8000326c:	2785                	addiw	a5,a5,1
    8000326e:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003270:	0001d517          	auipc	a0,0x1d
    80003274:	6d850513          	addi	a0,a0,1752 # 80020948 <itable>
    80003278:	a05fd0ef          	jal	80000c7c <release>
}
    8000327c:	8526                	mv	a0,s1
    8000327e:	60e2                	ld	ra,24(sp)
    80003280:	6442                	ld	s0,16(sp)
    80003282:	64a2                	ld	s1,8(sp)
    80003284:	6105                	addi	sp,sp,32
    80003286:	8082                	ret

0000000080003288 <ilock>:
{
    80003288:	1101                	addi	sp,sp,-32
    8000328a:	ec06                	sd	ra,24(sp)
    8000328c:	e822                	sd	s0,16(sp)
    8000328e:	e426                	sd	s1,8(sp)
    80003290:	1000                	addi	s0,sp,32
  if (ip == 0 || ip->ref < 1)
    80003292:	cd19                	beqz	a0,800032b0 <ilock+0x28>
    80003294:	84aa                	mv	s1,a0
    80003296:	451c                	lw	a5,8(a0)
    80003298:	00f05c63          	blez	a5,800032b0 <ilock+0x28>
  acquiresleep(&ip->lock);
    8000329c:	0541                	addi	a0,a0,16
    8000329e:	575000ef          	jal	80004012 <acquiresleep>
  if (ip->valid == 0) {
    800032a2:	40bc                	lw	a5,64(s1)
    800032a4:	cf89                	beqz	a5,800032be <ilock+0x36>
}
    800032a6:	60e2                	ld	ra,24(sp)
    800032a8:	6442                	ld	s0,16(sp)
    800032aa:	64a2                	ld	s1,8(sp)
    800032ac:	6105                	addi	sp,sp,32
    800032ae:	8082                	ret
    800032b0:	e04a                	sd	s2,0(sp)
    panic("ilock");
    800032b2:	00004517          	auipc	a0,0x4
    800032b6:	1b650513          	addi	a0,a0,438 # 80007468 <etext+0x468>
    800032ba:	d8efd0ef          	jal	80000848 <panic>
    800032be:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800032c0:	40dc                	lw	a5,4(s1)
    800032c2:	0047d79b          	srliw	a5,a5,0x4
    800032c6:	0001d597          	auipc	a1,0x1d
    800032ca:	67a5a583          	lw	a1,1658(a1) # 80020940 <sb+0x18>
    800032ce:	9dbd                	addw	a1,a1,a5
    800032d0:	4088                	lw	a0,0(s1)
    800032d2:	917ff0ef          	jal	80002be8 <bread>
    800032d6:	892a                	mv	s2,a0
    dip = (struct dinode *)bp->data + ip->inum % IPB;
    800032d8:	05850593          	addi	a1,a0,88
    800032dc:	40dc                	lw	a5,4(s1)
    800032de:	8bbd                	andi	a5,a5,15
    800032e0:	079a                	slli	a5,a5,0x6
    800032e2:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800032e4:	00059783          	lh	a5,0(a1)
    800032e8:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800032ec:	00259783          	lh	a5,2(a1)
    800032f0:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800032f4:	00459783          	lh	a5,4(a1)
    800032f8:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800032fc:	00659783          	lh	a5,6(a1)
    80003300:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80003304:	459c                	lw	a5,8(a1)
    80003306:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80003308:	03400613          	li	a2,52
    8000330c:	05b1                	addi	a1,a1,12
    8000330e:	05048513          	addi	a0,s1,80
    80003312:	9fffd0ef          	jal	80000d10 <memmove>
    brelse(bp);
    80003316:	854a                	mv	a0,s2
    80003318:	9d9ff0ef          	jal	80002cf0 <brelse>
    ip->valid = 1;
    8000331c:	4785                	li	a5,1
    8000331e:	c0bc                	sw	a5,64(s1)
    if (ip->type == 0)
    80003320:	04449783          	lh	a5,68(s1)
    80003324:	c399                	beqz	a5,8000332a <ilock+0xa2>
    80003326:	6902                	ld	s2,0(sp)
    80003328:	bfbd                	j	800032a6 <ilock+0x1e>
      panic("ilock: no type");
    8000332a:	00004517          	auipc	a0,0x4
    8000332e:	14650513          	addi	a0,a0,326 # 80007470 <etext+0x470>
    80003332:	d16fd0ef          	jal	80000848 <panic>

0000000080003336 <iunlock>:
{
    80003336:	1101                	addi	sp,sp,-32
    80003338:	ec06                	sd	ra,24(sp)
    8000333a:	e822                	sd	s0,16(sp)
    8000333c:	e426                	sd	s1,8(sp)
    8000333e:	e04a                	sd	s2,0(sp)
    80003340:	1000                	addi	s0,sp,32
  if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80003342:	c505                	beqz	a0,8000336a <iunlock+0x34>
    80003344:	84aa                	mv	s1,a0
    80003346:	01050913          	addi	s2,a0,16
    8000334a:	854a                	mv	a0,s2
    8000334c:	553000ef          	jal	8000409e <holdingsleep>
    80003350:	cd09                	beqz	a0,8000336a <iunlock+0x34>
    80003352:	449c                	lw	a5,8(s1)
    80003354:	00f05b63          	blez	a5,8000336a <iunlock+0x34>
  releasesleep(&ip->lock);
    80003358:	854a                	mv	a0,s2
    8000335a:	50d000ef          	jal	80004066 <releasesleep>
}
    8000335e:	60e2                	ld	ra,24(sp)
    80003360:	6442                	ld	s0,16(sp)
    80003362:	64a2                	ld	s1,8(sp)
    80003364:	6902                	ld	s2,0(sp)
    80003366:	6105                	addi	sp,sp,32
    80003368:	8082                	ret
    panic("iunlock");
    8000336a:	00004517          	auipc	a0,0x4
    8000336e:	11650513          	addi	a0,a0,278 # 80007480 <etext+0x480>
    80003372:	cd6fd0ef          	jal	80000848 <panic>

0000000080003376 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80003376:	7179                	addi	sp,sp,-48
    80003378:	f406                	sd	ra,40(sp)
    8000337a:	f022                	sd	s0,32(sp)
    8000337c:	ec26                	sd	s1,24(sp)
    8000337e:	e84a                	sd	s2,16(sp)
    80003380:	e44e                	sd	s3,8(sp)
    80003382:	1800                	addi	s0,sp,48
    80003384:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for (i = 0; i < NDIRECT; i++) {
    80003386:	05050493          	addi	s1,a0,80
    8000338a:	08050913          	addi	s2,a0,128
    8000338e:	a021                	j	80003396 <itrunc+0x20>
    80003390:	0491                	addi	s1,s1,4
    80003392:	01248b63          	beq	s1,s2,800033a8 <itrunc+0x32>
    if (ip->addrs[i]) {
    80003396:	408c                	lw	a1,0(s1)
    80003398:	dde5                	beqz	a1,80003390 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    8000339a:	0009a503          	lw	a0,0(s3)
    8000339e:	a3fff0ef          	jal	80002ddc <bfree>
      ip->addrs[i] = 0;
    800033a2:	0004a023          	sw	zero,0(s1)
    800033a6:	b7ed                	j	80003390 <itrunc+0x1a>
    }
  }

  if (ip->addrs[NDIRECT]) {
    800033a8:	0809a583          	lw	a1,128(s3)
    800033ac:	ed89                	bnez	a1,800033c6 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800033ae:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800033b2:	854e                	mv	a0,s3
    800033b4:	e21ff0ef          	jal	800031d4 <iupdate>
}
    800033b8:	70a2                	ld	ra,40(sp)
    800033ba:	7402                	ld	s0,32(sp)
    800033bc:	64e2                	ld	s1,24(sp)
    800033be:	6942                	ld	s2,16(sp)
    800033c0:	69a2                	ld	s3,8(sp)
    800033c2:	6145                	addi	sp,sp,48
    800033c4:	8082                	ret
    800033c6:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800033c8:	0009a503          	lw	a0,0(s3)
    800033cc:	81dff0ef          	jal	80002be8 <bread>
    800033d0:	8a2a                	mv	s4,a0
    for (j = 0; j < NINDIRECT; j++) {
    800033d2:	05850493          	addi	s1,a0,88
    800033d6:	45850913          	addi	s2,a0,1112
    800033da:	a021                	j	800033e2 <itrunc+0x6c>
    800033dc:	0491                	addi	s1,s1,4
    800033de:	01248963          	beq	s1,s2,800033f0 <itrunc+0x7a>
      if (a[j])
    800033e2:	408c                	lw	a1,0(s1)
    800033e4:	dde5                	beqz	a1,800033dc <itrunc+0x66>
        bfree(ip->dev, a[j]);
    800033e6:	0009a503          	lw	a0,0(s3)
    800033ea:	9f3ff0ef          	jal	80002ddc <bfree>
    800033ee:	b7fd                	j	800033dc <itrunc+0x66>
    brelse(bp);
    800033f0:	8552                	mv	a0,s4
    800033f2:	8ffff0ef          	jal	80002cf0 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800033f6:	0809a583          	lw	a1,128(s3)
    800033fa:	0009a503          	lw	a0,0(s3)
    800033fe:	9dfff0ef          	jal	80002ddc <bfree>
    ip->addrs[NDIRECT] = 0;
    80003402:	0809a023          	sw	zero,128(s3)
    80003406:	6a02                	ld	s4,0(sp)
    80003408:	b75d                	j	800033ae <itrunc+0x38>

000000008000340a <iput>:
{
    8000340a:	7179                	addi	sp,sp,-48
    8000340c:	f406                	sd	ra,40(sp)
    8000340e:	f022                	sd	s0,32(sp)
    80003410:	ec26                	sd	s1,24(sp)
    80003412:	1800                	addi	s0,sp,48
    80003414:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003416:	0001d517          	auipc	a0,0x1d
    8000341a:	53250513          	addi	a0,a0,1330 # 80020948 <itable>
    8000341e:	fdafd0ef          	jal	80000bf8 <acquire>
  int last = (ip->ref == 1 && ip->valid && ip->nlink == 0);
    80003422:	449c                	lw	a5,8(s1)
    80003424:	4705                	li	a4,1
    80003426:	00e78f63          	beq	a5,a4,80003444 <iput+0x3a>
  ip->ref--;
    8000342a:	37fd                	addiw	a5,a5,-1
    8000342c:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000342e:	0001d517          	auipc	a0,0x1d
    80003432:	51a50513          	addi	a0,a0,1306 # 80020948 <itable>
    80003436:	847fd0ef          	jal	80000c7c <release>
}
    8000343a:	70a2                	ld	ra,40(sp)
    8000343c:	7402                	ld	s0,32(sp)
    8000343e:	64e2                	ld	s1,24(sp)
    80003440:	6145                	addi	sp,sp,48
    80003442:	8082                	ret
  int last = (ip->ref == 1 && ip->valid && ip->nlink == 0);
    80003444:	40b8                	lw	a4,64(s1)
    80003446:	d375                	beqz	a4,8000342a <iput+0x20>
    80003448:	e84a                	sd	s2,16(sp)
    8000344a:	e052                	sd	s4,0(sp)
  uint dev = ip->dev, inum = ip->inum;
    8000344c:	0004aa03          	lw	s4,0(s1)
    80003450:	0044a903          	lw	s2,4(s1)
  if (last) {
    80003454:	04a49703          	lh	a4,74(s1)
    80003458:	ef3d                	bnez	a4,800034d6 <iput+0xcc>
    8000345a:	e44e                	sd	s3,8(sp)
    acquiresleep(&ip->lock);
    8000345c:	01048793          	addi	a5,s1,16
    80003460:	89be                	mv	s3,a5
    80003462:	853e                	mv	a0,a5
    80003464:	3af000ef          	jal	80004012 <acquiresleep>
    release(&itable.lock);
    80003468:	0001d517          	auipc	a0,0x1d
    8000346c:	4e050513          	addi	a0,a0,1248 # 80020948 <itable>
    80003470:	80dfd0ef          	jal	80000c7c <release>
    itrunc(ip); // free the data blocks (type stays nonzero on disk)
    80003474:	8526                	mv	a0,s1
    80003476:	f01ff0ef          	jal	80003376 <itrunc>
    ip->valid = 0;
    8000347a:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    8000347e:	854e                	mv	a0,s3
    80003480:	3e7000ef          	jal	80004066 <releasesleep>
    acquire(&itable.lock);
    80003484:	0001d517          	auipc	a0,0x1d
    80003488:	4c450513          	addi	a0,a0,1220 # 80020948 <itable>
    8000348c:	f6cfd0ef          	jal	80000bf8 <acquire>
  ip->ref--;
    80003490:	449c                	lw	a5,8(s1)
    80003492:	37fd                	addiw	a5,a5,-1
    80003494:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003496:	0001d517          	auipc	a0,0x1d
    8000349a:	4b250513          	addi	a0,a0,1202 # 80020948 <itable>
    8000349e:	fdefd0ef          	jal	80000c7c <release>
  struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800034a2:	0049579b          	srliw	a5,s2,0x4
    800034a6:	0001d597          	auipc	a1,0x1d
    800034aa:	49a5a583          	lw	a1,1178(a1) # 80020940 <sb+0x18>
    800034ae:	9dbd                	addw	a1,a1,a5
    800034b0:	8552                	mv	a0,s4
    800034b2:	f36ff0ef          	jal	80002be8 <bread>
    800034b6:	84aa                	mv	s1,a0
  struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    800034b8:	00f97793          	andi	a5,s2,15
  dip->type = 0;
    800034bc:	079a                	slli	a5,a5,0x6
    800034be:	97aa                	add	a5,a5,a0
    800034c0:	04079c23          	sh	zero,88(a5)
  log_write(bp);
    800034c4:	1e5000ef          	jal	80003ea8 <log_write>
  brelse(bp);
    800034c8:	8526                	mv	a0,s1
    800034ca:	827ff0ef          	jal	80002cf0 <brelse>
}
    800034ce:	6942                	ld	s2,16(sp)
    800034d0:	69a2                	ld	s3,8(sp)
    800034d2:	6a02                	ld	s4,0(sp)
    800034d4:	b79d                	j	8000343a <iput+0x30>
    800034d6:	6942                	ld	s2,16(sp)
    800034d8:	6a02                	ld	s4,0(sp)
    800034da:	bf81                	j	8000342a <iput+0x20>

00000000800034dc <iunlockput>:
{
    800034dc:	1101                	addi	sp,sp,-32
    800034de:	ec06                	sd	ra,24(sp)
    800034e0:	e822                	sd	s0,16(sp)
    800034e2:	e426                	sd	s1,8(sp)
    800034e4:	1000                	addi	s0,sp,32
    800034e6:	84aa                	mv	s1,a0
  iunlock(ip);
    800034e8:	e4fff0ef          	jal	80003336 <iunlock>
  iput(ip);
    800034ec:	8526                	mv	a0,s1
    800034ee:	f1dff0ef          	jal	8000340a <iput>
}
    800034f2:	60e2                	ld	ra,24(sp)
    800034f4:	6442                	ld	s0,16(sp)
    800034f6:	64a2                	ld	s1,8(sp)
    800034f8:	6105                	addi	sp,sp,32
    800034fa:	8082                	ret

00000000800034fc <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800034fc:	0001d717          	auipc	a4,0x1d
    80003500:	43872703          	lw	a4,1080(a4) # 80020934 <sb+0xc>
    80003504:	4785                	li	a5,1
    80003506:	0ae7fe63          	bgeu	a5,a4,800035c2 <ireclaim+0xc6>
{
    8000350a:	7139                	addi	sp,sp,-64
    8000350c:	fc06                	sd	ra,56(sp)
    8000350e:	f822                	sd	s0,48(sp)
    80003510:	f426                	sd	s1,40(sp)
    80003512:	f04a                	sd	s2,32(sp)
    80003514:	ec4e                	sd	s3,24(sp)
    80003516:	e852                	sd	s4,16(sp)
    80003518:	e456                	sd	s5,8(sp)
    8000351a:	e05a                	sd	s6,0(sp)
    8000351c:	0080                	addi	s0,sp,64
    8000351e:	8aaa                	mv	s5,a0
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003520:	84be                	mv	s1,a5
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003522:	0001da17          	auipc	s4,0x1d
    80003526:	406a0a13          	addi	s4,s4,1030 # 80020928 <sb>
      printk("ireclaim: orphaned inode %d\n", inum);
    8000352a:	00004b17          	auipc	s6,0x4
    8000352e:	f5eb0b13          	addi	s6,s6,-162 # 80007488 <etext+0x488>
    80003532:	a099                	j	80003578 <ireclaim+0x7c>
    80003534:	85ce                	mv	a1,s3
    80003536:	855a                	mv	a0,s6
    80003538:	fd9fc0ef          	jal	80000510 <printk>
      ip = iget(dev, inum);
    8000353c:	85ce                	mv	a1,s3
    8000353e:	8556                	mv	a0,s5
    80003540:	acfff0ef          	jal	8000300e <iget>
    80003544:	89aa                	mv	s3,a0
    brelse(bp);
    80003546:	854a                	mv	a0,s2
    80003548:	fa8ff0ef          	jal	80002cf0 <brelse>
    if (ip) {
    8000354c:	00098f63          	beqz	s3,8000356a <ireclaim+0x6e>
      begin_op();
    80003550:	7aa000ef          	jal	80003cfa <begin_op>
      ilock(ip);
    80003554:	854e                	mv	a0,s3
    80003556:	d33ff0ef          	jal	80003288 <ilock>
      iunlock(ip);
    8000355a:	854e                	mv	a0,s3
    8000355c:	ddbff0ef          	jal	80003336 <iunlock>
      iput(ip);
    80003560:	854e                	mv	a0,s3
    80003562:	ea9ff0ef          	jal	8000340a <iput>
      end_op();
    80003566:	021000ef          	jal	80003d86 <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    8000356a:	0485                	addi	s1,s1,1
    8000356c:	00ca2703          	lw	a4,12(s4)
    80003570:	0004879b          	sext.w	a5,s1
    80003574:	02e7fd63          	bgeu	a5,a4,800035ae <ireclaim+0xb2>
    80003578:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    8000357c:	0044d593          	srli	a1,s1,0x4
    80003580:	018a2783          	lw	a5,24(s4)
    80003584:	9dbd                	addw	a1,a1,a5
    80003586:	8556                	mv	a0,s5
    80003588:	e60ff0ef          	jal	80002be8 <bread>
    8000358c:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    8000358e:	05850793          	addi	a5,a0,88
    80003592:	00f9f713          	andi	a4,s3,15
    80003596:	071a                	slli	a4,a4,0x6
    80003598:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) { // is an orphaned inode
    8000359a:	00079703          	lh	a4,0(a5)
    8000359e:	c701                	beqz	a4,800035a6 <ireclaim+0xaa>
    800035a0:	00679783          	lh	a5,6(a5)
    800035a4:	dbc1                	beqz	a5,80003534 <ireclaim+0x38>
    brelse(bp);
    800035a6:	854a                	mv	a0,s2
    800035a8:	f48ff0ef          	jal	80002cf0 <brelse>
    if (ip) {
    800035ac:	bf7d                	j	8000356a <ireclaim+0x6e>
}
    800035ae:	70e2                	ld	ra,56(sp)
    800035b0:	7442                	ld	s0,48(sp)
    800035b2:	74a2                	ld	s1,40(sp)
    800035b4:	7902                	ld	s2,32(sp)
    800035b6:	69e2                	ld	s3,24(sp)
    800035b8:	6a42                	ld	s4,16(sp)
    800035ba:	6aa2                	ld	s5,8(sp)
    800035bc:	6b02                	ld	s6,0(sp)
    800035be:	6121                	addi	sp,sp,64
    800035c0:	8082                	ret
    800035c2:	8082                	ret

00000000800035c4 <fsinit>:
{
    800035c4:	1101                	addi	sp,sp,-32
    800035c6:	ec06                	sd	ra,24(sp)
    800035c8:	e822                	sd	s0,16(sp)
    800035ca:	e426                	sd	s1,8(sp)
    800035cc:	e04a                	sd	s2,0(sp)
    800035ce:	1000                	addi	s0,sp,32
    800035d0:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    800035d2:	4585                	li	a1,1
    800035d4:	e14ff0ef          	jal	80002be8 <bread>
    800035d8:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    800035da:	02000613          	li	a2,32
    800035de:	05850593          	addi	a1,a0,88
    800035e2:	0001d517          	auipc	a0,0x1d
    800035e6:	34650513          	addi	a0,a0,838 # 80020928 <sb>
    800035ea:	f26fd0ef          	jal	80000d10 <memmove>
  brelse(bp);
    800035ee:	8526                	mv	a0,s1
    800035f0:	f00ff0ef          	jal	80002cf0 <brelse>
  if (sb.magic != FSMAGIC)
    800035f4:	0001d717          	auipc	a4,0x1d
    800035f8:	33472703          	lw	a4,820(a4) # 80020928 <sb>
    800035fc:	102037b7          	lui	a5,0x10203
    80003600:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80003604:	02f71263          	bne	a4,a5,80003628 <fsinit+0x64>
  initlog(dev, &sb);
    80003608:	0001d597          	auipc	a1,0x1d
    8000360c:	32058593          	addi	a1,a1,800 # 80020928 <sb>
    80003610:	854a                	mv	a0,s2
    80003612:	666000ef          	jal	80003c78 <initlog>
  ireclaim(dev);
    80003616:	854a                	mv	a0,s2
    80003618:	ee5ff0ef          	jal	800034fc <ireclaim>
}
    8000361c:	60e2                	ld	ra,24(sp)
    8000361e:	6442                	ld	s0,16(sp)
    80003620:	64a2                	ld	s1,8(sp)
    80003622:	6902                	ld	s2,0(sp)
    80003624:	6105                	addi	sp,sp,32
    80003626:	8082                	ret
    panic("invalid file system");
    80003628:	00004517          	auipc	a0,0x4
    8000362c:	e8050513          	addi	a0,a0,-384 # 800074a8 <etext+0x4a8>
    80003630:	a18fd0ef          	jal	80000848 <panic>

0000000080003634 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003634:	1141                	addi	sp,sp,-16
    80003636:	e406                	sd	ra,8(sp)
    80003638:	e022                	sd	s0,0(sp)
    8000363a:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    8000363c:	411c                	lw	a5,0(a0)
    8000363e:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80003640:	415c                	lw	a5,4(a0)
    80003642:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80003644:	04451783          	lh	a5,68(a0)
    80003648:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    8000364c:	04a51783          	lh	a5,74(a0)
    80003650:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003654:	04c56783          	lwu	a5,76(a0)
    80003658:	e99c                	sd	a5,16(a1)
}
    8000365a:	60a2                	ld	ra,8(sp)
    8000365c:	6402                	ld	s0,0(sp)
    8000365e:	0141                	addi	sp,sp,16
    80003660:	8082                	ret

0000000080003662 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    80003662:	457c                	lw	a5,76(a0)
    80003664:	0ed7e663          	bltu	a5,a3,80003750 <readi+0xee>
{
    80003668:	7159                	addi	sp,sp,-112
    8000366a:	f486                	sd	ra,104(sp)
    8000366c:	f0a2                	sd	s0,96(sp)
    8000366e:	eca6                	sd	s1,88(sp)
    80003670:	e0d2                	sd	s4,64(sp)
    80003672:	fc56                	sd	s5,56(sp)
    80003674:	f85a                	sd	s6,48(sp)
    80003676:	f45e                	sd	s7,40(sp)
    80003678:	1880                	addi	s0,sp,112
    8000367a:	8b2a                	mv	s6,a0
    8000367c:	8bae                	mv	s7,a1
    8000367e:	8a32                	mv	s4,a2
    80003680:	84b6                	mv	s1,a3
    80003682:	8aba                	mv	s5,a4
  if (off > ip->size || off + n < off)
    80003684:	9f35                	addw	a4,a4,a3
    return 0;
    80003686:	4501                	li	a0,0
  if (off > ip->size || off + n < off)
    80003688:	0ad76b63          	bltu	a4,a3,8000373e <readi+0xdc>
    8000368c:	e4ce                	sd	s3,72(sp)
  if (off + n > ip->size)
    8000368e:	00e7f463          	bgeu	a5,a4,80003696 <readi+0x34>
    n = ip->size - off;
    80003692:	40d78abb          	subw	s5,a5,a3

  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003696:	080a8b63          	beqz	s5,8000372c <readi+0xca>
    8000369a:	e8ca                	sd	s2,80(sp)
    8000369c:	f062                	sd	s8,32(sp)
    8000369e:	ec66                	sd	s9,24(sp)
    800036a0:	e86a                	sd	s10,16(sp)
    800036a2:	e46e                	sd	s11,8(sp)
    800036a4:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    800036a6:	40000c93          	li	s9,1024
    if (either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    800036aa:	5c7d                	li	s8,-1
    800036ac:	a80d                	j	800036de <readi+0x7c>
    800036ae:	020d1d93          	slli	s11,s10,0x20
    800036b2:	020ddd93          	srli	s11,s11,0x20
    800036b6:	05890613          	addi	a2,s2,88
    800036ba:	86ee                	mv	a3,s11
    800036bc:	963e                	add	a2,a2,a5
    800036be:	85d2                	mv	a1,s4
    800036c0:	855e                	mv	a0,s7
    800036c2:	c21fe0ef          	jal	800022e2 <either_copyout>
    800036c6:	05850363          	beq	a0,s8,8000370c <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    800036ca:	854a                	mv	a0,s2
    800036cc:	e24ff0ef          	jal	80002cf0 <brelse>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    800036d0:	013d09bb          	addw	s3,s10,s3
    800036d4:	009d04bb          	addw	s1,s10,s1
    800036d8:	9a6e                	add	s4,s4,s11
    800036da:	0559f363          	bgeu	s3,s5,80003720 <readi+0xbe>
    uint addr = bmap(ip, off / BSIZE);
    800036de:	00a4d59b          	srliw	a1,s1,0xa
    800036e2:	855a                	mv	a0,s6
    800036e4:	86bff0ef          	jal	80002f4e <bmap>
    800036e8:	85aa                	mv	a1,a0
    if (addr == 0)
    800036ea:	c139                	beqz	a0,80003730 <readi+0xce>
    bp = bread(ip->dev, addr);
    800036ec:	000b2503          	lw	a0,0(s6)
    800036f0:	cf8ff0ef          	jal	80002be8 <bread>
    800036f4:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    800036f6:	3ff4f793          	andi	a5,s1,1023
    800036fa:	40fc873b          	subw	a4,s9,a5
    800036fe:	413a86bb          	subw	a3,s5,s3
    80003702:	8d3a                	mv	s10,a4
    80003704:	fae6f5e3          	bgeu	a3,a4,800036ae <readi+0x4c>
    80003708:	8d36                	mv	s10,a3
    8000370a:	b755                	j	800036ae <readi+0x4c>
      brelse(bp);
    8000370c:	854a                	mv	a0,s2
    8000370e:	de2ff0ef          	jal	80002cf0 <brelse>
      tot = -1;
    80003712:	59fd                	li	s3,-1
      break;
    80003714:	6946                	ld	s2,80(sp)
    80003716:	7c02                	ld	s8,32(sp)
    80003718:	6ce2                	ld	s9,24(sp)
    8000371a:	6d42                	ld	s10,16(sp)
    8000371c:	6da2                	ld	s11,8(sp)
    8000371e:	a831                	j	8000373a <readi+0xd8>
    80003720:	6946                	ld	s2,80(sp)
    80003722:	7c02                	ld	s8,32(sp)
    80003724:	6ce2                	ld	s9,24(sp)
    80003726:	6d42                	ld	s10,16(sp)
    80003728:	6da2                	ld	s11,8(sp)
    8000372a:	a801                	j	8000373a <readi+0xd8>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    8000372c:	89d6                	mv	s3,s5
    8000372e:	a031                	j	8000373a <readi+0xd8>
    80003730:	6946                	ld	s2,80(sp)
    80003732:	7c02                	ld	s8,32(sp)
    80003734:	6ce2                	ld	s9,24(sp)
    80003736:	6d42                	ld	s10,16(sp)
    80003738:	6da2                	ld	s11,8(sp)
  }
  return tot;
    8000373a:	854e                	mv	a0,s3
    8000373c:	69a6                	ld	s3,72(sp)
}
    8000373e:	70a6                	ld	ra,104(sp)
    80003740:	7406                	ld	s0,96(sp)
    80003742:	64e6                	ld	s1,88(sp)
    80003744:	6a06                	ld	s4,64(sp)
    80003746:	7ae2                	ld	s5,56(sp)
    80003748:	7b42                	ld	s6,48(sp)
    8000374a:	7ba2                	ld	s7,40(sp)
    8000374c:	6165                	addi	sp,sp,112
    8000374e:	8082                	ret
    return 0;
    80003750:	4501                	li	a0,0
}
    80003752:	8082                	ret

0000000080003754 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    80003754:	457c                	lw	a5,76(a0)
    80003756:	10d7e163          	bltu	a5,a3,80003858 <writei+0x104>
{
    8000375a:	7159                	addi	sp,sp,-112
    8000375c:	f486                	sd	ra,104(sp)
    8000375e:	f0a2                	sd	s0,96(sp)
    80003760:	e8ca                	sd	s2,80(sp)
    80003762:	e0d2                	sd	s4,64(sp)
    80003764:	fc56                	sd	s5,56(sp)
    80003766:	f85a                	sd	s6,48(sp)
    80003768:	f45e                	sd	s7,40(sp)
    8000376a:	1880                	addi	s0,sp,112
    8000376c:	8aaa                	mv	s5,a0
    8000376e:	8bae                	mv	s7,a1
    80003770:	8a32                	mv	s4,a2
    80003772:	8936                	mv	s2,a3
    80003774:	8b3a                	mv	s6,a4
  if (off > ip->size || off + n < off)
    80003776:	9f35                	addw	a4,a4,a3
    return -1;
  if (off + n > MAXFILE * BSIZE)
    80003778:	000437b7          	lui	a5,0x43
    8000377c:	00e7b7b3          	sltu	a5,a5,a4
  if (off > ip->size || off + n < off)
    80003780:	00d73733          	sltu	a4,a4,a3
  if (off + n > MAXFILE * BSIZE)
    80003784:	8fd9                	or	a5,a5,a4
    80003786:	ef91                	bnez	a5,800037a2 <writei+0x4e>
    80003788:	e4ce                	sd	s3,72(sp)
    return -1;

  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    8000378a:	0a0b0f63          	beqz	s6,80003848 <writei+0xf4>
    8000378e:	eca6                	sd	s1,88(sp)
    80003790:	f062                	sd	s8,32(sp)
    80003792:	ec66                	sd	s9,24(sp)
    80003794:	e86a                	sd	s10,16(sp)
    80003796:	e46e                	sd	s11,8(sp)
    80003798:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    8000379a:	40000c93          	li	s9,1024
    if (either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    8000379e:	5c7d                	li	s8,-1
    800037a0:	a835                	j	800037dc <writei+0x88>
    return -1;
    800037a2:	557d                	li	a0,-1
    800037a4:	a849                	j	80003836 <writei+0xe2>
    if (either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    800037a6:	020d1d93          	slli	s11,s10,0x20
    800037aa:	020ddd93          	srli	s11,s11,0x20
    800037ae:	05848513          	addi	a0,s1,88
    800037b2:	86ee                	mv	a3,s11
    800037b4:	8652                	mv	a2,s4
    800037b6:	85de                	mv	a1,s7
    800037b8:	953e                	add	a0,a0,a5
    800037ba:	b75fe0ef          	jal	8000232e <either_copyin>
    800037be:	05850663          	beq	a0,s8,8000380a <writei+0xb6>
      // Might have partially updated the block, so we need to log it.
      log_write(bp);
      brelse(bp);
      break;
    }
    log_write(bp);
    800037c2:	8526                	mv	a0,s1
    800037c4:	6e4000ef          	jal	80003ea8 <log_write>
    brelse(bp);
    800037c8:	8526                	mv	a0,s1
    800037ca:	d26ff0ef          	jal	80002cf0 <brelse>
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    800037ce:	013d09bb          	addw	s3,s10,s3
    800037d2:	012d093b          	addw	s2,s10,s2
    800037d6:	9a6e                	add	s4,s4,s11
    800037d8:	0369ff63          	bgeu	s3,s6,80003816 <writei+0xc2>
    uint addr = bmap(ip, off / BSIZE);
    800037dc:	00a9559b          	srliw	a1,s2,0xa
    800037e0:	8556                	mv	a0,s5
    800037e2:	f6cff0ef          	jal	80002f4e <bmap>
    800037e6:	85aa                	mv	a1,a0
    if (addr == 0)
    800037e8:	c51d                	beqz	a0,80003816 <writei+0xc2>
    bp = bread(ip->dev, addr);
    800037ea:	000aa503          	lw	a0,0(s5)
    800037ee:	bfaff0ef          	jal	80002be8 <bread>
    800037f2:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    800037f4:	3ff97793          	andi	a5,s2,1023
    800037f8:	40fc873b          	subw	a4,s9,a5
    800037fc:	413b06bb          	subw	a3,s6,s3
    80003800:	8d3a                	mv	s10,a4
    80003802:	fae6f2e3          	bgeu	a3,a4,800037a6 <writei+0x52>
    80003806:	8d36                	mv	s10,a3
    80003808:	bf79                	j	800037a6 <writei+0x52>
      log_write(bp);
    8000380a:	8526                	mv	a0,s1
    8000380c:	69c000ef          	jal	80003ea8 <log_write>
      brelse(bp);
    80003810:	8526                	mv	a0,s1
    80003812:	cdeff0ef          	jal	80002cf0 <brelse>
  }

  if (off > ip->size)
    80003816:	04caa783          	lw	a5,76(s5)
    8000381a:	0327f963          	bgeu	a5,s2,8000384c <writei+0xf8>
    ip->size = off;
    8000381e:	052aa623          	sw	s2,76(s5)
    80003822:	64e6                	ld	s1,88(sp)
    80003824:	7c02                	ld	s8,32(sp)
    80003826:	6ce2                	ld	s9,24(sp)
    80003828:	6d42                	ld	s10,16(sp)
    8000382a:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    8000382c:	8556                	mv	a0,s5
    8000382e:	9a7ff0ef          	jal	800031d4 <iupdate>

  return tot;
    80003832:	854e                	mv	a0,s3
    80003834:	69a6                	ld	s3,72(sp)
}
    80003836:	70a6                	ld	ra,104(sp)
    80003838:	7406                	ld	s0,96(sp)
    8000383a:	6946                	ld	s2,80(sp)
    8000383c:	6a06                	ld	s4,64(sp)
    8000383e:	7ae2                	ld	s5,56(sp)
    80003840:	7b42                	ld	s6,48(sp)
    80003842:	7ba2                	ld	s7,40(sp)
    80003844:	6165                	addi	sp,sp,112
    80003846:	8082                	ret
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003848:	89da                	mv	s3,s6
    8000384a:	b7cd                	j	8000382c <writei+0xd8>
    8000384c:	64e6                	ld	s1,88(sp)
    8000384e:	7c02                	ld	s8,32(sp)
    80003850:	6ce2                	ld	s9,24(sp)
    80003852:	6d42                	ld	s10,16(sp)
    80003854:	6da2                	ld	s11,8(sp)
    80003856:	bfd9                	j	8000382c <writei+0xd8>
    return -1;
    80003858:	557d                	li	a0,-1
}
    8000385a:	8082                	ret

000000008000385c <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    8000385c:	1141                	addi	sp,sp,-16
    8000385e:	e406                	sd	ra,8(sp)
    80003860:	e022                	sd	s0,0(sp)
    80003862:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003864:	4639                	li	a2,14
    80003866:	d1efd0ef          	jal	80000d84 <strncmp>
}
    8000386a:	60a2                	ld	ra,8(sp)
    8000386c:	6402                	ld	s0,0(sp)
    8000386e:	0141                	addi	sp,sp,16
    80003870:	8082                	ret

0000000080003872 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode *
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003872:	711d                	addi	sp,sp,-96
    80003874:	ec86                	sd	ra,88(sp)
    80003876:	e8a2                	sd	s0,80(sp)
    80003878:	e4a6                	sd	s1,72(sp)
    8000387a:	e0ca                	sd	s2,64(sp)
    8000387c:	fc4e                	sd	s3,56(sp)
    8000387e:	f852                	sd	s4,48(sp)
    80003880:	f456                	sd	s5,40(sp)
    80003882:	f05a                	sd	s6,32(sp)
    80003884:	ec5e                	sd	s7,24(sp)
    80003886:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if (dp->type != T_DIR)
    80003888:	04451703          	lh	a4,68(a0)
    8000388c:	4785                	li	a5,1
    8000388e:	02f71963          	bne	a4,a5,800038c0 <dirlookup+0x4e>
    80003892:	892a                	mv	s2,a0
    80003894:	8aae                	mv	s5,a1
    80003896:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003898:	457c                	lw	a5,76(a0)
    8000389a:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000389c:	fa040a13          	addi	s4,s0,-96
    800038a0:	49c1                	li	s3,16
      panic("dirlookup read");
    if (de.inum == 0)
      continue;
    if (namecmp(name, de.name) == 0) {
    800038a2:	fa240b13          	addi	s6,s0,-94
  for (off = 0; off < dp->size; off += sizeof(de)) {
    800038a6:	ef95                	bnez	a5,800038e2 <dirlookup+0x70>
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    800038a8:	4501                	li	a0,0
}
    800038aa:	60e6                	ld	ra,88(sp)
    800038ac:	6446                	ld	s0,80(sp)
    800038ae:	64a6                	ld	s1,72(sp)
    800038b0:	6906                	ld	s2,64(sp)
    800038b2:	79e2                	ld	s3,56(sp)
    800038b4:	7a42                	ld	s4,48(sp)
    800038b6:	7aa2                	ld	s5,40(sp)
    800038b8:	7b02                	ld	s6,32(sp)
    800038ba:	6be2                	ld	s7,24(sp)
    800038bc:	6125                	addi	sp,sp,96
    800038be:	8082                	ret
    panic("dirlookup not DIR");
    800038c0:	00004517          	auipc	a0,0x4
    800038c4:	c0050513          	addi	a0,a0,-1024 # 800074c0 <etext+0x4c0>
    800038c8:	f81fc0ef          	jal	80000848 <panic>
      panic("dirlookup read");
    800038cc:	00004517          	auipc	a0,0x4
    800038d0:	c0c50513          	addi	a0,a0,-1012 # 800074d8 <etext+0x4d8>
    800038d4:	f75fc0ef          	jal	80000848 <panic>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    800038d8:	24c1                	addiw	s1,s1,16
    800038da:	04c92783          	lw	a5,76(s2)
    800038de:	fcf4f5e3          	bgeu	s1,a5,800038a8 <dirlookup+0x36>
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800038e2:	874e                	mv	a4,s3
    800038e4:	86a6                	mv	a3,s1
    800038e6:	8652                	mv	a2,s4
    800038e8:	4581                	li	a1,0
    800038ea:	854a                	mv	a0,s2
    800038ec:	d77ff0ef          	jal	80003662 <readi>
    800038f0:	fd351ee3          	bne	a0,s3,800038cc <dirlookup+0x5a>
    if (de.inum == 0)
    800038f4:	fa045783          	lhu	a5,-96(s0)
    800038f8:	d3e5                	beqz	a5,800038d8 <dirlookup+0x66>
    if (namecmp(name, de.name) == 0) {
    800038fa:	85da                	mv	a1,s6
    800038fc:	8556                	mv	a0,s5
    800038fe:	f5fff0ef          	jal	8000385c <namecmp>
    80003902:	f979                	bnez	a0,800038d8 <dirlookup+0x66>
      if (poff)
    80003904:	000b8463          	beqz	s7,8000390c <dirlookup+0x9a>
        *poff = off;
    80003908:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    8000390c:	fa045583          	lhu	a1,-96(s0)
    80003910:	00092503          	lw	a0,0(s2)
    80003914:	efaff0ef          	jal	8000300e <iget>
    80003918:	bf49                	j	800038aa <dirlookup+0x38>

000000008000391a <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode *
namex(char *path, int nameiparent, char *name)
{
    8000391a:	711d                	addi	sp,sp,-96
    8000391c:	ec86                	sd	ra,88(sp)
    8000391e:	e8a2                	sd	s0,80(sp)
    80003920:	e4a6                	sd	s1,72(sp)
    80003922:	e0ca                	sd	s2,64(sp)
    80003924:	fc4e                	sd	s3,56(sp)
    80003926:	f852                	sd	s4,48(sp)
    80003928:	f456                	sd	s5,40(sp)
    8000392a:	f05a                	sd	s6,32(sp)
    8000392c:	ec5e                	sd	s7,24(sp)
    8000392e:	e862                	sd	s8,16(sp)
    80003930:	e466                	sd	s9,8(sp)
    80003932:	e06a                	sd	s10,0(sp)
    80003934:	1080                	addi	s0,sp,96
    80003936:	84aa                	mv	s1,a0
    80003938:	8b2e                	mv	s6,a1
    8000393a:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if (*path == '/')
    8000393c:	00054703          	lbu	a4,0(a0)
    80003940:	02f00793          	li	a5,47
    80003944:	00f70f63          	beq	a4,a5,80003962 <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003948:	f9bfd0ef          	jal	800018e2 <myproc>
    8000394c:	15053503          	ld	a0,336(a0)
    80003950:	903ff0ef          	jal	80003252 <idup>
    80003954:	8a2a                	mv	s4,a0
  while (*path == '/')
    80003956:	02f00993          	li	s3,47
  if (len >= DIRSIZ)
    8000395a:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    8000395c:	4cb9                	li	s9,14

  while ((path = skipelem(path, name)) != 0) {
    ilock(ip);
    if (ip->type != T_DIR) {
    8000395e:	4b85                	li	s7,1
    80003960:	a075                	j	80003a0c <namex+0xf2>
    ip = iget(ROOTDEV, ROOTINO);
    80003962:	4585                	li	a1,1
    80003964:	852e                	mv	a0,a1
    80003966:	ea8ff0ef          	jal	8000300e <iget>
    8000396a:	8a2a                	mv	s4,a0
    8000396c:	b7ed                	j	80003956 <namex+0x3c>
      iunlockput(ip);
    8000396e:	8552                	mv	a0,s4
    80003970:	b6dff0ef          	jal	800034dc <iunlockput>
      return 0;
    80003974:	4a01                	li	s4,0
  if (nameiparent) {
    iput(ip);
    return 0;
  }
  return ip;
}
    80003976:	8552                	mv	a0,s4
    80003978:	60e6                	ld	ra,88(sp)
    8000397a:	6446                	ld	s0,80(sp)
    8000397c:	64a6                	ld	s1,72(sp)
    8000397e:	6906                	ld	s2,64(sp)
    80003980:	79e2                	ld	s3,56(sp)
    80003982:	7a42                	ld	s4,48(sp)
    80003984:	7aa2                	ld	s5,40(sp)
    80003986:	7b02                	ld	s6,32(sp)
    80003988:	6be2                	ld	s7,24(sp)
    8000398a:	6c42                	ld	s8,16(sp)
    8000398c:	6ca2                	ld	s9,8(sp)
    8000398e:	6d02                	ld	s10,0(sp)
    80003990:	6125                	addi	sp,sp,96
    80003992:	8082                	ret
      iunlockput(ip);
    80003994:	8552                	mv	a0,s4
    80003996:	b47ff0ef          	jal	800034dc <iunlockput>
      return 0;
    8000399a:	bfe9                	j	80003974 <namex+0x5a>
      iunlock(ip);
    8000399c:	8552                	mv	a0,s4
    8000399e:	999ff0ef          	jal	80003336 <iunlock>
      return ip;
    800039a2:	bfd1                	j	80003976 <namex+0x5c>
      iunlockput(ip);
    800039a4:	8552                	mv	a0,s4
    800039a6:	b37ff0ef          	jal	800034dc <iunlockput>
      return 0;
    800039aa:	8a4a                	mv	s4,s2
    800039ac:	b7e9                	j	80003976 <namex+0x5c>
  while (*path != '/' && *path != 0)
    800039ae:	8926                	mv	s2,s1
  len = path - s;
    800039b0:	4d01                	li	s10,0
    800039b2:	4601                	li	a2,0
    memmove(name, s, len);
    800039b4:	2601                	sext.w	a2,a2
    800039b6:	85a6                	mv	a1,s1
    800039b8:	8556                	mv	a0,s5
    800039ba:	b56fd0ef          	jal	80000d10 <memmove>
    name[len] = 0;
    800039be:	9d56                	add	s10,s10,s5
    800039c0:	000d0023          	sb	zero,0(s10) # fffffffffffff000 <end+0xffffffff7ffdb9d0>
    800039c4:	84ca                	mv	s1,s2
  while (*path == '/')
    800039c6:	0004c783          	lbu	a5,0(s1)
    800039ca:	01379763          	bne	a5,s3,800039d8 <namex+0xbe>
    path++;
    800039ce:	0485                	addi	s1,s1,1
  while (*path == '/')
    800039d0:	0004c783          	lbu	a5,0(s1)
    800039d4:	ff378de3          	beq	a5,s3,800039ce <namex+0xb4>
    ilock(ip);
    800039d8:	8552                	mv	a0,s4
    800039da:	8afff0ef          	jal	80003288 <ilock>
    if (ip->type != T_DIR) {
    800039de:	044a1783          	lh	a5,68(s4)
    800039e2:	f97796e3          	bne	a5,s7,8000396e <namex+0x54>
    if (ip->nlink == 0) {
    800039e6:	04aa1783          	lh	a5,74(s4)
    800039ea:	d7cd                	beqz	a5,80003994 <namex+0x7a>
    if (nameiparent && *path == '\0') {
    800039ec:	000b0563          	beqz	s6,800039f6 <namex+0xdc>
    800039f0:	0004c783          	lbu	a5,0(s1)
    800039f4:	d7c5                	beqz	a5,8000399c <namex+0x82>
    if ((next = dirlookup(ip, name, 0)) == 0) {
    800039f6:	4601                	li	a2,0
    800039f8:	85d6                	mv	a1,s5
    800039fa:	8552                	mv	a0,s4
    800039fc:	e77ff0ef          	jal	80003872 <dirlookup>
    80003a00:	892a                	mv	s2,a0
    80003a02:	d14d                	beqz	a0,800039a4 <namex+0x8a>
    iunlockput(ip);
    80003a04:	8552                	mv	a0,s4
    80003a06:	ad7ff0ef          	jal	800034dc <iunlockput>
    ip = next;
    80003a0a:	8a4a                	mv	s4,s2
  while (*path == '/')
    80003a0c:	0004c783          	lbu	a5,0(s1)
    80003a10:	01379763          	bne	a5,s3,80003a1e <namex+0x104>
    path++;
    80003a14:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003a16:	0004c783          	lbu	a5,0(s1)
    80003a1a:	ff378de3          	beq	a5,s3,80003a14 <namex+0xfa>
  if (*path == 0)
    80003a1e:	c7a1                	beqz	a5,80003a66 <namex+0x14c>
  while (*path != '/' && *path != 0)
    80003a20:	0004c703          	lbu	a4,0(s1)
    80003a24:	fd170793          	addi	a5,a4,-47
    80003a28:	00f037b3          	snez	a5,a5
    80003a2c:	00e03733          	snez	a4,a4
    80003a30:	8ff9                	and	a5,a5,a4
    80003a32:	dfb5                	beqz	a5,800039ae <namex+0x94>
    80003a34:	8926                	mv	s2,s1
    path++;
    80003a36:	0905                	addi	s2,s2,1
  while (*path != '/' && *path != 0)
    80003a38:	00094703          	lbu	a4,0(s2)
    80003a3c:	fd170793          	addi	a5,a4,-47
    80003a40:	00f037b3          	snez	a5,a5
    80003a44:	00e03733          	snez	a4,a4
    80003a48:	8ff9                	and	a5,a5,a4
    80003a4a:	f7f5                	bnez	a5,80003a36 <namex+0x11c>
  len = path - s;
    80003a4c:	40990633          	sub	a2,s2,s1
    80003a50:	00060d1b          	sext.w	s10,a2
  if (len >= DIRSIZ)
    80003a54:	f7ac50e3          	bge	s8,s10,800039b4 <namex+0x9a>
    memmove(name, s, DIRSIZ);
    80003a58:	8666                	mv	a2,s9
    80003a5a:	85a6                	mv	a1,s1
    80003a5c:	8556                	mv	a0,s5
    80003a5e:	ab2fd0ef          	jal	80000d10 <memmove>
    80003a62:	84ca                	mv	s1,s2
    80003a64:	b78d                	j	800039c6 <namex+0xac>
  if (nameiparent) {
    80003a66:	f00b08e3          	beqz	s6,80003976 <namex+0x5c>
    iput(ip);
    80003a6a:	8552                	mv	a0,s4
    80003a6c:	99fff0ef          	jal	8000340a <iput>
    return 0;
    80003a70:	b711                	j	80003974 <namex+0x5a>

0000000080003a72 <dirlink>:
{
    80003a72:	715d                	addi	sp,sp,-80
    80003a74:	e486                	sd	ra,72(sp)
    80003a76:	e0a2                	sd	s0,64(sp)
    80003a78:	f84a                	sd	s2,48(sp)
    80003a7a:	ec56                	sd	s5,24(sp)
    80003a7c:	e85a                	sd	s6,16(sp)
    80003a7e:	0880                	addi	s0,sp,80
    80003a80:	892a                	mv	s2,a0
    80003a82:	8aae                	mv	s5,a1
    80003a84:	8b32                	mv	s6,a2
  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80003a86:	4601                	li	a2,0
    80003a88:	debff0ef          	jal	80003872 <dirlookup>
    80003a8c:	ed1d                	bnez	a0,80003aca <dirlink+0x58>
    80003a8e:	fc26                	sd	s1,56(sp)
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003a90:	04c92483          	lw	s1,76(s2)
    80003a94:	c4b9                	beqz	s1,80003ae2 <dirlink+0x70>
    80003a96:	f44e                	sd	s3,40(sp)
    80003a98:	f052                	sd	s4,32(sp)
    80003a9a:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003a9c:	fb040a13          	addi	s4,s0,-80
    80003aa0:	49c1                	li	s3,16
    80003aa2:	874e                	mv	a4,s3
    80003aa4:	86a6                	mv	a3,s1
    80003aa6:	8652                	mv	a2,s4
    80003aa8:	4581                	li	a1,0
    80003aaa:	854a                	mv	a0,s2
    80003aac:	bb7ff0ef          	jal	80003662 <readi>
    80003ab0:	03351163          	bne	a0,s3,80003ad2 <dirlink+0x60>
    if (de.inum == 0)
    80003ab4:	fb045783          	lhu	a5,-80(s0)
    80003ab8:	c39d                	beqz	a5,80003ade <dirlink+0x6c>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003aba:	24c1                	addiw	s1,s1,16
    80003abc:	04c92783          	lw	a5,76(s2)
    80003ac0:	fef4e1e3          	bltu	s1,a5,80003aa2 <dirlink+0x30>
    80003ac4:	79a2                	ld	s3,40(sp)
    80003ac6:	7a02                	ld	s4,32(sp)
    80003ac8:	a829                	j	80003ae2 <dirlink+0x70>
    iput(ip);
    80003aca:	941ff0ef          	jal	8000340a <iput>
    return -1;
    80003ace:	557d                	li	a0,-1
    80003ad0:	a83d                	j	80003b0e <dirlink+0x9c>
      panic("dirlink read");
    80003ad2:	00004517          	auipc	a0,0x4
    80003ad6:	a1650513          	addi	a0,a0,-1514 # 800074e8 <etext+0x4e8>
    80003ada:	d6ffc0ef          	jal	80000848 <panic>
    80003ade:	79a2                	ld	s3,40(sp)
    80003ae0:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80003ae2:	4639                	li	a2,14
    80003ae4:	85d6                	mv	a1,s5
    80003ae6:	fb240513          	addi	a0,s0,-78
    80003aea:	ad0fd0ef          	jal	80000dba <strncpy>
  de.inum = inum;
    80003aee:	fb641823          	sh	s6,-80(s0)
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003af2:	4741                	li	a4,16
    80003af4:	86a6                	mv	a3,s1
    80003af6:	fb040613          	addi	a2,s0,-80
    80003afa:	4581                	li	a1,0
    80003afc:	854a                	mv	a0,s2
    80003afe:	c57ff0ef          	jal	80003754 <writei>
    80003b02:	1541                	addi	a0,a0,-16
    80003b04:	00a03533          	snez	a0,a0
    80003b08:	40a0053b          	negw	a0,a0
    80003b0c:	74e2                	ld	s1,56(sp)
}
    80003b0e:	60a6                	ld	ra,72(sp)
    80003b10:	6406                	ld	s0,64(sp)
    80003b12:	7942                	ld	s2,48(sp)
    80003b14:	6ae2                	ld	s5,24(sp)
    80003b16:	6b42                	ld	s6,16(sp)
    80003b18:	6161                	addi	sp,sp,80
    80003b1a:	8082                	ret

0000000080003b1c <namei>:

struct inode *
namei(char *path)
{
    80003b1c:	1101                	addi	sp,sp,-32
    80003b1e:	ec06                	sd	ra,24(sp)
    80003b20:	e822                	sd	s0,16(sp)
    80003b22:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003b24:	fe040613          	addi	a2,s0,-32
    80003b28:	4581                	li	a1,0
    80003b2a:	df1ff0ef          	jal	8000391a <namex>
}
    80003b2e:	60e2                	ld	ra,24(sp)
    80003b30:	6442                	ld	s0,16(sp)
    80003b32:	6105                	addi	sp,sp,32
    80003b34:	8082                	ret

0000000080003b36 <nameiparent>:

struct inode *
nameiparent(char *path, char *name)
{
    80003b36:	1141                	addi	sp,sp,-16
    80003b38:	e406                	sd	ra,8(sp)
    80003b3a:	e022                	sd	s0,0(sp)
    80003b3c:	0800                	addi	s0,sp,16
    80003b3e:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003b40:	4585                	li	a1,1
    80003b42:	dd9ff0ef          	jal	8000391a <namex>
}
    80003b46:	60a2                	ld	ra,8(sp)
    80003b48:	6402                	ld	s0,0(sp)
    80003b4a:	0141                	addi	sp,sp,16
    80003b4c:	8082                	ret

0000000080003b4e <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003b4e:	1101                	addi	sp,sp,-32
    80003b50:	ec06                	sd	ra,24(sp)
    80003b52:	e822                	sd	s0,16(sp)
    80003b54:	e426                	sd	s1,8(sp)
    80003b56:	e04a                	sd	s2,0(sp)
    80003b58:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003b5a:	0001f917          	auipc	s2,0x1f
    80003b5e:	89690913          	addi	s2,s2,-1898 # 800223f0 <log>
    80003b62:	01892583          	lw	a1,24(s2)
    80003b66:	02492503          	lw	a0,36(s2)
    80003b6a:	87eff0ef          	jal	80002be8 <bread>
    80003b6e:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *)(buf->data);
  int i;
  hb->n = log.lh.n;
    80003b70:	02c92603          	lw	a2,44(s2)
    80003b74:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003b76:	00c05f63          	blez	a2,80003b94 <write_head+0x46>
    80003b7a:	0001f717          	auipc	a4,0x1f
    80003b7e:	8a670713          	addi	a4,a4,-1882 # 80022420 <log+0x30>
    80003b82:	87aa                	mv	a5,a0
    80003b84:	060a                	slli	a2,a2,0x2
    80003b86:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003b88:	4314                	lw	a3,0(a4)
    80003b8a:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003b8c:	0711                	addi	a4,a4,4
    80003b8e:	0791                	addi	a5,a5,4 # 43004 <_entry-0x7ffbcffc>
    80003b90:	fec79ce3          	bne	a5,a2,80003b88 <write_head+0x3a>
  }
  bwrite(buf);
    80003b94:	8526                	mv	a0,s1
    80003b96:	928ff0ef          	jal	80002cbe <bwrite>
  brelse(buf);
    80003b9a:	8526                	mv	a0,s1
    80003b9c:	954ff0ef          	jal	80002cf0 <brelse>
}
    80003ba0:	60e2                	ld	ra,24(sp)
    80003ba2:	6442                	ld	s0,16(sp)
    80003ba4:	64a2                	ld	s1,8(sp)
    80003ba6:	6902                	ld	s2,0(sp)
    80003ba8:	6105                	addi	sp,sp,32
    80003baa:	8082                	ret

0000000080003bac <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003bac:	0001f797          	auipc	a5,0x1f
    80003bb0:	8707a783          	lw	a5,-1936(a5) # 8002241c <log+0x2c>
    80003bb4:	0cf05163          	blez	a5,80003c76 <install_trans+0xca>
{
    80003bb8:	715d                	addi	sp,sp,-80
    80003bba:	e486                	sd	ra,72(sp)
    80003bbc:	e0a2                	sd	s0,64(sp)
    80003bbe:	fc26                	sd	s1,56(sp)
    80003bc0:	f84a                	sd	s2,48(sp)
    80003bc2:	f44e                	sd	s3,40(sp)
    80003bc4:	f052                	sd	s4,32(sp)
    80003bc6:	ec56                	sd	s5,24(sp)
    80003bc8:	e85a                	sd	s6,16(sp)
    80003bca:	e45e                	sd	s7,8(sp)
    80003bcc:	e062                	sd	s8,0(sp)
    80003bce:	0880                	addi	s0,sp,80
    80003bd0:	8b2a                	mv	s6,a0
    80003bd2:	0001fa97          	auipc	s5,0x1f
    80003bd6:	84ea8a93          	addi	s5,s5,-1970 # 80022420 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003bda:	4981                	li	s3,0
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003bdc:	00004c17          	auipc	s8,0x4
    80003be0:	91cc0c13          	addi	s8,s8,-1764 # 800074f8 <etext+0x4f8>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003be4:	0001fa17          	auipc	s4,0x1f
    80003be8:	80ca0a13          	addi	s4,s4,-2036 # 800223f0 <log>
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80003bec:	40000b93          	li	s7,1024
    80003bf0:	a025                	j	80003c18 <install_trans+0x6c>
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003bf2:	000aa603          	lw	a2,0(s5)
    80003bf6:	85ce                	mv	a1,s3
    80003bf8:	8562                	mv	a0,s8
    80003bfa:	917fc0ef          	jal	80000510 <printk>
    80003bfe:	a839                	j	80003c1c <install_trans+0x70>
    brelse(lbuf);
    80003c00:	854a                	mv	a0,s2
    80003c02:	8eeff0ef          	jal	80002cf0 <brelse>
    brelse(dbuf);
    80003c06:	8526                	mv	a0,s1
    80003c08:	8e8ff0ef          	jal	80002cf0 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003c0c:	2985                	addiw	s3,s3,1
    80003c0e:	0a91                	addi	s5,s5,4
    80003c10:	02ca2783          	lw	a5,44(s4)
    80003c14:	04f9d563          	bge	s3,a5,80003c5e <install_trans+0xb2>
    if (recovering) {
    80003c18:	fc0b1de3          	bnez	s6,80003bf2 <install_trans+0x46>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003c1c:	018a2583          	lw	a1,24(s4)
    80003c20:	013585bb          	addw	a1,a1,s3
    80003c24:	2585                	addiw	a1,a1,1
    80003c26:	024a2503          	lw	a0,36(s4)
    80003c2a:	fbffe0ef          	jal	80002be8 <bread>
    80003c2e:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]);   // read dst
    80003c30:	000aa583          	lw	a1,0(s5)
    80003c34:	024a2503          	lw	a0,36(s4)
    80003c38:	fb1fe0ef          	jal	80002be8 <bread>
    80003c3c:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80003c3e:	865e                	mv	a2,s7
    80003c40:	05890593          	addi	a1,s2,88
    80003c44:	05850513          	addi	a0,a0,88
    80003c48:	8c8fd0ef          	jal	80000d10 <memmove>
    bwrite(dbuf);                           // write dst to disk
    80003c4c:	8526                	mv	a0,s1
    80003c4e:	870ff0ef          	jal	80002cbe <bwrite>
    if (recovering == 0)
    80003c52:	fa0b17e3          	bnez	s6,80003c00 <install_trans+0x54>
      bunpin(dbuf);
    80003c56:	8526                	mv	a0,s1
    80003c58:	950ff0ef          	jal	80002da8 <bunpin>
    80003c5c:	b755                	j	80003c00 <install_trans+0x54>
}
    80003c5e:	60a6                	ld	ra,72(sp)
    80003c60:	6406                	ld	s0,64(sp)
    80003c62:	74e2                	ld	s1,56(sp)
    80003c64:	7942                	ld	s2,48(sp)
    80003c66:	79a2                	ld	s3,40(sp)
    80003c68:	7a02                	ld	s4,32(sp)
    80003c6a:	6ae2                	ld	s5,24(sp)
    80003c6c:	6b42                	ld	s6,16(sp)
    80003c6e:	6ba2                	ld	s7,8(sp)
    80003c70:	6c02                	ld	s8,0(sp)
    80003c72:	6161                	addi	sp,sp,80
    80003c74:	8082                	ret
    80003c76:	8082                	ret

0000000080003c78 <initlog>:
{
    80003c78:	7179                	addi	sp,sp,-48
    80003c7a:	f406                	sd	ra,40(sp)
    80003c7c:	f022                	sd	s0,32(sp)
    80003c7e:	ec26                	sd	s1,24(sp)
    80003c80:	e84a                	sd	s2,16(sp)
    80003c82:	e44e                	sd	s3,8(sp)
    80003c84:	1800                	addi	s0,sp,48
    80003c86:	84aa                	mv	s1,a0
    80003c88:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003c8a:	0001e917          	auipc	s2,0x1e
    80003c8e:	76690913          	addi	s2,s2,1894 # 800223f0 <log>
    80003c92:	00004597          	auipc	a1,0x4
    80003c96:	88658593          	addi	a1,a1,-1914 # 80007518 <etext+0x518>
    80003c9a:	854a                	mv	a0,s2
    80003c9c:	eddfc0ef          	jal	80000b78 <initlock>
  log.start = sb->logstart;
    80003ca0:	0149a583          	lw	a1,20(s3)
    80003ca4:	00b92c23          	sw	a1,24(s2)
  log.dev = dev;
    80003ca8:	02992223          	sw	s1,36(s2)
  struct buf *buf = bread(log.dev, log.start);
    80003cac:	8526                	mv	a0,s1
    80003cae:	f3bfe0ef          	jal	80002be8 <bread>
  log.lh.n = lh->n;
    80003cb2:	4d30                	lw	a2,88(a0)
    80003cb4:	02c92623          	sw	a2,44(s2)
  for (i = 0; i < log.lh.n; i++) {
    80003cb8:	00c05f63          	blez	a2,80003cd6 <initlog+0x5e>
    80003cbc:	87aa                	mv	a5,a0
    80003cbe:	0001e717          	auipc	a4,0x1e
    80003cc2:	76270713          	addi	a4,a4,1890 # 80022420 <log+0x30>
    80003cc6:	060a                	slli	a2,a2,0x2
    80003cc8:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003cca:	4ff4                	lw	a3,92(a5)
    80003ccc:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003cce:	0791                	addi	a5,a5,4
    80003cd0:	0711                	addi	a4,a4,4
    80003cd2:	fec79ce3          	bne	a5,a2,80003cca <initlog+0x52>
  brelse(buf);
    80003cd6:	81aff0ef          	jal	80002cf0 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003cda:	4505                	li	a0,1
    80003cdc:	ed1ff0ef          	jal	80003bac <install_trans>
  log.lh.n = 0;
    80003ce0:	0001e797          	auipc	a5,0x1e
    80003ce4:	7207ae23          	sw	zero,1852(a5) # 8002241c <log+0x2c>
  write_head(); // clear the log
    80003ce8:	e67ff0ef          	jal	80003b4e <write_head>
}
    80003cec:	70a2                	ld	ra,40(sp)
    80003cee:	7402                	ld	s0,32(sp)
    80003cf0:	64e2                	ld	s1,24(sp)
    80003cf2:	6942                	ld	s2,16(sp)
    80003cf4:	69a2                	ld	s3,8(sp)
    80003cf6:	6145                	addi	sp,sp,48
    80003cf8:	8082                	ret

0000000080003cfa <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003cfa:	1101                	addi	sp,sp,-32
    80003cfc:	ec06                	sd	ra,24(sp)
    80003cfe:	e822                	sd	s0,16(sp)
    80003d00:	e426                	sd	s1,8(sp)
    80003d02:	e04a                	sd	s2,0(sp)
    80003d04:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003d06:	0001e517          	auipc	a0,0x1e
    80003d0a:	6ea50513          	addi	a0,a0,1770 # 800223f0 <log>
    80003d0e:	eebfc0ef          	jal	80000bf8 <acquire>
  while (1) {
    if (log.committing) {
    80003d12:	0001e497          	auipc	s1,0x1e
    80003d16:	6de48493          	addi	s1,s1,1758 # 800223f0 <log>
      sleep_prepare(&log);
      release(&log.lock);
      sleep();
      acquire(&log.lock);
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003d1a:	4979                	li	s2,30
    80003d1c:	a821                	j	80003d34 <begin_op+0x3a>
      sleep_prepare(&log);
    80003d1e:	8526                	mv	a0,s1
    80003d20:	9cafe0ef          	jal	80001eea <sleep_prepare>
      release(&log.lock);
    80003d24:	8526                	mv	a0,s1
    80003d26:	f57fc0ef          	jal	80000c7c <release>
      sleep();
    80003d2a:	9fcfe0ef          	jal	80001f26 <sleep>
      acquire(&log.lock);
    80003d2e:	8526                	mv	a0,s1
    80003d30:	ec9fc0ef          	jal	80000bf8 <acquire>
    if (log.committing) {
    80003d34:	509c                	lw	a5,32(s1)
    80003d36:	f7e5                	bnez	a5,80003d1e <begin_op+0x24>
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003d38:	4cd8                	lw	a4,28(s1)
    80003d3a:	2705                	addiw	a4,a4,1
    80003d3c:	0027179b          	slliw	a5,a4,0x2
    80003d40:	9fb9                	addw	a5,a5,a4
    80003d42:	0017979b          	slliw	a5,a5,0x1
    80003d46:	54d4                	lw	a3,44(s1)
    80003d48:	9fb5                	addw	a5,a5,a3
    80003d4a:	00f95e63          	bge	s2,a5,80003d66 <begin_op+0x6c>
      // this op might exhaust log space; wait for commit.
      sleep_prepare(&log);
    80003d4e:	8526                	mv	a0,s1
    80003d50:	99afe0ef          	jal	80001eea <sleep_prepare>
      release(&log.lock);
    80003d54:	8526                	mv	a0,s1
    80003d56:	f27fc0ef          	jal	80000c7c <release>
      sleep();
    80003d5a:	9ccfe0ef          	jal	80001f26 <sleep>
      acquire(&log.lock);
    80003d5e:	8526                	mv	a0,s1
    80003d60:	e99fc0ef          	jal	80000bf8 <acquire>
    80003d64:	bfc1                	j	80003d34 <begin_op+0x3a>
    } else {
      log.outstanding += 1;
    80003d66:	0001e797          	auipc	a5,0x1e
    80003d6a:	6ae7a323          	sw	a4,1702(a5) # 8002240c <log+0x1c>
      release(&log.lock);
    80003d6e:	0001e517          	auipc	a0,0x1e
    80003d72:	68250513          	addi	a0,a0,1666 # 800223f0 <log>
    80003d76:	f07fc0ef          	jal	80000c7c <release>
      break;
    }
  }
}
    80003d7a:	60e2                	ld	ra,24(sp)
    80003d7c:	6442                	ld	s0,16(sp)
    80003d7e:	64a2                	ld	s1,8(sp)
    80003d80:	6902                	ld	s2,0(sp)
    80003d82:	6105                	addi	sp,sp,32
    80003d84:	8082                	ret

0000000080003d86 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003d86:	7139                	addi	sp,sp,-64
    80003d88:	fc06                	sd	ra,56(sp)
    80003d8a:	f822                	sd	s0,48(sp)
    80003d8c:	f426                	sd	s1,40(sp)
    80003d8e:	f04a                	sd	s2,32(sp)
    80003d90:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003d92:	0001e497          	auipc	s1,0x1e
    80003d96:	65e48493          	addi	s1,s1,1630 # 800223f0 <log>
    80003d9a:	8526                	mv	a0,s1
    80003d9c:	e5dfc0ef          	jal	80000bf8 <acquire>
  log.outstanding -= 1;
    80003da0:	4cdc                	lw	a5,28(s1)
    80003da2:	37fd                	addiw	a5,a5,-1
    80003da4:	893e                	mv	s2,a5
    80003da6:	ccdc                	sw	a5,28(s1)
  if (log.committing)
    80003da8:	509c                	lw	a5,32(s1)
    80003daa:	e7b9                	bnez	a5,80003df8 <end_op+0x72>
    panic("log.committing");
  if (log.outstanding == 0) {
    80003dac:	04091f63          	bnez	s2,80003e0a <end_op+0x84>
    do_commit = 1;
    log.committing = 1;
    80003db0:	0001e497          	auipc	s1,0x1e
    80003db4:	64048493          	addi	s1,s1,1600 # 800223f0 <log>
    80003db8:	4785                	li	a5,1
    80003dba:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003dbc:	8526                	mv	a0,s1
    80003dbe:	ebffc0ef          	jal	80000c7c <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003dc2:	54dc                	lw	a5,44(s1)
    80003dc4:	06f04063          	bgtz	a5,80003e24 <end_op+0x9e>
    acquire(&log.lock);
    80003dc8:	0001e497          	auipc	s1,0x1e
    80003dcc:	62848493          	addi	s1,s1,1576 # 800223f0 <log>
    80003dd0:	8526                	mv	a0,s1
    80003dd2:	e27fc0ef          	jal	80000bf8 <acquire>
    log.committing = 0;
    80003dd6:	0204a023          	sw	zero,32(s1)
    log.ncommit += 1;
    80003dda:	549c                	lw	a5,40(s1)
    80003ddc:	2785                	addiw	a5,a5,1
    80003dde:	d49c                	sw	a5,40(s1)
    wakeup(&log);
    80003de0:	8526                	mv	a0,s1
    80003de2:	974fe0ef          	jal	80001f56 <wakeup>
    release(&log.lock);
    80003de6:	8526                	mv	a0,s1
    80003de8:	e95fc0ef          	jal	80000c7c <release>
}
    80003dec:	70e2                	ld	ra,56(sp)
    80003dee:	7442                	ld	s0,48(sp)
    80003df0:	74a2                	ld	s1,40(sp)
    80003df2:	7902                	ld	s2,32(sp)
    80003df4:	6121                	addi	sp,sp,64
    80003df6:	8082                	ret
    80003df8:	ec4e                	sd	s3,24(sp)
    80003dfa:	e852                	sd	s4,16(sp)
    80003dfc:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003dfe:	00003517          	auipc	a0,0x3
    80003e02:	72250513          	addi	a0,a0,1826 # 80007520 <etext+0x520>
    80003e06:	a43fc0ef          	jal	80000848 <panic>
    wakeup(&log);
    80003e0a:	0001e517          	auipc	a0,0x1e
    80003e0e:	5e650513          	addi	a0,a0,1510 # 800223f0 <log>
    80003e12:	944fe0ef          	jal	80001f56 <wakeup>
  release(&log.lock);
    80003e16:	0001e517          	auipc	a0,0x1e
    80003e1a:	5da50513          	addi	a0,a0,1498 # 800223f0 <log>
    80003e1e:	e5ffc0ef          	jal	80000c7c <release>
  if (do_commit) {
    80003e22:	b7e9                	j	80003dec <end_op+0x66>
    80003e24:	ec4e                	sd	s3,24(sp)
    80003e26:	e852                	sd	s4,16(sp)
    80003e28:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003e2a:	0001ea97          	auipc	s5,0x1e
    80003e2e:	5f6a8a93          	addi	s5,s5,1526 # 80022420 <log+0x30>
    struct buf *to = bread(log.dev, log.start + tail + 1); // log block
    80003e32:	0001ea17          	auipc	s4,0x1e
    80003e36:	5bea0a13          	addi	s4,s4,1470 # 800223f0 <log>
    80003e3a:	018a2583          	lw	a1,24(s4)
    80003e3e:	012585bb          	addw	a1,a1,s2
    80003e42:	2585                	addiw	a1,a1,1
    80003e44:	024a2503          	lw	a0,36(s4)
    80003e48:	da1fe0ef          	jal	80002be8 <bread>
    80003e4c:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003e4e:	000aa583          	lw	a1,0(s5)
    80003e52:	024a2503          	lw	a0,36(s4)
    80003e56:	d93fe0ef          	jal	80002be8 <bread>
    80003e5a:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003e5c:	40000613          	li	a2,1024
    80003e60:	05850593          	addi	a1,a0,88
    80003e64:	05848513          	addi	a0,s1,88
    80003e68:	ea9fc0ef          	jal	80000d10 <memmove>
    bwrite(to); // write the log
    80003e6c:	8526                	mv	a0,s1
    80003e6e:	e51fe0ef          	jal	80002cbe <bwrite>
    brelse(from);
    80003e72:	854e                	mv	a0,s3
    80003e74:	e7dfe0ef          	jal	80002cf0 <brelse>
    brelse(to);
    80003e78:	8526                	mv	a0,s1
    80003e7a:	e77fe0ef          	jal	80002cf0 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003e7e:	2905                	addiw	s2,s2,1
    80003e80:	0a91                	addi	s5,s5,4
    80003e82:	02ca2783          	lw	a5,44(s4)
    80003e86:	faf94ae3          	blt	s2,a5,80003e3a <end_op+0xb4>
    write_log();      // Write modified blocks from cache to log
    write_head();     // Write header to disk -- the real commit
    80003e8a:	cc5ff0ef          	jal	80003b4e <write_head>
    install_trans(0); // Now install writes to home locations
    80003e8e:	4501                	li	a0,0
    80003e90:	d1dff0ef          	jal	80003bac <install_trans>
    log.lh.n = 0;
    80003e94:	0001e797          	auipc	a5,0x1e
    80003e98:	5807a423          	sw	zero,1416(a5) # 8002241c <log+0x2c>
    write_head(); // Erase the transaction from the log
    80003e9c:	cb3ff0ef          	jal	80003b4e <write_head>
    80003ea0:	69e2                	ld	s3,24(sp)
    80003ea2:	6a42                	ld	s4,16(sp)
    80003ea4:	6aa2                	ld	s5,8(sp)
    80003ea6:	b70d                	j	80003dc8 <end_op+0x42>

0000000080003ea8 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003ea8:	1101                	addi	sp,sp,-32
    80003eaa:	ec06                	sd	ra,24(sp)
    80003eac:	e822                	sd	s0,16(sp)
    80003eae:	e426                	sd	s1,8(sp)
    80003eb0:	1000                	addi	s0,sp,32
    80003eb2:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003eb4:	0001e517          	auipc	a0,0x1e
    80003eb8:	53c50513          	addi	a0,a0,1340 # 800223f0 <log>
    80003ebc:	d3dfc0ef          	jal	80000bf8 <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80003ec0:	0001e617          	auipc	a2,0x1e
    80003ec4:	55c62603          	lw	a2,1372(a2) # 8002241c <log+0x2c>
    80003ec8:	47f5                	li	a5,29
    80003eca:	04c7cc63          	blt	a5,a2,80003f22 <log_write+0x7a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003ece:	0001e797          	auipc	a5,0x1e
    80003ed2:	53e7a783          	lw	a5,1342(a5) # 8002240c <log+0x1c>
    80003ed6:	04f05c63          	blez	a5,80003f2e <log_write+0x86>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003eda:	4781                	li	a5,0
    80003edc:	04c05f63          	blez	a2,80003f3a <log_write+0x92>
    if (log.lh.block[i] == b->blockno) // log absorption
    80003ee0:	44cc                	lw	a1,12(s1)
    80003ee2:	0001e717          	auipc	a4,0x1e
    80003ee6:	53e70713          	addi	a4,a4,1342 # 80022420 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80003eea:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno) // log absorption
    80003eec:	4314                	lw	a3,0(a4)
    80003eee:	04b68663          	beq	a3,a1,80003f3a <log_write+0x92>
  for (i = 0; i < log.lh.n; i++) {
    80003ef2:	2785                	addiw	a5,a5,1
    80003ef4:	0711                	addi	a4,a4,4
    80003ef6:	fef61be3          	bne	a2,a5,80003eec <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003efa:	0621                	addi	a2,a2,8
    80003efc:	060a                	slli	a2,a2,0x2
    80003efe:	0001e797          	auipc	a5,0x1e
    80003f02:	4f278793          	addi	a5,a5,1266 # 800223f0 <log>
    80003f06:	97b2                	add	a5,a5,a2
    80003f08:	44d8                	lw	a4,12(s1)
    80003f0a:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) { // Add new block to log?
    bpin(b);
    80003f0c:	8526                	mv	a0,s1
    80003f0e:	e67fe0ef          	jal	80002d74 <bpin>
    log.lh.n++;
    80003f12:	0001e717          	auipc	a4,0x1e
    80003f16:	4de70713          	addi	a4,a4,1246 # 800223f0 <log>
    80003f1a:	575c                	lw	a5,44(a4)
    80003f1c:	2785                	addiw	a5,a5,1
    80003f1e:	d75c                	sw	a5,44(a4)
    80003f20:	a80d                	j	80003f52 <log_write+0xaa>
    panic("too big a transaction");
    80003f22:	00003517          	auipc	a0,0x3
    80003f26:	60e50513          	addi	a0,a0,1550 # 80007530 <etext+0x530>
    80003f2a:	91ffc0ef          	jal	80000848 <panic>
    panic("log_write outside of trans");
    80003f2e:	00003517          	auipc	a0,0x3
    80003f32:	61a50513          	addi	a0,a0,1562 # 80007548 <etext+0x548>
    80003f36:	913fc0ef          	jal	80000848 <panic>
  log.lh.block[i] = b->blockno;
    80003f3a:	00878693          	addi	a3,a5,8
    80003f3e:	068a                	slli	a3,a3,0x2
    80003f40:	0001e717          	auipc	a4,0x1e
    80003f44:	4b070713          	addi	a4,a4,1200 # 800223f0 <log>
    80003f48:	9736                	add	a4,a4,a3
    80003f4a:	44d4                	lw	a3,12(s1)
    80003f4c:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) { // Add new block to log?
    80003f4e:	faf60fe3          	beq	a2,a5,80003f0c <log_write+0x64>
  }
  release(&log.lock);
    80003f52:	0001e517          	auipc	a0,0x1e
    80003f56:	49e50513          	addi	a0,a0,1182 # 800223f0 <log>
    80003f5a:	d23fc0ef          	jal	80000c7c <release>
}
    80003f5e:	60e2                	ld	ra,24(sp)
    80003f60:	6442                	ld	s0,16(sp)
    80003f62:	64a2                	ld	s1,8(sp)
    80003f64:	6105                	addi	sp,sp,32
    80003f66:	8082                	ret

0000000080003f68 <sys_sync>:

uint64
sys_sync(void)
{
    80003f68:	1101                	addi	sp,sp,-32
    80003f6a:	ec06                	sd	ra,24(sp)
    80003f6c:	e822                	sd	s0,16(sp)
    80003f6e:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003f70:	0001e517          	auipc	a0,0x1e
    80003f74:	48050513          	addi	a0,a0,1152 # 800223f0 <log>
    80003f78:	c81fc0ef          	jal	80000bf8 <acquire>
  if (log.committing || log.outstanding > 0) {
    80003f7c:	0001e797          	auipc	a5,0x1e
    80003f80:	4947a783          	lw	a5,1172(a5) # 80022410 <log+0x20>
    80003f84:	e799                	bnez	a5,80003f92 <sys_sync+0x2a>
    80003f86:	0001e797          	auipc	a5,0x1e
    80003f8a:	4867a783          	lw	a5,1158(a5) # 8002240c <log+0x1c>
    80003f8e:	02f05c63          	blez	a5,80003fc6 <sys_sync+0x5e>
    80003f92:	e426                	sd	s1,8(sp)
    80003f94:	e04a                	sd	s2,0(sp)
    int n = log.ncommit + 1;
    80003f96:	0001e917          	auipc	s2,0x1e
    80003f9a:	48292903          	lw	s2,1154(s2) # 80022418 <log+0x28>
    while (log.ncommit < n) {
      sleep_prepare(&log);
    80003f9e:	0001e497          	auipc	s1,0x1e
    80003fa2:	45248493          	addi	s1,s1,1106 # 800223f0 <log>
    80003fa6:	8526                	mv	a0,s1
    80003fa8:	f43fd0ef          	jal	80001eea <sleep_prepare>
      release(&log.lock);
    80003fac:	8526                	mv	a0,s1
    80003fae:	ccffc0ef          	jal	80000c7c <release>
      sleep();
    80003fb2:	f75fd0ef          	jal	80001f26 <sleep>
      acquire(&log.lock);
    80003fb6:	8526                	mv	a0,s1
    80003fb8:	c41fc0ef          	jal	80000bf8 <acquire>
    while (log.ncommit < n) {
    80003fbc:	549c                	lw	a5,40(s1)
    80003fbe:	fef954e3          	bge	s2,a5,80003fa6 <sys_sync+0x3e>
    80003fc2:	64a2                	ld	s1,8(sp)
    80003fc4:	6902                	ld	s2,0(sp)
    }
  }
  release(&log.lock);
    80003fc6:	0001e517          	auipc	a0,0x1e
    80003fca:	42a50513          	addi	a0,a0,1066 # 800223f0 <log>
    80003fce:	caffc0ef          	jal	80000c7c <release>
  return 0;
}
    80003fd2:	4501                	li	a0,0
    80003fd4:	60e2                	ld	ra,24(sp)
    80003fd6:	6442                	ld	s0,16(sp)
    80003fd8:	6105                	addi	sp,sp,32
    80003fda:	8082                	ret

0000000080003fdc <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003fdc:	1101                	addi	sp,sp,-32
    80003fde:	ec06                	sd	ra,24(sp)
    80003fe0:	e822                	sd	s0,16(sp)
    80003fe2:	e426                	sd	s1,8(sp)
    80003fe4:	e04a                	sd	s2,0(sp)
    80003fe6:	1000                	addi	s0,sp,32
    80003fe8:	84aa                	mv	s1,a0
    80003fea:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80003fec:	00003597          	auipc	a1,0x3
    80003ff0:	57c58593          	addi	a1,a1,1404 # 80007568 <etext+0x568>
    80003ff4:	0521                	addi	a0,a0,8
    80003ff6:	b83fc0ef          	jal	80000b78 <initlock>
  lk->name = name;
    80003ffa:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80003ffe:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004002:	0204a423          	sw	zero,40(s1)
}
    80004006:	60e2                	ld	ra,24(sp)
    80004008:	6442                	ld	s0,16(sp)
    8000400a:	64a2                	ld	s1,8(sp)
    8000400c:	6902                	ld	s2,0(sp)
    8000400e:	6105                	addi	sp,sp,32
    80004010:	8082                	ret

0000000080004012 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80004012:	1101                	addi	sp,sp,-32
    80004014:	ec06                	sd	ra,24(sp)
    80004016:	e822                	sd	s0,16(sp)
    80004018:	e426                	sd	s1,8(sp)
    8000401a:	e04a                	sd	s2,0(sp)
    8000401c:	1000                	addi	s0,sp,32
    8000401e:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004020:	00850913          	addi	s2,a0,8
    80004024:	854a                	mv	a0,s2
    80004026:	bd3fc0ef          	jal	80000bf8 <acquire>
  while (lk->locked) {
    8000402a:	409c                	lw	a5,0(s1)
    8000402c:	cf91                	beqz	a5,80004048 <acquiresleep+0x36>
    sleep_prepare(lk);
    8000402e:	8526                	mv	a0,s1
    80004030:	ebbfd0ef          	jal	80001eea <sleep_prepare>
    release(&lk->lk);
    80004034:	854a                	mv	a0,s2
    80004036:	c47fc0ef          	jal	80000c7c <release>
    sleep();
    8000403a:	eedfd0ef          	jal	80001f26 <sleep>
    acquire(&lk->lk);
    8000403e:	854a                	mv	a0,s2
    80004040:	bb9fc0ef          	jal	80000bf8 <acquire>
  while (lk->locked) {
    80004044:	409c                	lw	a5,0(s1)
    80004046:	f7e5                	bnez	a5,8000402e <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80004048:	4785                	li	a5,1
    8000404a:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    8000404c:	897fd0ef          	jal	800018e2 <myproc>
    80004050:	591c                	lw	a5,48(a0)
    80004052:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80004054:	854a                	mv	a0,s2
    80004056:	c27fc0ef          	jal	80000c7c <release>
}
    8000405a:	60e2                	ld	ra,24(sp)
    8000405c:	6442                	ld	s0,16(sp)
    8000405e:	64a2                	ld	s1,8(sp)
    80004060:	6902                	ld	s2,0(sp)
    80004062:	6105                	addi	sp,sp,32
    80004064:	8082                	ret

0000000080004066 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80004066:	1101                	addi	sp,sp,-32
    80004068:	ec06                	sd	ra,24(sp)
    8000406a:	e822                	sd	s0,16(sp)
    8000406c:	e426                	sd	s1,8(sp)
    8000406e:	e04a                	sd	s2,0(sp)
    80004070:	1000                	addi	s0,sp,32
    80004072:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004074:	00850913          	addi	s2,a0,8
    80004078:	854a                	mv	a0,s2
    8000407a:	b7ffc0ef          	jal	80000bf8 <acquire>
  lk->locked = 0;
    8000407e:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004082:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80004086:	8526                	mv	a0,s1
    80004088:	ecffd0ef          	jal	80001f56 <wakeup>
  release(&lk->lk);
    8000408c:	854a                	mv	a0,s2
    8000408e:	beffc0ef          	jal	80000c7c <release>
}
    80004092:	60e2                	ld	ra,24(sp)
    80004094:	6442                	ld	s0,16(sp)
    80004096:	64a2                	ld	s1,8(sp)
    80004098:	6902                	ld	s2,0(sp)
    8000409a:	6105                	addi	sp,sp,32
    8000409c:	8082                	ret

000000008000409e <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    8000409e:	7179                	addi	sp,sp,-48
    800040a0:	f406                	sd	ra,40(sp)
    800040a2:	f022                	sd	s0,32(sp)
    800040a4:	ec26                	sd	s1,24(sp)
    800040a6:	e84a                	sd	s2,16(sp)
    800040a8:	1800                	addi	s0,sp,48
    800040aa:	84aa                	mv	s1,a0
  int r;

  acquire(&lk->lk);
    800040ac:	00850913          	addi	s2,a0,8
    800040b0:	854a                	mv	a0,s2
    800040b2:	b47fc0ef          	jal	80000bf8 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    800040b6:	409c                	lw	a5,0(s1)
    800040b8:	ef81                	bnez	a5,800040d0 <holdingsleep+0x32>
    800040ba:	4481                	li	s1,0
  release(&lk->lk);
    800040bc:	854a                	mv	a0,s2
    800040be:	bbffc0ef          	jal	80000c7c <release>
  return r;
}
    800040c2:	8526                	mv	a0,s1
    800040c4:	70a2                	ld	ra,40(sp)
    800040c6:	7402                	ld	s0,32(sp)
    800040c8:	64e2                	ld	s1,24(sp)
    800040ca:	6942                	ld	s2,16(sp)
    800040cc:	6145                	addi	sp,sp,48
    800040ce:	8082                	ret
    800040d0:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    800040d2:	0284a983          	lw	s3,40(s1)
    800040d6:	80dfd0ef          	jal	800018e2 <myproc>
    800040da:	5904                	lw	s1,48(a0)
    800040dc:	413484b3          	sub	s1,s1,s3
    800040e0:	0014b493          	seqz	s1,s1
    800040e4:	69a2                	ld	s3,8(sp)
    800040e6:	bfd9                	j	800040bc <holdingsleep+0x1e>

00000000800040e8 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800040e8:	1141                	addi	sp,sp,-16
    800040ea:	e406                	sd	ra,8(sp)
    800040ec:	e022                	sd	s0,0(sp)
    800040ee:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    800040f0:	00003597          	auipc	a1,0x3
    800040f4:	48858593          	addi	a1,a1,1160 # 80007578 <etext+0x578>
    800040f8:	0001e517          	auipc	a0,0x1e
    800040fc:	44050513          	addi	a0,a0,1088 # 80022538 <ftable>
    80004100:	a79fc0ef          	jal	80000b78 <initlock>
}
    80004104:	60a2                	ld	ra,8(sp)
    80004106:	6402                	ld	s0,0(sp)
    80004108:	0141                	addi	sp,sp,16
    8000410a:	8082                	ret

000000008000410c <filealloc>:

// Allocate a file structure.
struct file *
filealloc(void)
{
    8000410c:	1101                	addi	sp,sp,-32
    8000410e:	ec06                	sd	ra,24(sp)
    80004110:	e822                	sd	s0,16(sp)
    80004112:	e426                	sd	s1,8(sp)
    80004114:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80004116:	0001e517          	auipc	a0,0x1e
    8000411a:	42250513          	addi	a0,a0,1058 # 80022538 <ftable>
    8000411e:	adbfc0ef          	jal	80000bf8 <acquire>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    80004122:	0001e497          	auipc	s1,0x1e
    80004126:	42e48493          	addi	s1,s1,1070 # 80022550 <ftable+0x18>
    8000412a:	0001f717          	auipc	a4,0x1f
    8000412e:	3c670713          	addi	a4,a4,966 # 800234f0 <disk>
    if (f->ref == 0) {
    80004132:	40dc                	lw	a5,4(s1)
    80004134:	cf89                	beqz	a5,8000414e <filealloc+0x42>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    80004136:	02848493          	addi	s1,s1,40
    8000413a:	fee49ce3          	bne	s1,a4,80004132 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    8000413e:	0001e517          	auipc	a0,0x1e
    80004142:	3fa50513          	addi	a0,a0,1018 # 80022538 <ftable>
    80004146:	b37fc0ef          	jal	80000c7c <release>
  return 0;
    8000414a:	4481                	li	s1,0
    8000414c:	a809                	j	8000415e <filealloc+0x52>
      f->ref = 1;
    8000414e:	4785                	li	a5,1
    80004150:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80004152:	0001e517          	auipc	a0,0x1e
    80004156:	3e650513          	addi	a0,a0,998 # 80022538 <ftable>
    8000415a:	b23fc0ef          	jal	80000c7c <release>
}
    8000415e:	8526                	mv	a0,s1
    80004160:	60e2                	ld	ra,24(sp)
    80004162:	6442                	ld	s0,16(sp)
    80004164:	64a2                	ld	s1,8(sp)
    80004166:	6105                	addi	sp,sp,32
    80004168:	8082                	ret

000000008000416a <filedup>:

// Increment ref count for file f.
struct file *
filedup(struct file *f)
{
    8000416a:	1101                	addi	sp,sp,-32
    8000416c:	ec06                	sd	ra,24(sp)
    8000416e:	e822                	sd	s0,16(sp)
    80004170:	e426                	sd	s1,8(sp)
    80004172:	1000                	addi	s0,sp,32
    80004174:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80004176:	0001e517          	auipc	a0,0x1e
    8000417a:	3c250513          	addi	a0,a0,962 # 80022538 <ftable>
    8000417e:	a7bfc0ef          	jal	80000bf8 <acquire>
  if (f->ref < 1)
    80004182:	40dc                	lw	a5,4(s1)
    80004184:	02f05063          	blez	a5,800041a4 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80004188:	2785                	addiw	a5,a5,1
    8000418a:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    8000418c:	0001e517          	auipc	a0,0x1e
    80004190:	3ac50513          	addi	a0,a0,940 # 80022538 <ftable>
    80004194:	ae9fc0ef          	jal	80000c7c <release>
  return f;
}
    80004198:	8526                	mv	a0,s1
    8000419a:	60e2                	ld	ra,24(sp)
    8000419c:	6442                	ld	s0,16(sp)
    8000419e:	64a2                	ld	s1,8(sp)
    800041a0:	6105                	addi	sp,sp,32
    800041a2:	8082                	ret
    panic("filedup");
    800041a4:	00003517          	auipc	a0,0x3
    800041a8:	3dc50513          	addi	a0,a0,988 # 80007580 <etext+0x580>
    800041ac:	e9cfc0ef          	jal	80000848 <panic>

00000000800041b0 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    800041b0:	7139                	addi	sp,sp,-64
    800041b2:	fc06                	sd	ra,56(sp)
    800041b4:	f822                	sd	s0,48(sp)
    800041b6:	f426                	sd	s1,40(sp)
    800041b8:	0080                	addi	s0,sp,64
    800041ba:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    800041bc:	0001e517          	auipc	a0,0x1e
    800041c0:	37c50513          	addi	a0,a0,892 # 80022538 <ftable>
    800041c4:	a35fc0ef          	jal	80000bf8 <acquire>
  if (f->ref < 1)
    800041c8:	40dc                	lw	a5,4(s1)
    800041ca:	04f05a63          	blez	a5,8000421e <fileclose+0x6e>
    panic("fileclose");
  if (--f->ref > 0) {
    800041ce:	37fd                	addiw	a5,a5,-1
    800041d0:	c0dc                	sw	a5,4(s1)
    800041d2:	06f04063          	bgtz	a5,80004232 <fileclose+0x82>
    800041d6:	f04a                	sd	s2,32(sp)
    800041d8:	ec4e                	sd	s3,24(sp)
    800041da:	e852                	sd	s4,16(sp)
    800041dc:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    800041de:	0004a903          	lw	s2,0(s1)
    800041e2:	0094c783          	lbu	a5,9(s1)
    800041e6:	89be                	mv	s3,a5
    800041e8:	689c                	ld	a5,16(s1)
    800041ea:	8a3e                	mv	s4,a5
    800041ec:	6c9c                	ld	a5,24(s1)
    800041ee:	8abe                	mv	s5,a5
  f->ref = 0;
    800041f0:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    800041f4:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    800041f8:	0001e517          	auipc	a0,0x1e
    800041fc:	34050513          	addi	a0,a0,832 # 80022538 <ftable>
    80004200:	a7dfc0ef          	jal	80000c7c <release>

  if (ff.type == FD_PIPE) {
    80004204:	4785                	li	a5,1
    80004206:	04f90163          	beq	s2,a5,80004248 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if (ff.type == FD_INODE || ff.type == FD_DEVICE) {
    8000420a:	ffe9079b          	addiw	a5,s2,-2
    8000420e:	4705                	li	a4,1
    80004210:	04f77563          	bgeu	a4,a5,8000425a <fileclose+0xaa>
    80004214:	7902                	ld	s2,32(sp)
    80004216:	69e2                	ld	s3,24(sp)
    80004218:	6a42                	ld	s4,16(sp)
    8000421a:	6aa2                	ld	s5,8(sp)
    8000421c:	a00d                	j	8000423e <fileclose+0x8e>
    8000421e:	f04a                	sd	s2,32(sp)
    80004220:	ec4e                	sd	s3,24(sp)
    80004222:	e852                	sd	s4,16(sp)
    80004224:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80004226:	00003517          	auipc	a0,0x3
    8000422a:	36250513          	addi	a0,a0,866 # 80007588 <etext+0x588>
    8000422e:	e1afc0ef          	jal	80000848 <panic>
    release(&ftable.lock);
    80004232:	0001e517          	auipc	a0,0x1e
    80004236:	30650513          	addi	a0,a0,774 # 80022538 <ftable>
    8000423a:	a43fc0ef          	jal	80000c7c <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    8000423e:	70e2                	ld	ra,56(sp)
    80004240:	7442                	ld	s0,48(sp)
    80004242:	74a2                	ld	s1,40(sp)
    80004244:	6121                	addi	sp,sp,64
    80004246:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80004248:	85ce                	mv	a1,s3
    8000424a:	8552                	mv	a0,s4
    8000424c:	348000ef          	jal	80004594 <pipeclose>
    80004250:	7902                	ld	s2,32(sp)
    80004252:	69e2                	ld	s3,24(sp)
    80004254:	6a42                	ld	s4,16(sp)
    80004256:	6aa2                	ld	s5,8(sp)
    80004258:	b7dd                	j	8000423e <fileclose+0x8e>
    begin_op();
    8000425a:	aa1ff0ef          	jal	80003cfa <begin_op>
    iput(ff.ip);
    8000425e:	8556                	mv	a0,s5
    80004260:	9aaff0ef          	jal	8000340a <iput>
    end_op();
    80004264:	b23ff0ef          	jal	80003d86 <end_op>
    80004268:	7902                	ld	s2,32(sp)
    8000426a:	69e2                	ld	s3,24(sp)
    8000426c:	6a42                	ld	s4,16(sp)
    8000426e:	6aa2                	ld	s5,8(sp)
    80004270:	b7f9                	j	8000423e <fileclose+0x8e>

0000000080004272 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80004272:	715d                	addi	sp,sp,-80
    80004274:	e486                	sd	ra,72(sp)
    80004276:	e0a2                	sd	s0,64(sp)
    80004278:	fc26                	sd	s1,56(sp)
    8000427a:	f052                	sd	s4,32(sp)
    8000427c:	0880                	addi	s0,sp,80
    8000427e:	84aa                	mv	s1,a0
    80004280:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    80004282:	e60fd0ef          	jal	800018e2 <myproc>
  struct stat st;

  if (f->type == FD_INODE || f->type == FD_DEVICE) {
    80004286:	409c                	lw	a5,0(s1)
    80004288:	37f9                	addiw	a5,a5,-2
    8000428a:	4705                	li	a4,1
    8000428c:	04f76463          	bltu	a4,a5,800042d4 <filestat+0x62>
    80004290:	f84a                	sd	s2,48(sp)
    80004292:	f44e                	sd	s3,40(sp)
    80004294:	892a                	mv	s2,a0
    ilock(f->ip);
    80004296:	6c88                	ld	a0,24(s1)
    80004298:	ff1fe0ef          	jal	80003288 <ilock>
    stati(f->ip, &st);
    8000429c:	fb840993          	addi	s3,s0,-72
    800042a0:	85ce                	mv	a1,s3
    800042a2:	6c88                	ld	a0,24(s1)
    800042a4:	b90ff0ef          	jal	80003634 <stati>
    iunlock(f->ip);
    800042a8:	6c88                	ld	a0,24(s1)
    800042aa:	88cff0ef          	jal	80003336 <iunlock>
    if (copyout(p->pagetable, p->sz, addr, (char *)&st, sizeof(st)) < 0)
    800042ae:	4761                	li	a4,24
    800042b0:	86ce                	mv	a3,s3
    800042b2:	8652                	mv	a2,s4
    800042b4:	04893583          	ld	a1,72(s2)
    800042b8:	05093503          	ld	a0,80(s2)
    800042bc:	a70fd0ef          	jal	8000152c <copyout>
    800042c0:	41f5551b          	sraiw	a0,a0,0x1f
    800042c4:	7942                	ld	s2,48(sp)
    800042c6:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    800042c8:	60a6                	ld	ra,72(sp)
    800042ca:	6406                	ld	s0,64(sp)
    800042cc:	74e2                	ld	s1,56(sp)
    800042ce:	7a02                	ld	s4,32(sp)
    800042d0:	6161                	addi	sp,sp,80
    800042d2:	8082                	ret
  return -1;
    800042d4:	557d                	li	a0,-1
    800042d6:	bfcd                	j	800042c8 <filestat+0x56>

00000000800042d8 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    800042d8:	7179                	addi	sp,sp,-48
    800042da:	f406                	sd	ra,40(sp)
    800042dc:	f022                	sd	s0,32(sp)
    800042de:	e84a                	sd	s2,16(sp)
    800042e0:	1800                	addi	s0,sp,48
  int r = 0;

  if (f->readable == 0 || n < 0)
    800042e2:	00854783          	lbu	a5,8(a0)
    800042e6:	0017b793          	seqz	a5,a5
    800042ea:	01f6571b          	srliw	a4,a2,0x1f
    800042ee:	8fd9                	or	a5,a5,a4
    800042f0:	e3c5                	bnez	a5,80004390 <fileread+0xb8>
    800042f2:	ec26                	sd	s1,24(sp)
    800042f4:	e44e                	sd	s3,8(sp)
    800042f6:	84aa                	mv	s1,a0
    800042f8:	892e                	mv	s2,a1
    800042fa:	89b2                	mv	s3,a2
    return -1;

  if (f->type == FD_PIPE) {
    800042fc:	411c                	lw	a5,0(a0)
    800042fe:	4705                	li	a4,1
    80004300:	04e78363          	beq	a5,a4,80004346 <fileread+0x6e>
    r = piperead(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    80004304:	470d                	li	a4,3
    80004306:	04e78763          	beq	a5,a4,80004354 <fileread+0x7c>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if (f->type == FD_INODE) {
    8000430a:	4709                	li	a4,2
    8000430c:	06e79a63          	bne	a5,a4,80004380 <fileread+0xa8>
    ilock(f->ip);
    80004310:	6d08                	ld	a0,24(a0)
    80004312:	f77fe0ef          	jal	80003288 <ilock>
    if ((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004316:	874e                	mv	a4,s3
    80004318:	5094                	lw	a3,32(s1)
    8000431a:	864a                	mv	a2,s2
    8000431c:	4585                	li	a1,1
    8000431e:	6c88                	ld	a0,24(s1)
    80004320:	b42ff0ef          	jal	80003662 <readi>
    80004324:	892a                	mv	s2,a0
    80004326:	00a05563          	blez	a0,80004330 <fileread+0x58>
      f->off += r;
    8000432a:	509c                	lw	a5,32(s1)
    8000432c:	9fa9                	addw	a5,a5,a0
    8000432e:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80004330:	6c88                	ld	a0,24(s1)
    80004332:	804ff0ef          	jal	80003336 <iunlock>
    80004336:	64e2                	ld	s1,24(sp)
    80004338:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    8000433a:	854a                	mv	a0,s2
    8000433c:	70a2                	ld	ra,40(sp)
    8000433e:	7402                	ld	s0,32(sp)
    80004340:	6942                	ld	s2,16(sp)
    80004342:	6145                	addi	sp,sp,48
    80004344:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004346:	6908                	ld	a0,16(a0)
    80004348:	3c6000ef          	jal	8000470e <piperead>
    8000434c:	892a                	mv	s2,a0
    8000434e:	64e2                	ld	s1,24(sp)
    80004350:	69a2                	ld	s3,8(sp)
    80004352:	b7e5                	j	8000433a <fileread+0x62>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80004354:	02451783          	lh	a5,36(a0)
    80004358:	03079693          	slli	a3,a5,0x30
    8000435c:	92c1                	srli	a3,a3,0x30
    8000435e:	4725                	li	a4,9
    80004360:	02d76663          	bltu	a4,a3,8000438c <fileread+0xb4>
    80004364:	0792                	slli	a5,a5,0x4
    80004366:	0001e717          	auipc	a4,0x1e
    8000436a:	13270713          	addi	a4,a4,306 # 80022498 <devsw>
    8000436e:	97ba                	add	a5,a5,a4
    80004370:	639c                	ld	a5,0(a5)
    80004372:	c395                	beqz	a5,80004396 <fileread+0xbe>
    r = devsw[f->major].read(1, addr, n);
    80004374:	4505                	li	a0,1
    80004376:	9782                	jalr	a5
    80004378:	892a                	mv	s2,a0
    8000437a:	64e2                	ld	s1,24(sp)
    8000437c:	69a2                	ld	s3,8(sp)
    8000437e:	bf75                	j	8000433a <fileread+0x62>
    panic("fileread");
    80004380:	00003517          	auipc	a0,0x3
    80004384:	21850513          	addi	a0,a0,536 # 80007598 <etext+0x598>
    80004388:	cc0fc0ef          	jal	80000848 <panic>
    8000438c:	64e2                	ld	s1,24(sp)
    8000438e:	69a2                	ld	s3,8(sp)
    return -1;
    80004390:	57fd                	li	a5,-1
    80004392:	893e                	mv	s2,a5
    80004394:	b75d                	j	8000433a <fileread+0x62>
    80004396:	64e2                	ld	s1,24(sp)
    80004398:	69a2                	ld	s3,8(sp)
    8000439a:	bfdd                	j	80004390 <fileread+0xb8>

000000008000439c <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if (f->writable == 0 || n < 0)
    8000439c:	00954783          	lbu	a5,9(a0)
    800043a0:	0017b793          	seqz	a5,a5
    800043a4:	01f6571b          	srliw	a4,a2,0x1f
    800043a8:	8fd9                	or	a5,a5,a4
    800043aa:	12079363          	bnez	a5,800044d0 <filewrite+0x134>
{
    800043ae:	711d                	addi	sp,sp,-96
    800043b0:	ec86                	sd	ra,88(sp)
    800043b2:	e8a2                	sd	s0,80(sp)
    800043b4:	e0ca                	sd	s2,64(sp)
    800043b6:	f456                	sd	s5,40(sp)
    800043b8:	f05a                	sd	s6,32(sp)
    800043ba:	1080                	addi	s0,sp,96
    800043bc:	892a                	mv	s2,a0
    800043be:	8b2e                	mv	s6,a1
    800043c0:	8ab2                	mv	s5,a2
    return -1;

  if (f->type == FD_PIPE) {
    800043c2:	411c                	lw	a5,0(a0)
    800043c4:	4705                	li	a4,1
    800043c6:	02e78a63          	beq	a5,a4,800043fa <filewrite+0x5e>
    ret = pipewrite(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    800043ca:	470d                	li	a4,3
    800043cc:	02e78b63          	beq	a5,a4,80004402 <filewrite+0x66>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if (f->type == FD_INODE) {
    800043d0:	4709                	li	a4,2
    800043d2:	0ce79763          	bne	a5,a4,800044a0 <filewrite+0x104>
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS - 1 - 1 - 2) / 2) * BSIZE;
    int i = 0;
    while (i < n) {
    800043d6:	0ec05363          	blez	a2,800044bc <filewrite+0x120>
    800043da:	e4a6                	sd	s1,72(sp)
    800043dc:	fc4e                	sd	s3,56(sp)
    800043de:	f852                	sd	s4,48(sp)
    800043e0:	ec5e                	sd	s7,24(sp)
    800043e2:	e862                	sd	s8,16(sp)
    800043e4:	e466                	sd	s9,8(sp)
    int i = 0;
    800043e6:	4a01                	li	s4,0
      int n1 = n - i;
      if (n1 > max)
    800043e8:	6b85                	lui	s7,0x1
    800043ea:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    800043ee:	6785                	lui	a5,0x1
    800043f0:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    800043f4:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800043f6:	4c05                	li	s8,1
    800043f8:	a8ad                	j	80004472 <filewrite+0xd6>
    ret = pipewrite(f->pipe, addr, n);
    800043fa:	6908                	ld	a0,16(a0)
    800043fc:	1f6000ef          	jal	800045f2 <pipewrite>
    80004400:	a849                	j	80004492 <filewrite+0xf6>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004402:	02451783          	lh	a5,36(a0)
    80004406:	03079693          	slli	a3,a5,0x30
    8000440a:	92c1                	srli	a3,a3,0x30
    8000440c:	4725                	li	a4,9
    8000440e:	0ad76563          	bltu	a4,a3,800044b8 <filewrite+0x11c>
    80004412:	0792                	slli	a5,a5,0x4
    80004414:	0001e717          	auipc	a4,0x1e
    80004418:	08470713          	addi	a4,a4,132 # 80022498 <devsw>
    8000441c:	97ba                	add	a5,a5,a4
    8000441e:	679c                	ld	a5,8(a5)
    80004420:	cfc1                	beqz	a5,800044b8 <filewrite+0x11c>
    ret = devsw[f->major].write(1, addr, n);
    80004422:	4505                	li	a0,1
    80004424:	9782                	jalr	a5
    80004426:	a0b5                	j	80004492 <filewrite+0xf6>
      if (n1 > max)
    80004428:	2981                	sext.w	s3,s3
      begin_op();
    8000442a:	8d1ff0ef          	jal	80003cfa <begin_op>
      ilock(f->ip);
    8000442e:	01893503          	ld	a0,24(s2)
    80004432:	e57fe0ef          	jal	80003288 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004436:	874e                	mv	a4,s3
    80004438:	02092683          	lw	a3,32(s2)
    8000443c:	016a0633          	add	a2,s4,s6
    80004440:	85e2                	mv	a1,s8
    80004442:	01893503          	ld	a0,24(s2)
    80004446:	b0eff0ef          	jal	80003754 <writei>
    8000444a:	84aa                	mv	s1,a0
    8000444c:	00a05763          	blez	a0,8000445a <filewrite+0xbe>
        f->off += r;
    80004450:	02092783          	lw	a5,32(s2)
    80004454:	9fa9                	addw	a5,a5,a0
    80004456:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    8000445a:	01893503          	ld	a0,24(s2)
    8000445e:	ed9fe0ef          	jal	80003336 <iunlock>
      end_op();
    80004462:	925ff0ef          	jal	80003d86 <end_op>

      if (r != n1) {
    80004466:	00999d63          	bne	s3,s1,80004480 <filewrite+0xe4>
        // error from writei
        break;
      }
      i += r;
    8000446a:	01448a3b          	addw	s4,s1,s4
    while (i < n) {
    8000446e:	015a5963          	bge	s4,s5,80004480 <filewrite+0xe4>
      int n1 = n - i;
    80004472:	414a87bb          	subw	a5,s5,s4
    80004476:	89be                	mv	s3,a5
      if (n1 > max)
    80004478:	fafbd8e3          	bge	s7,a5,80004428 <filewrite+0x8c>
    8000447c:	89e6                	mv	s3,s9
    8000447e:	b76d                	j	80004428 <filewrite+0x8c>
    }
    ret = (i == n ? n : -1);
    80004480:	054a9063          	bne	s5,s4,800044c0 <filewrite+0x124>
    80004484:	8556                	mv	a0,s5
    80004486:	64a6                	ld	s1,72(sp)
    80004488:	79e2                	ld	s3,56(sp)
    8000448a:	7a42                	ld	s4,48(sp)
    8000448c:	6be2                	ld	s7,24(sp)
    8000448e:	6c42                	ld	s8,16(sp)
    80004490:	6ca2                	ld	s9,8(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80004492:	60e6                	ld	ra,88(sp)
    80004494:	6446                	ld	s0,80(sp)
    80004496:	6906                	ld	s2,64(sp)
    80004498:	7aa2                	ld	s5,40(sp)
    8000449a:	7b02                	ld	s6,32(sp)
    8000449c:	6125                	addi	sp,sp,96
    8000449e:	8082                	ret
    800044a0:	e4a6                	sd	s1,72(sp)
    800044a2:	fc4e                	sd	s3,56(sp)
    800044a4:	f852                	sd	s4,48(sp)
    800044a6:	ec5e                	sd	s7,24(sp)
    800044a8:	e862                	sd	s8,16(sp)
    800044aa:	e466                	sd	s9,8(sp)
    panic("filewrite");
    800044ac:	00003517          	auipc	a0,0x3
    800044b0:	0fc50513          	addi	a0,a0,252 # 800075a8 <etext+0x5a8>
    800044b4:	b94fc0ef          	jal	80000848 <panic>
    return -1;
    800044b8:	557d                	li	a0,-1
    800044ba:	bfe1                	j	80004492 <filewrite+0xf6>
    ret = (i == n ? n : -1);
    800044bc:	8532                	mv	a0,a2
    800044be:	bfd1                	j	80004492 <filewrite+0xf6>
    800044c0:	557d                	li	a0,-1
    800044c2:	64a6                	ld	s1,72(sp)
    800044c4:	79e2                	ld	s3,56(sp)
    800044c6:	7a42                	ld	s4,48(sp)
    800044c8:	6be2                	ld	s7,24(sp)
    800044ca:	6c42                	ld	s8,16(sp)
    800044cc:	6ca2                	ld	s9,8(sp)
    800044ce:	b7d1                	j	80004492 <filewrite+0xf6>
    return -1;
    800044d0:	557d                	li	a0,-1
}
    800044d2:	8082                	ret

00000000800044d4 <pipealloc>:
  int writeopen; // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800044d4:	7179                	addi	sp,sp,-48
    800044d6:	f406                	sd	ra,40(sp)
    800044d8:	f022                	sd	s0,32(sp)
    800044da:	ec26                	sd	s1,24(sp)
    800044dc:	e052                	sd	s4,0(sp)
    800044de:	1800                	addi	s0,sp,48
    800044e0:	84aa                	mv	s1,a0
    800044e2:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800044e4:	0005b023          	sd	zero,0(a1)
    800044e8:	00053023          	sd	zero,0(a0)
  if ((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800044ec:	c21ff0ef          	jal	8000410c <filealloc>
    800044f0:	e088                	sd	a0,0(s1)
    800044f2:	c549                	beqz	a0,8000457c <pipealloc+0xa8>
    800044f4:	c19ff0ef          	jal	8000410c <filealloc>
    800044f8:	00aa3023          	sd	a0,0(s4)
    800044fc:	cd25                	beqz	a0,80004574 <pipealloc+0xa0>
    800044fe:	e84a                	sd	s2,16(sp)
    goto bad;
  if ((pi = (struct pipe *)kalloc()) == 0)
    80004500:	e1efc0ef          	jal	80000b1e <kalloc>
    80004504:	892a                	mv	s2,a0
    80004506:	c12d                	beqz	a0,80004568 <pipealloc+0x94>
    80004508:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    8000450a:	4985                	li	s3,1
    8000450c:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80004510:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004514:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004518:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    8000451c:	00003597          	auipc	a1,0x3
    80004520:	09c58593          	addi	a1,a1,156 # 800075b8 <etext+0x5b8>
    80004524:	e54fc0ef          	jal	80000b78 <initlock>
  (*f0)->type = FD_PIPE;
    80004528:	609c                	ld	a5,0(s1)
    8000452a:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    8000452e:	609c                	ld	a5,0(s1)
    80004530:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004534:	609c                	ld	a5,0(s1)
    80004536:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    8000453a:	609c                	ld	a5,0(s1)
    8000453c:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004540:	000a3783          	ld	a5,0(s4)
    80004544:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80004548:	000a3783          	ld	a5,0(s4)
    8000454c:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004550:	000a3783          	ld	a5,0(s4)
    80004554:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80004558:	000a3783          	ld	a5,0(s4)
    8000455c:	0127b823          	sd	s2,16(a5)
  return 0;
    80004560:	4501                	li	a0,0
    80004562:	6942                	ld	s2,16(sp)
    80004564:	69a2                	ld	s3,8(sp)
    80004566:	a00d                	j	80004588 <pipealloc+0xb4>

bad:
  if (pi)
    kfree((char *)pi);
  if (*f0)
    80004568:	6088                	ld	a0,0(s1)
    8000456a:	c119                	beqz	a0,80004570 <pipealloc+0x9c>
    8000456c:	6942                	ld	s2,16(sp)
    8000456e:	a029                	j	80004578 <pipealloc+0xa4>
    80004570:	6942                	ld	s2,16(sp)
    80004572:	a029                	j	8000457c <pipealloc+0xa8>
    80004574:	6088                	ld	a0,0(s1)
    80004576:	c901                	beqz	a0,80004586 <pipealloc+0xb2>
    fileclose(*f0);
    80004578:	c39ff0ef          	jal	800041b0 <fileclose>
  if (*f1)
    8000457c:	000a3503          	ld	a0,0(s4)
    80004580:	c119                	beqz	a0,80004586 <pipealloc+0xb2>
    fileclose(*f1);
    80004582:	c2fff0ef          	jal	800041b0 <fileclose>
  return -1;
    80004586:	557d                	li	a0,-1
}
    80004588:	70a2                	ld	ra,40(sp)
    8000458a:	7402                	ld	s0,32(sp)
    8000458c:	64e2                	ld	s1,24(sp)
    8000458e:	6a02                	ld	s4,0(sp)
    80004590:	6145                	addi	sp,sp,48
    80004592:	8082                	ret

0000000080004594 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004594:	1101                	addi	sp,sp,-32
    80004596:	ec06                	sd	ra,24(sp)
    80004598:	e822                	sd	s0,16(sp)
    8000459a:	e426                	sd	s1,8(sp)
    8000459c:	e04a                	sd	s2,0(sp)
    8000459e:	1000                	addi	s0,sp,32
    800045a0:	84aa                	mv	s1,a0
    800045a2:	892e                	mv	s2,a1
  acquire(&pi->lock);
    800045a4:	e54fc0ef          	jal	80000bf8 <acquire>
  if (writable) {
    800045a8:	02090763          	beqz	s2,800045d6 <pipeclose+0x42>
    pi->writeopen = 0;
    800045ac:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    800045b0:	21848513          	addi	a0,s1,536
    800045b4:	9a3fd0ef          	jal	80001f56 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if (pi->readopen == 0 && pi->writeopen == 0) {
    800045b8:	2204a783          	lw	a5,544(s1)
    800045bc:	e781                	bnez	a5,800045c4 <pipeclose+0x30>
    800045be:	2244a783          	lw	a5,548(s1)
    800045c2:	c38d                	beqz	a5,800045e4 <pipeclose+0x50>
    release(&pi->lock);
    kfree((char *)pi);
  } else
    release(&pi->lock);
    800045c4:	8526                	mv	a0,s1
    800045c6:	eb6fc0ef          	jal	80000c7c <release>
}
    800045ca:	60e2                	ld	ra,24(sp)
    800045cc:	6442                	ld	s0,16(sp)
    800045ce:	64a2                	ld	s1,8(sp)
    800045d0:	6902                	ld	s2,0(sp)
    800045d2:	6105                	addi	sp,sp,32
    800045d4:	8082                	ret
    pi->readopen = 0;
    800045d6:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    800045da:	21c48513          	addi	a0,s1,540
    800045de:	979fd0ef          	jal	80001f56 <wakeup>
    800045e2:	bfd9                	j	800045b8 <pipeclose+0x24>
    release(&pi->lock);
    800045e4:	8526                	mv	a0,s1
    800045e6:	e96fc0ef          	jal	80000c7c <release>
    kfree((char *)pi);
    800045ea:	8526                	mv	a0,s1
    800045ec:	c4afc0ef          	jal	80000a36 <kfree>
    800045f0:	bfe9                	j	800045ca <pipeclose+0x36>

00000000800045f2 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800045f2:	7159                	addi	sp,sp,-112
    800045f4:	f486                	sd	ra,104(sp)
    800045f6:	f0a2                	sd	s0,96(sp)
    800045f8:	eca6                	sd	s1,88(sp)
    800045fa:	e8ca                	sd	s2,80(sp)
    800045fc:	e4ce                	sd	s3,72(sp)
    800045fe:	e0d2                	sd	s4,64(sp)
    80004600:	fc56                	sd	s5,56(sp)
    80004602:	1880                	addi	s0,sp,112
    80004604:	84aa                	mv	s1,a0
    80004606:	8aae                	mv	s5,a1
    80004608:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    8000460a:	ad8fd0ef          	jal	800018e2 <myproc>
    8000460e:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004610:	8526                	mv	a0,s1
    80004612:	de6fc0ef          	jal	80000bf8 <acquire>
  while (i < n) {
    80004616:	0f405a63          	blez	s4,8000470a <pipewrite+0x118>
    8000461a:	f85a                	sd	s6,48(sp)
    8000461c:	f45e                	sd	s7,40(sp)
    8000461e:	f062                	sd	s8,32(sp)
    80004620:	ec66                	sd	s9,24(sp)
    80004622:	e86a                	sd	s10,16(sp)
  int i = 0;
    80004624:	4901                	li	s2,0
      release(&pi->lock);
      sleep();
      acquire(&pi->lock);
    } else {
      char ch;
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    80004626:	f9f40c13          	addi	s8,s0,-97
    8000462a:	4b85                	li	s7,1
    8000462c:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    8000462e:	21848d13          	addi	s10,s1,536
      sleep_prepare(&pi->nwrite);
    80004632:	21c48c93          	addi	s9,s1,540
    80004636:	a0a1                	j	8000467e <pipewrite+0x8c>
      release(&pi->lock);
    80004638:	8526                	mv	a0,s1
    8000463a:	e42fc0ef          	jal	80000c7c <release>
      return -1;
    8000463e:	597d                	li	s2,-1
    80004640:	7b42                	ld	s6,48(sp)
    80004642:	7ba2                	ld	s7,40(sp)
    80004644:	7c02                	ld	s8,32(sp)
    80004646:	6ce2                	ld	s9,24(sp)
    80004648:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    8000464a:	854a                	mv	a0,s2
    8000464c:	70a6                	ld	ra,104(sp)
    8000464e:	7406                	ld	s0,96(sp)
    80004650:	64e6                	ld	s1,88(sp)
    80004652:	6946                	ld	s2,80(sp)
    80004654:	69a6                	ld	s3,72(sp)
    80004656:	6a06                	ld	s4,64(sp)
    80004658:	7ae2                	ld	s5,56(sp)
    8000465a:	6165                	addi	sp,sp,112
    8000465c:	8082                	ret
      wakeup(&pi->nread);
    8000465e:	856a                	mv	a0,s10
    80004660:	8f7fd0ef          	jal	80001f56 <wakeup>
      sleep_prepare(&pi->nwrite);
    80004664:	8566                	mv	a0,s9
    80004666:	885fd0ef          	jal	80001eea <sleep_prepare>
      release(&pi->lock);
    8000466a:	8526                	mv	a0,s1
    8000466c:	e10fc0ef          	jal	80000c7c <release>
      sleep();
    80004670:	8b7fd0ef          	jal	80001f26 <sleep>
      acquire(&pi->lock);
    80004674:	8526                	mv	a0,s1
    80004676:	d82fc0ef          	jal	80000bf8 <acquire>
  while (i < n) {
    8000467a:	07495b63          	bge	s2,s4,800046f0 <pipewrite+0xfe>
    if (pi->readopen == 0 || killed(pr)) {
    8000467e:	2204a783          	lw	a5,544(s1)
    80004682:	dbdd                	beqz	a5,80004638 <pipewrite+0x46>
    80004684:	854e                	mv	a0,s3
    80004686:	b2bfd0ef          	jal	800021b0 <killed>
    8000468a:	f55d                	bnez	a0,80004638 <pipewrite+0x46>
    if (pi->nwrite == pi->nread + PIPESIZE) { //DOC: pipewrite-full
    8000468c:	2184a783          	lw	a5,536(s1)
    80004690:	21c4a703          	lw	a4,540(s1)
    80004694:	2007879b          	addiw	a5,a5,512
    80004698:	fcf703e3          	beq	a4,a5,8000465e <pipewrite+0x6c>
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    8000469c:	875e                	mv	a4,s7
    8000469e:	015906b3          	add	a3,s2,s5
    800046a2:	8662                	mv	a2,s8
    800046a4:	0489b583          	ld	a1,72(s3)
    800046a8:	0509b503          	ld	a0,80(s3)
    800046ac:	f41fc0ef          	jal	800015ec <copyin>
    800046b0:	03650163          	beq	a0,s6,800046d2 <pipewrite+0xe0>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    800046b4:	21c4a783          	lw	a5,540(s1)
    800046b8:	0017871b          	addiw	a4,a5,1
    800046bc:	20e4ae23          	sw	a4,540(s1)
    800046c0:	1ff7f793          	andi	a5,a5,511
    800046c4:	97a6                	add	a5,a5,s1
    800046c6:	f9f44703          	lbu	a4,-97(s0)
    800046ca:	00e78c23          	sb	a4,24(a5)
      i++;
    800046ce:	2905                	addiw	s2,s2,1
    800046d0:	b76d                	j	8000467a <pipewrite+0x88>
        if (i == 0)
    800046d2:	00090863          	beqz	s2,800046e2 <pipewrite+0xf0>
    800046d6:	7b42                	ld	s6,48(sp)
    800046d8:	7ba2                	ld	s7,40(sp)
    800046da:	7c02                	ld	s8,32(sp)
    800046dc:	6ce2                	ld	s9,24(sp)
    800046de:	6d42                	ld	s10,16(sp)
    800046e0:	a829                	j	800046fa <pipewrite+0x108>
          i = -1;
    800046e2:	892a                	mv	s2,a0
        break;
    800046e4:	7b42                	ld	s6,48(sp)
    800046e6:	7ba2                	ld	s7,40(sp)
    800046e8:	7c02                	ld	s8,32(sp)
    800046ea:	6ce2                	ld	s9,24(sp)
    800046ec:	6d42                	ld	s10,16(sp)
    800046ee:	a031                	j	800046fa <pipewrite+0x108>
    800046f0:	7b42                	ld	s6,48(sp)
    800046f2:	7ba2                	ld	s7,40(sp)
    800046f4:	7c02                	ld	s8,32(sp)
    800046f6:	6ce2                	ld	s9,24(sp)
    800046f8:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    800046fa:	21848513          	addi	a0,s1,536
    800046fe:	859fd0ef          	jal	80001f56 <wakeup>
  release(&pi->lock);
    80004702:	8526                	mv	a0,s1
    80004704:	d78fc0ef          	jal	80000c7c <release>
  return i;
    80004708:	b789                	j	8000464a <pipewrite+0x58>
  int i = 0;
    8000470a:	4901                	li	s2,0
    8000470c:	b7fd                	j	800046fa <pipewrite+0x108>

000000008000470e <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    8000470e:	711d                	addi	sp,sp,-96
    80004710:	ec86                	sd	ra,88(sp)
    80004712:	e8a2                	sd	s0,80(sp)
    80004714:	e4a6                	sd	s1,72(sp)
    80004716:	e0ca                	sd	s2,64(sp)
    80004718:	fc4e                	sd	s3,56(sp)
    8000471a:	f852                	sd	s4,48(sp)
    8000471c:	f456                	sd	s5,40(sp)
    8000471e:	1080                	addi	s0,sp,96
    80004720:	84aa                	mv	s1,a0
    80004722:	89ae                	mv	s3,a1
    80004724:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80004726:	9bcfd0ef          	jal	800018e2 <myproc>
    8000472a:	892a                	mv	s2,a0
  char ch;

  acquire(&pi->lock);
    8000472c:	8526                	mv	a0,s1
    8000472e:	ccafc0ef          	jal	80000bf8 <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004732:	2184a703          	lw	a4,536(s1)
    80004736:	21c4a783          	lw	a5,540(s1)
    if (killed(pr)) {
      release(&pi->lock);
      return -1;
    }
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    8000473a:	21848a13          	addi	s4,s1,536
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    8000473e:	02f71a63          	bne	a4,a5,80004772 <piperead+0x64>
    80004742:	2244a783          	lw	a5,548(s1)
    80004746:	c795                	beqz	a5,80004772 <piperead+0x64>
    if (killed(pr)) {
    80004748:	854a                	mv	a0,s2
    8000474a:	a67fd0ef          	jal	800021b0 <killed>
    8000474e:	e149                	bnez	a0,800047d0 <piperead+0xc2>
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    80004750:	8552                	mv	a0,s4
    80004752:	f98fd0ef          	jal	80001eea <sleep_prepare>
    release(&pi->lock);
    80004756:	8526                	mv	a0,s1
    80004758:	d24fc0ef          	jal	80000c7c <release>
    sleep();
    8000475c:	fcafd0ef          	jal	80001f26 <sleep>
    acquire(&pi->lock);
    80004760:	8526                	mv	a0,s1
    80004762:	c96fc0ef          	jal	80000bf8 <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004766:	2184a703          	lw	a4,536(s1)
    8000476a:	21c4a783          	lw	a5,540(s1)
    8000476e:	fcf70ae3          	beq	a4,a5,80004742 <piperead+0x34>
  }
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    80004772:	07505a63          	blez	s5,800047e6 <piperead+0xd8>
    80004776:	f05a                	sd	s6,32(sp)
    80004778:	ec5e                	sd	s7,24(sp)
    8000477a:	e862                	sd	s8,16(sp)
    8000477c:	4a01                	li	s4,0
    if (pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    8000477e:	faf40c13          	addi	s8,s0,-81
    80004782:	4b85                	li	s7,1
    80004784:	5b7d                	li	s6,-1
    if (pi->nread == pi->nwrite)
    80004786:	2184a783          	lw	a5,536(s1)
    8000478a:	21c4a703          	lw	a4,540(s1)
    8000478e:	06f70363          	beq	a4,a5,800047f4 <piperead+0xe6>
    ch = pi->data[pi->nread % PIPESIZE];
    80004792:	1ff7f793          	andi	a5,a5,511
    80004796:	97a6                	add	a5,a5,s1
    80004798:	0187c783          	lbu	a5,24(a5)
    8000479c:	faf407a3          	sb	a5,-81(s0)
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    800047a0:	875e                	mv	a4,s7
    800047a2:	86e2                	mv	a3,s8
    800047a4:	864e                	mv	a2,s3
    800047a6:	04893583          	ld	a1,72(s2)
    800047aa:	05093503          	ld	a0,80(s2)
    800047ae:	d7ffc0ef          	jal	8000152c <copyout>
    800047b2:	03650463          	beq	a0,s6,800047da <piperead+0xcc>
      if (i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    800047b6:	2184a783          	lw	a5,536(s1)
    800047ba:	2785                	addiw	a5,a5,1
    800047bc:	20f4ac23          	sw	a5,536(s1)
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    800047c0:	2a05                	addiw	s4,s4,1
    800047c2:	0985                	addi	s3,s3,1
    800047c4:	fd4a91e3          	bne	s5,s4,80004786 <piperead+0x78>
    800047c8:	7b02                	ld	s6,32(sp)
    800047ca:	6be2                	ld	s7,24(sp)
    800047cc:	6c42                	ld	s8,16(sp)
    800047ce:	a035                	j	800047fa <piperead+0xec>
      release(&pi->lock);
    800047d0:	8526                	mv	a0,s1
    800047d2:	caafc0ef          	jal	80000c7c <release>
      return -1;
    800047d6:	5a7d                	li	s4,-1
    800047d8:	a805                	j	80004808 <piperead+0xfa>
      if (i == 0)
    800047da:	000a0863          	beqz	s4,800047ea <piperead+0xdc>
    800047de:	7b02                	ld	s6,32(sp)
    800047e0:	6be2                	ld	s7,24(sp)
    800047e2:	6c42                	ld	s8,16(sp)
    800047e4:	a819                	j	800047fa <piperead+0xec>
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    800047e6:	4a01                	li	s4,0
    800047e8:	a809                	j	800047fa <piperead+0xec>
        i = -1;
    800047ea:	8a2a                	mv	s4,a0
    800047ec:	7b02                	ld	s6,32(sp)
    800047ee:	6be2                	ld	s7,24(sp)
    800047f0:	6c42                	ld	s8,16(sp)
    800047f2:	a021                	j	800047fa <piperead+0xec>
    800047f4:	7b02                	ld	s6,32(sp)
    800047f6:	6be2                	ld	s7,24(sp)
    800047f8:	6c42                	ld	s8,16(sp)
  }
  wakeup(&pi->nwrite); //DOC: piperead-wakeup
    800047fa:	21c48513          	addi	a0,s1,540
    800047fe:	f58fd0ef          	jal	80001f56 <wakeup>
  release(&pi->lock);
    80004802:	8526                	mv	a0,s1
    80004804:	c78fc0ef          	jal	80000c7c <release>
  return i;
}
    80004808:	8552                	mv	a0,s4
    8000480a:	60e6                	ld	ra,88(sp)
    8000480c:	6446                	ld	s0,80(sp)
    8000480e:	64a6                	ld	s1,72(sp)
    80004810:	6906                	ld	s2,64(sp)
    80004812:	79e2                	ld	s3,56(sp)
    80004814:	7a42                	ld	s4,48(sp)
    80004816:	7aa2                	ld	s5,40(sp)
    80004818:	6125                	addi	sp,sp,96
    8000481a:	8082                	ret

000000008000481c <flags2perm>:
static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int
flags2perm(int flags)
{
    8000481c:	1141                	addi	sp,sp,-16
    8000481e:	e406                	sd	ra,8(sp)
    80004820:	e022                	sd	s0,0(sp)
    80004822:	0800                	addi	s0,sp,16
    80004824:	87aa                	mv	a5,a0
  int perm = 0;
  if (flags & 0x1)
    80004826:	0035151b          	slliw	a0,a0,0x3
    8000482a:	8921                	andi	a0,a0,8
    perm = PTE_X;
  if (flags & 0x2)
    8000482c:	8b89                	andi	a5,a5,2
    8000482e:	c399                	beqz	a5,80004834 <flags2perm+0x18>
    perm |= PTE_W;
    80004830:	00456513          	ori	a0,a0,4
  return perm;
}
    80004834:	60a2                	ld	ra,8(sp)
    80004836:	6402                	ld	s0,0(sp)
    80004838:	0141                	addi	sp,sp,16
    8000483a:	8082                	ret

000000008000483c <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    8000483c:	df010113          	addi	sp,sp,-528
    80004840:	20113423          	sd	ra,520(sp)
    80004844:	20813023          	sd	s0,512(sp)
    80004848:	ffa6                	sd	s1,504(sp)
    8000484a:	fbca                	sd	s2,496(sp)
    8000484c:	0c00                	addi	s0,sp,528
    8000484e:	892a                	mv	s2,a0
    80004850:	e0a43023          	sd	a0,-512(s0)
    80004854:	deb43c23          	sd	a1,-520(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004858:	88afd0ef          	jal	800018e2 <myproc>
    8000485c:	84aa                	mv	s1,a0

  begin_op();
    8000485e:	c9cff0ef          	jal	80003cfa <begin_op>

  // Open the executable file.
  if ((ip = namei(path)) == 0) {
    80004862:	854a                	mv	a0,s2
    80004864:	ab8ff0ef          	jal	80003b1c <namei>
    80004868:	c931                	beqz	a0,800048bc <kexec+0x80>
    8000486a:	f3d2                	sd	s4,480(sp)
    8000486c:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    8000486e:	a1bfe0ef          	jal	80003288 <ilock>

  // Read the ELF header.
  if (readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004872:	04000713          	li	a4,64
    80004876:	4681                	li	a3,0
    80004878:	e5040613          	addi	a2,s0,-432
    8000487c:	4581                	li	a1,0
    8000487e:	8552                	mv	a0,s4
    80004880:	de3fe0ef          	jal	80003662 <readi>
    80004884:	04000793          	li	a5,64
    80004888:	00f51a63          	bne	a0,a5,8000489c <kexec+0x60>
    goto bad;

  // Is this really an ELF file?
  if (elf.magic != ELF_MAGIC)
    8000488c:	e5042703          	lw	a4,-432(s0)
    80004890:	464c47b7          	lui	a5,0x464c4
    80004894:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004898:	02f70563          	beq	a4,a5,800048c2 <kexec+0x86>

bad:
  if (pagetable)
    proc_freepagetable(pagetable, sz);
  if (ip) {
    iunlockput(ip);
    8000489c:	8552                	mv	a0,s4
    8000489e:	c3ffe0ef          	jal	800034dc <iunlockput>
    end_op();
    800048a2:	ce4ff0ef          	jal	80003d86 <end_op>
    800048a6:	7a1e                	ld	s4,480(sp)
    return -1;
    800048a8:	557d                	li	a0,-1
  }
  return -1;
}
    800048aa:	20813083          	ld	ra,520(sp)
    800048ae:	20013403          	ld	s0,512(sp)
    800048b2:	74fe                	ld	s1,504(sp)
    800048b4:	795e                	ld	s2,496(sp)
    800048b6:	21010113          	addi	sp,sp,528
    800048ba:	8082                	ret
    end_op();
    800048bc:	ccaff0ef          	jal	80003d86 <end_op>
    return -1;
    800048c0:	b7e5                	j	800048a8 <kexec+0x6c>
    800048c2:	ebda                	sd	s6,464(sp)
  if ((pagetable = proc_pagetable(p)) == 0)
    800048c4:	8526                	mv	a0,s1
    800048c6:	932fd0ef          	jal	800019f8 <proc_pagetable>
    800048ca:	8b2a                	mv	s6,a0
    800048cc:	26050263          	beqz	a0,80004b30 <kexec+0x2f4>
    800048d0:	f7ce                	sd	s3,488(sp)
    800048d2:	efd6                	sd	s5,472(sp)
    800048d4:	e7de                	sd	s7,456(sp)
    800048d6:	e3e2                	sd	s8,448(sp)
    800048d8:	ff66                	sd	s9,440(sp)
    800048da:	fb6a                	sd	s10,432(sp)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    800048dc:	e8845783          	lhu	a5,-376(s0)
    800048e0:	12078763          	beqz	a5,80004a0e <kexec+0x1d2>
    800048e4:	f76e                	sd	s11,424(sp)
    800048e6:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    800048ea:	4901                	li	s2,0
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    800048ec:	4d01                	li	s10,0
    if (readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    800048ee:	03800d93          	li	s11,56

  for (i = 0; i < sz; i += PGSIZE) {
    pa = walkaddr(pagetable, va + i);
    if (pa == 0)
      panic("loadseg: address should exist");
    if (sz - i < PGSIZE)
    800048f2:	6c85                	lui	s9,0x1
    800048f4:	6a85                	lui	s5,0x1
    800048f6:	a085                	j	80004956 <kexec+0x11a>
      panic("loadseg: address should exist");
    800048f8:	00003517          	auipc	a0,0x3
    800048fc:	cc850513          	addi	a0,a0,-824 # 800075c0 <etext+0x5c0>
    80004900:	f49fb0ef          	jal	80000848 <panic>
    if (sz - i < PGSIZE)
    80004904:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if (readi(ip, 0, (uint64)pa, offset + i, n) != n)
    80004906:	874a                	mv	a4,s2
    80004908:	009b86bb          	addw	a3,s7,s1
    8000490c:	4581                	li	a1,0
    8000490e:	8552                	mv	a0,s4
    80004910:	d53fe0ef          	jal	80003662 <readi>
    80004914:	22a91263          	bne	s2,a0,80004b38 <kexec+0x2fc>
  for (i = 0; i < sz; i += PGSIZE) {
    80004918:	009a84bb          	addw	s1,s5,s1
    8000491c:	0334f263          	bgeu	s1,s3,80004940 <kexec+0x104>
    pa = walkaddr(pagetable, va + i);
    80004920:	02049593          	slli	a1,s1,0x20
    80004924:	9181                	srli	a1,a1,0x20
    80004926:	95e2                	add	a1,a1,s8
    80004928:	855a                	mv	a0,s6
    8000492a:	eaefc0ef          	jal	80000fd8 <walkaddr>
    8000492e:	862a                	mv	a2,a0
    if (pa == 0)
    80004930:	d561                	beqz	a0,800048f8 <kexec+0xbc>
    if (sz - i < PGSIZE)
    80004932:	409987bb          	subw	a5,s3,s1
    80004936:	893e                	mv	s2,a5
    80004938:	fcfcf6e3          	bgeu	s9,a5,80004904 <kexec+0xc8>
    8000493c:	8956                	mv	s2,s5
    8000493e:	b7d9                	j	80004904 <kexec+0xc8>
    sz = sz1;
    80004940:	df043903          	ld	s2,-528(s0)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004944:	2d05                	addiw	s10,s10,1
    80004946:	e0843783          	ld	a5,-504(s0)
    8000494a:	0387869b          	addiw	a3,a5,56
    8000494e:	e8845783          	lhu	a5,-376(s0)
    80004952:	06fd5863          	bge	s10,a5,800049c2 <kexec+0x186>
    if (readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004956:	e0d43423          	sd	a3,-504(s0)
    8000495a:	876e                	mv	a4,s11
    8000495c:	e1840613          	addi	a2,s0,-488
    80004960:	4581                	li	a1,0
    80004962:	8552                	mv	a0,s4
    80004964:	cfffe0ef          	jal	80003662 <readi>
    80004968:	1db51663          	bne	a0,s11,80004b34 <kexec+0x2f8>
    if (ph.type != ELF_PROG_LOAD)
    8000496c:	e1842783          	lw	a5,-488(s0)
    80004970:	4705                	li	a4,1
    80004972:	fce799e3          	bne	a5,a4,80004944 <kexec+0x108>
    if (ph.memsz < ph.filesz)
    80004976:	e4043483          	ld	s1,-448(s0)
    8000497a:	e3843783          	ld	a5,-456(s0)
    8000497e:	1af4eb63          	bltu	s1,a5,80004b34 <kexec+0x2f8>
    if (ph.vaddr + ph.memsz < ph.vaddr)
    80004982:	e2843783          	ld	a5,-472(s0)
    80004986:	94be                	add	s1,s1,a5
    80004988:	1af4e663          	bltu	s1,a5,80004b34 <kexec+0x2f8>
    if (ph.vaddr % PGSIZE != 0)
    8000498c:	17d2                	slli	a5,a5,0x34
    8000498e:	1a079363          	bnez	a5,80004b34 <kexec+0x2f8>
    if ((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz,
    80004992:	e1c42503          	lw	a0,-484(s0)
    80004996:	e87ff0ef          	jal	8000481c <flags2perm>
    8000499a:	86aa                	mv	a3,a0
    8000499c:	8626                	mv	a2,s1
    8000499e:	85ca                	mv	a1,s2
    800049a0:	855a                	mv	a0,s6
    800049a2:	905fc0ef          	jal	800012a6 <uvmalloc>
    800049a6:	dea43823          	sd	a0,-528(s0)
    800049aa:	18050563          	beqz	a0,80004b34 <kexec+0x2f8>
    if (loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    800049ae:	e3842983          	lw	s3,-456(s0)
  for (i = 0; i < sz; i += PGSIZE) {
    800049b2:	f80987e3          	beqz	s3,80004940 <kexec+0x104>
    if (loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    800049b6:	e2843c03          	ld	s8,-472(s0)
    800049ba:	e2042b83          	lw	s7,-480(s0)
  for (i = 0; i < sz; i += PGSIZE) {
    800049be:	4481                	li	s1,0
    800049c0:	b785                	j	80004920 <kexec+0xe4>
    800049c2:	7dba                	ld	s11,424(sp)
  iunlockput(ip);
    800049c4:	8552                	mv	a0,s4
    800049c6:	b17fe0ef          	jal	800034dc <iunlockput>
  end_op();
    800049ca:	bbcff0ef          	jal	80003d86 <end_op>
  p = myproc();
    800049ce:	f15fc0ef          	jal	800018e2 <myproc>
    800049d2:	89aa                	mv	s3,a0
  uint64 oldsz = p->sz;
    800049d4:	04853a03          	ld	s4,72(a0)
  sz = PGROUNDUP(sz);
    800049d8:	6485                	lui	s1,0x1
    800049da:	14fd                	addi	s1,s1,-1 # fff <_entry-0x7ffff001>
    800049dc:	94ca                	add	s1,s1,s2
    800049de:	77fd                	lui	a5,0xfffff
    800049e0:	8cfd                	and	s1,s1,a5
  if ((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK + 1) * PGSIZE, PTE_W)) ==
    800049e2:	4691                	li	a3,4
    800049e4:	6609                	lui	a2,0x2
    800049e6:	9626                	add	a2,a2,s1
    800049e8:	85a6                	mv	a1,s1
    800049ea:	855a                	mv	a0,s6
    800049ec:	8bbfc0ef          	jal	800012a6 <uvmalloc>
    800049f0:	8aaa                	mv	s5,a0
    800049f2:	e105                	bnez	a0,80004a12 <kexec+0x1d6>
    proc_freepagetable(pagetable, sz);
    800049f4:	85a6                	mv	a1,s1
    800049f6:	855a                	mv	a0,s6
    800049f8:	882fd0ef          	jal	80001a7a <proc_freepagetable>
  if (ip) {
    800049fc:	79be                	ld	s3,488(sp)
    800049fe:	7a1e                	ld	s4,480(sp)
    80004a00:	6afe                	ld	s5,472(sp)
    80004a02:	6b5e                	ld	s6,464(sp)
    80004a04:	6bbe                	ld	s7,456(sp)
    80004a06:	6c1e                	ld	s8,448(sp)
    80004a08:	7cfa                	ld	s9,440(sp)
    80004a0a:	7d5a                	ld	s10,432(sp)
    80004a0c:	bd71                	j	800048a8 <kexec+0x6c>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004a0e:	4901                	li	s2,0
    80004a10:	bf55                	j	800049c4 <kexec+0x188>
  uvmclear(pagetable, sz - (USERSTACK + 1) * PGSIZE);
    80004a12:	75f9                	lui	a1,0xffffe
    80004a14:	95aa                	add	a1,a1,a0
    80004a16:	855a                	mv	a0,s6
    80004a18:	a57fc0ef          	jal	8000146e <uvmclear>
  stackbase = sp - USERSTACK * PGSIZE;
    80004a1c:	7bfd                	lui	s7,0xfffff
    80004a1e:	9bd6                	add	s7,s7,s5
  for (argc = 0; argv[argc]; argc++) {
    80004a20:	df843783          	ld	a5,-520(s0)
    80004a24:	6388                	ld	a0,0(a5)
    80004a26:	cd3d                	beqz	a0,80004aa4 <kexec+0x268>
  sp = sz;
    80004a28:	8c56                	mv	s8,s5
  for (argc = 0; argv[argc]; argc++) {
    80004a2a:	4481                	li	s1,0
    ustack[argc] = sp;
    80004a2c:	e9040913          	addi	s2,s0,-368
    sp -= strlen(argv[argc]) + 1;
    80004a30:	c04fc0ef          	jal	80000e34 <strlen>
    80004a34:	0015079b          	addiw	a5,a0,1
    80004a38:	40fc07b3          	sub	a5,s8,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004a3c:	ff07fc13          	andi	s8,a5,-16
    if (sp < stackbase)
    80004a40:	077c6063          	bltu	s8,s7,80004aa0 <kexec+0x264>
    if (copyout(pagetable, sz, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004a44:	df843d03          	ld	s10,-520(s0)
    80004a48:	000d3c83          	ld	s9,0(s10)
    80004a4c:	8566                	mv	a0,s9
    80004a4e:	be6fc0ef          	jal	80000e34 <strlen>
    80004a52:	0015071b          	addiw	a4,a0,1
    80004a56:	86e6                	mv	a3,s9
    80004a58:	8662                	mv	a2,s8
    80004a5a:	85d6                	mv	a1,s5
    80004a5c:	855a                	mv	a0,s6
    80004a5e:	acffc0ef          	jal	8000152c <copyout>
    80004a62:	02054f63          	bltz	a0,80004aa0 <kexec+0x264>
    ustack[argc] = sp;
    80004a66:	00349793          	slli	a5,s1,0x3
    80004a6a:	97ca                	add	a5,a5,s2
    80004a6c:	0187b023          	sd	s8,0(a5) # fffffffffffff000 <end+0xffffffff7ffdb9d0>
  for (argc = 0; argv[argc]; argc++) {
    80004a70:	0485                	addi	s1,s1,1
    80004a72:	008d0793          	addi	a5,s10,8
    80004a76:	def43c23          	sd	a5,-520(s0)
    80004a7a:	008d3503          	ld	a0,8(s10)
    80004a7e:	f94d                	bnez	a0,80004a30 <kexec+0x1f4>
  ustack[argc] = 0;
    80004a80:	00349793          	slli	a5,s1,0x3
    80004a84:	f9040713          	addi	a4,s0,-112
    80004a88:	97ba                	add	a5,a5,a4
    80004a8a:	f007b023          	sd	zero,-256(a5)
  sp -= (argc + 1) * sizeof(uint64);
    80004a8e:	00148713          	addi	a4,s1,1
    80004a92:	070e                	slli	a4,a4,0x3
    80004a94:	40ec0933          	sub	s2,s8,a4
  sp -= sp % 16;
    80004a98:	ff097913          	andi	s2,s2,-16
  if (sp < stackbase)
    80004a9c:	01797763          	bgeu	s2,s7,80004aaa <kexec+0x26e>
  sz = sz1;
    80004aa0:	84d6                	mv	s1,s5
    80004aa2:	bf89                	j	800049f4 <kexec+0x1b8>
  sp = sz;
    80004aa4:	8c56                	mv	s8,s5
  for (argc = 0; argv[argc]; argc++) {
    80004aa6:	4481                	li	s1,0
    80004aa8:	bfe1                	j	80004a80 <kexec+0x244>
  if (copyout(pagetable, sz, sp, (char *)ustack, (argc + 1) * sizeof(uint64)) <
    80004aaa:	e9040693          	addi	a3,s0,-368
    80004aae:	864a                	mv	a2,s2
    80004ab0:	85d6                	mv	a1,s5
    80004ab2:	855a                	mv	a0,s6
    80004ab4:	a79fc0ef          	jal	8000152c <copyout>
    80004ab8:	fe0544e3          	bltz	a0,80004aa0 <kexec+0x264>
  p->trapframe->a1 = sp;
    80004abc:	0589b783          	ld	a5,88(s3)
    80004ac0:	0727bc23          	sd	s2,120(a5)
  for (last = s = path; *s; s++)
    80004ac4:	e0043783          	ld	a5,-512(s0)
    80004ac8:	0007c703          	lbu	a4,0(a5)
    80004acc:	cf11                	beqz	a4,80004ae8 <kexec+0x2ac>
    80004ace:	0785                	addi	a5,a5,1
    if (*s == '/')
    80004ad0:	02f00693          	li	a3,47
    80004ad4:	a029                	j	80004ade <kexec+0x2a2>
  for (last = s = path; *s; s++)
    80004ad6:	0785                	addi	a5,a5,1
    80004ad8:	fff7c703          	lbu	a4,-1(a5)
    80004adc:	c711                	beqz	a4,80004ae8 <kexec+0x2ac>
    if (*s == '/')
    80004ade:	fed71ce3          	bne	a4,a3,80004ad6 <kexec+0x29a>
      last = s + 1;
    80004ae2:	e0f43023          	sd	a5,-512(s0)
    80004ae6:	bfc5                	j	80004ad6 <kexec+0x29a>
  safestrcpy(p->name, last, sizeof(p->name));
    80004ae8:	4641                	li	a2,16
    80004aea:	e0043583          	ld	a1,-512(s0)
    80004aee:	15898513          	addi	a0,s3,344
    80004af2:	b0cfc0ef          	jal	80000dfe <safestrcpy>
  oldpagetable = p->pagetable;
    80004af6:	0509b503          	ld	a0,80(s3)
  p->pagetable = pagetable;
    80004afa:	0569b823          	sd	s6,80(s3)
  p->sz = sz;
    80004afe:	0559b423          	sd	s5,72(s3)
  p->trapframe->epc = elf.entry; // initial program counter = ulib.c:start()
    80004b02:	0589b783          	ld	a5,88(s3)
    80004b06:	e6843703          	ld	a4,-408(s0)
    80004b0a:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp;         // initial stack pointer
    80004b0c:	0589b783          	ld	a5,88(s3)
    80004b10:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004b14:	85d2                	mv	a1,s4
    80004b16:	f65fc0ef          	jal	80001a7a <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004b1a:	0004851b          	sext.w	a0,s1
    80004b1e:	79be                	ld	s3,488(sp)
    80004b20:	7a1e                	ld	s4,480(sp)
    80004b22:	6afe                	ld	s5,472(sp)
    80004b24:	6b5e                	ld	s6,464(sp)
    80004b26:	6bbe                	ld	s7,456(sp)
    80004b28:	6c1e                	ld	s8,448(sp)
    80004b2a:	7cfa                	ld	s9,440(sp)
    80004b2c:	7d5a                	ld	s10,432(sp)
    80004b2e:	bbb5                	j	800048aa <kexec+0x6e>
    80004b30:	6b5e                	ld	s6,464(sp)
    80004b32:	b3ad                	j	8000489c <kexec+0x60>
    return -1;
    80004b34:	df243823          	sd	s2,-528(s0)
    proc_freepagetable(pagetable, sz);
    80004b38:	df043583          	ld	a1,-528(s0)
    80004b3c:	855a                	mv	a0,s6
    80004b3e:	f3dfc0ef          	jal	80001a7a <proc_freepagetable>
  if (ip) {
    80004b42:	79be                	ld	s3,488(sp)
    80004b44:	6afe                	ld	s5,472(sp)
    80004b46:	6b5e                	ld	s6,464(sp)
    80004b48:	6bbe                	ld	s7,456(sp)
    80004b4a:	6c1e                	ld	s8,448(sp)
    80004b4c:	7cfa                	ld	s9,440(sp)
    80004b4e:	7d5a                	ld	s10,432(sp)
    80004b50:	7dba                	ld	s11,424(sp)
    80004b52:	b3a9                	j	8000489c <kexec+0x60>

0000000080004b54 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004b54:	7179                	addi	sp,sp,-48
    80004b56:	f406                	sd	ra,40(sp)
    80004b58:	f022                	sd	s0,32(sp)
    80004b5a:	ec26                	sd	s1,24(sp)
    80004b5c:	e84a                	sd	s2,16(sp)
    80004b5e:	1800                	addi	s0,sp,48
    80004b60:	892e                	mv	s2,a1
    80004b62:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004b64:	fdc40593          	addi	a1,s0,-36
    80004b68:	d17fd0ef          	jal	8000287e <argint>
  if (fd < 0 || fd >= NOFILE || (f = myproc()->ofile[fd]) == 0)
    80004b6c:	fdc42703          	lw	a4,-36(s0)
    80004b70:	47bd                	li	a5,15
    80004b72:	02e7e963          	bltu	a5,a4,80004ba4 <argfd+0x50>
    80004b76:	d6dfc0ef          	jal	800018e2 <myproc>
    80004b7a:	fdc42703          	lw	a4,-36(s0)
    80004b7e:	01a70793          	addi	a5,a4,26
    80004b82:	078e                	slli	a5,a5,0x3
    80004b84:	953e                	add	a0,a0,a5
    80004b86:	611c                	ld	a5,0(a0)
    80004b88:	cf91                	beqz	a5,80004ba4 <argfd+0x50>
    return -1;
  if (pfd)
    80004b8a:	00090463          	beqz	s2,80004b92 <argfd+0x3e>
    *pfd = fd;
    80004b8e:	00e92023          	sw	a4,0(s2)
  if (pf)
    80004b92:	c091                	beqz	s1,80004b96 <argfd+0x42>
    *pf = f;
    80004b94:	e09c                	sd	a5,0(s1)
  return 0;
    80004b96:	4501                	li	a0,0
}
    80004b98:	70a2                	ld	ra,40(sp)
    80004b9a:	7402                	ld	s0,32(sp)
    80004b9c:	64e2                	ld	s1,24(sp)
    80004b9e:	6942                	ld	s2,16(sp)
    80004ba0:	6145                	addi	sp,sp,48
    80004ba2:	8082                	ret
    return -1;
    80004ba4:	557d                	li	a0,-1
    80004ba6:	bfcd                	j	80004b98 <argfd+0x44>

0000000080004ba8 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004ba8:	1101                	addi	sp,sp,-32
    80004baa:	ec06                	sd	ra,24(sp)
    80004bac:	e822                	sd	s0,16(sp)
    80004bae:	e426                	sd	s1,8(sp)
    80004bb0:	1000                	addi	s0,sp,32
    80004bb2:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004bb4:	d2ffc0ef          	jal	800018e2 <myproc>
    80004bb8:	862a                	mv	a2,a0

  for (fd = 0; fd < NOFILE; fd++) {
    80004bba:	0d050793          	addi	a5,a0,208
    80004bbe:	4501                	li	a0,0
    80004bc0:	46c1                	li	a3,16
    if (p->ofile[fd] == 0) {
    80004bc2:	6398                	ld	a4,0(a5)
    80004bc4:	cb19                	beqz	a4,80004bda <fdalloc+0x32>
  for (fd = 0; fd < NOFILE; fd++) {
    80004bc6:	2505                	addiw	a0,a0,1
    80004bc8:	07a1                	addi	a5,a5,8
    80004bca:	fed51ce3          	bne	a0,a3,80004bc2 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004bce:	557d                	li	a0,-1
}
    80004bd0:	60e2                	ld	ra,24(sp)
    80004bd2:	6442                	ld	s0,16(sp)
    80004bd4:	64a2                	ld	s1,8(sp)
    80004bd6:	6105                	addi	sp,sp,32
    80004bd8:	8082                	ret
      p->ofile[fd] = f;
    80004bda:	01a50793          	addi	a5,a0,26
    80004bde:	078e                	slli	a5,a5,0x3
    80004be0:	963e                	add	a2,a2,a5
    80004be2:	e204                	sd	s1,0(a2)
      return fd;
    80004be4:	b7f5                	j	80004bd0 <fdalloc+0x28>

0000000080004be6 <create>:
  return -1;
}

static struct inode *
create(char *path, short type, short major, short minor)
{
    80004be6:	715d                	addi	sp,sp,-80
    80004be8:	e486                	sd	ra,72(sp)
    80004bea:	e0a2                	sd	s0,64(sp)
    80004bec:	fc26                	sd	s1,56(sp)
    80004bee:	f84a                	sd	s2,48(sp)
    80004bf0:	f44e                	sd	s3,40(sp)
    80004bf2:	ec56                	sd	s5,24(sp)
    80004bf4:	e85a                	sd	s6,16(sp)
    80004bf6:	0880                	addi	s0,sp,80
    80004bf8:	89ae                	mv	s3,a1
    80004bfa:	8ab2                	mv	s5,a2
    80004bfc:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if ((dp = nameiparent(path, name)) == 0)
    80004bfe:	fb040593          	addi	a1,s0,-80
    80004c02:	f35fe0ef          	jal	80003b36 <nameiparent>
    80004c06:	84aa                	mv	s1,a0
    return 0;
    80004c08:	892a                	mv	s2,a0
  if ((dp = nameiparent(path, name)) == 0)
    80004c0a:	cd31                	beqz	a0,80004c66 <create+0x80>

  ilock(dp);
    80004c0c:	e7cfe0ef          	jal	80003288 <ilock>

  if (dp->nlink == 0) {
    80004c10:	04a49783          	lh	a5,74(s1)
    80004c14:	c3bd                	beqz	a5,80004c7a <create+0x94>
    iunlockput(dp);
    return 0;
  }

  // a new directory's ".." would push dp->nlink past its maximum
  if (type == T_DIR && dp->nlink >= NLINK_MAX) {
    80004c16:	7761                	lui	a4,0xffff8
    80004c18:	0705                	addi	a4,a4,1 # ffffffffffff8001 <end+0xffffffff7ffd49d1>
    80004c1a:	97ba                	add	a5,a5,a4
    80004c1c:	0017b793          	seqz	a5,a5
    80004c20:	fff98713          	addi	a4,s3,-1
    80004c24:	00173713          	seqz	a4,a4
    80004c28:	8ff9                	and	a5,a5,a4
    80004c2a:	efa1                	bnez	a5,80004c82 <create+0x9c>
    iunlockput(dp);
    return 0;
  }

  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80004c2c:	4601                	li	a2,0
    80004c2e:	fb040593          	addi	a1,s0,-80
    80004c32:	8526                	mv	a0,s1
    80004c34:	c3ffe0ef          	jal	80003872 <dirlookup>
    80004c38:	892a                	mv	s2,a0
    80004c3a:	c921                	beqz	a0,80004c8a <create+0xa4>
    iunlockput(dp);
    80004c3c:	8526                	mv	a0,s1
    80004c3e:	89ffe0ef          	jal	800034dc <iunlockput>
    ilock(ip);
    80004c42:	854a                	mv	a0,s2
    80004c44:	e44fe0ef          	jal	80003288 <ilock>
    if (type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004c48:	4789                	li	a5,2
    80004c4a:	00f99a63          	bne	s3,a5,80004c5e <create+0x78>
    80004c4e:	04495783          	lhu	a5,68(s2)
    80004c52:	37f9                	addiw	a5,a5,-2
    80004c54:	17c2                	slli	a5,a5,0x30
    80004c56:	93c1                	srli	a5,a5,0x30
    80004c58:	4705                	li	a4,1
    80004c5a:	00f77663          	bgeu	a4,a5,80004c66 <create+0x80>
      return ip;
    iunlockput(ip);
    80004c5e:	854a                	mv	a0,s2
    80004c60:	87dfe0ef          	jal	800034dc <iunlockput>
    return 0;
    80004c64:	4901                	li	s2,0
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004c66:	854a                	mv	a0,s2
    80004c68:	60a6                	ld	ra,72(sp)
    80004c6a:	6406                	ld	s0,64(sp)
    80004c6c:	74e2                	ld	s1,56(sp)
    80004c6e:	7942                	ld	s2,48(sp)
    80004c70:	79a2                	ld	s3,40(sp)
    80004c72:	6ae2                	ld	s5,24(sp)
    80004c74:	6b42                	ld	s6,16(sp)
    80004c76:	6161                	addi	sp,sp,80
    80004c78:	8082                	ret
    iunlockput(dp);
    80004c7a:	8526                	mv	a0,s1
    80004c7c:	861fe0ef          	jal	800034dc <iunlockput>
    return 0;
    80004c80:	b7d5                	j	80004c64 <create+0x7e>
    iunlockput(dp);
    80004c82:	8526                	mv	a0,s1
    80004c84:	859fe0ef          	jal	800034dc <iunlockput>
    return 0;
    80004c88:	bff1                	j	80004c64 <create+0x7e>
    80004c8a:	f052                	sd	s4,32(sp)
  if ((ip = ialloc(dp->dev, type)) == 0) {
    80004c8c:	85ce                	mv	a1,s3
    80004c8e:	4088                	lw	a0,0(s1)
    80004c90:	c88fe0ef          	jal	80003118 <ialloc>
    80004c94:	8a2a                	mv	s4,a0
    80004c96:	cd1d                	beqz	a0,80004cd4 <create+0xee>
  ilock(ip);
    80004c98:	df0fe0ef          	jal	80003288 <ilock>
  ip->major = major;
    80004c9c:	055a1323          	sh	s5,70(s4)
  ip->minor = minor;
    80004ca0:	056a1423          	sh	s6,72(s4)
  ip->nlink = 1;
    80004ca4:	4705                	li	a4,1
    80004ca6:	04ea1523          	sh	a4,74(s4)
  iupdate(ip);
    80004caa:	8552                	mv	a0,s4
    80004cac:	d28fe0ef          	jal	800031d4 <iupdate>
  if (type == T_DIR) { // Create . and .. entries.
    80004cb0:	4785                	li	a5,1
    80004cb2:	02f98563          	beq	s3,a5,80004cdc <create+0xf6>
  if (dirlink(dp, name, ip->inum) < 0)
    80004cb6:	004a2603          	lw	a2,4(s4)
    80004cba:	fb040593          	addi	a1,s0,-80
    80004cbe:	8526                	mv	a0,s1
    80004cc0:	db3fe0ef          	jal	80003a72 <dirlink>
    80004cc4:	06054363          	bltz	a0,80004d2a <create+0x144>
  iunlockput(dp);
    80004cc8:	8526                	mv	a0,s1
    80004cca:	813fe0ef          	jal	800034dc <iunlockput>
    return 0;
    80004cce:	8952                	mv	s2,s4
    80004cd0:	7a02                	ld	s4,32(sp)
    80004cd2:	bf51                	j	80004c66 <create+0x80>
    iunlockput(dp);
    80004cd4:	8526                	mv	a0,s1
    80004cd6:	807fe0ef          	jal	800034dc <iunlockput>
    return 0;
    80004cda:	bfd5                	j	80004cce <create+0xe8>
    if (dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004cdc:	004a2603          	lw	a2,4(s4)
    80004ce0:	00003597          	auipc	a1,0x3
    80004ce4:	90058593          	addi	a1,a1,-1792 # 800075e0 <etext+0x5e0>
    80004ce8:	8552                	mv	a0,s4
    80004cea:	d89fe0ef          	jal	80003a72 <dirlink>
    80004cee:	02054e63          	bltz	a0,80004d2a <create+0x144>
    80004cf2:	40d0                	lw	a2,4(s1)
    80004cf4:	00003597          	auipc	a1,0x3
    80004cf8:	8f458593          	addi	a1,a1,-1804 # 800075e8 <etext+0x5e8>
    80004cfc:	8552                	mv	a0,s4
    80004cfe:	d75fe0ef          	jal	80003a72 <dirlink>
    80004d02:	02054463          	bltz	a0,80004d2a <create+0x144>
  if (dirlink(dp, name, ip->inum) < 0)
    80004d06:	004a2603          	lw	a2,4(s4)
    80004d0a:	fb040593          	addi	a1,s0,-80
    80004d0e:	8526                	mv	a0,s1
    80004d10:	d63fe0ef          	jal	80003a72 <dirlink>
    80004d14:	00054b63          	bltz	a0,80004d2a <create+0x144>
    dp->nlink++; // for ".."
    80004d18:	04a4d783          	lhu	a5,74(s1)
    80004d1c:	2785                	addiw	a5,a5,1
    80004d1e:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004d22:	8526                	mv	a0,s1
    80004d24:	cb0fe0ef          	jal	800031d4 <iupdate>
    80004d28:	b745                	j	80004cc8 <create+0xe2>
  ip->nlink = 0;
    80004d2a:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80004d2e:	8552                	mv	a0,s4
    80004d30:	ca4fe0ef          	jal	800031d4 <iupdate>
  iunlockput(ip);
    80004d34:	8552                	mv	a0,s4
    80004d36:	fa6fe0ef          	jal	800034dc <iunlockput>
  iunlockput(dp);
    80004d3a:	8526                	mv	a0,s1
    80004d3c:	fa0fe0ef          	jal	800034dc <iunlockput>
  return 0;
    80004d40:	7a02                	ld	s4,32(sp)
    80004d42:	b715                	j	80004c66 <create+0x80>

0000000080004d44 <sys_dup>:
{
    80004d44:	7179                	addi	sp,sp,-48
    80004d46:	f406                	sd	ra,40(sp)
    80004d48:	f022                	sd	s0,32(sp)
    80004d4a:	1800                	addi	s0,sp,48
  if (argfd(0, 0, &f) < 0)
    80004d4c:	fd840613          	addi	a2,s0,-40
    80004d50:	4581                	li	a1,0
    80004d52:	4501                	li	a0,0
    80004d54:	e01ff0ef          	jal	80004b54 <argfd>
    80004d58:	02054863          	bltz	a0,80004d88 <sys_dup+0x44>
    80004d5c:	ec26                	sd	s1,24(sp)
    80004d5e:	e84a                	sd	s2,16(sp)
  if ((fd = fdalloc(f)) < 0)
    80004d60:	fd843483          	ld	s1,-40(s0)
    80004d64:	8526                	mv	a0,s1
    80004d66:	e43ff0ef          	jal	80004ba8 <fdalloc>
    80004d6a:	892a                	mv	s2,a0
    80004d6c:	00054c63          	bltz	a0,80004d84 <sys_dup+0x40>
  filedup(f);
    80004d70:	8526                	mv	a0,s1
    80004d72:	bf8ff0ef          	jal	8000416a <filedup>
  return fd;
    80004d76:	854a                	mv	a0,s2
    80004d78:	64e2                	ld	s1,24(sp)
    80004d7a:	6942                	ld	s2,16(sp)
}
    80004d7c:	70a2                	ld	ra,40(sp)
    80004d7e:	7402                	ld	s0,32(sp)
    80004d80:	6145                	addi	sp,sp,48
    80004d82:	8082                	ret
    80004d84:	64e2                	ld	s1,24(sp)
    80004d86:	6942                	ld	s2,16(sp)
    return -1;
    80004d88:	557d                	li	a0,-1
    80004d8a:	bfcd                	j	80004d7c <sys_dup+0x38>

0000000080004d8c <sys_read>:
{
    80004d8c:	7179                	addi	sp,sp,-48
    80004d8e:	f406                	sd	ra,40(sp)
    80004d90:	f022                	sd	s0,32(sp)
    80004d92:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004d94:	fd840593          	addi	a1,s0,-40
    80004d98:	4505                	li	a0,1
    80004d9a:	b01fd0ef          	jal	8000289a <argaddr>
  argint(2, &n);
    80004d9e:	fe440593          	addi	a1,s0,-28
    80004da2:	4509                	li	a0,2
    80004da4:	adbfd0ef          	jal	8000287e <argint>
  if (argfd(0, 0, &f) < 0)
    80004da8:	fe840613          	addi	a2,s0,-24
    80004dac:	4581                	li	a1,0
    80004dae:	4501                	li	a0,0
    80004db0:	da5ff0ef          	jal	80004b54 <argfd>
    80004db4:	87aa                	mv	a5,a0
    return -1;
    80004db6:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004db8:	0007ca63          	bltz	a5,80004dcc <sys_read+0x40>
  return fileread(f, p, n);
    80004dbc:	fe442603          	lw	a2,-28(s0)
    80004dc0:	fd843583          	ld	a1,-40(s0)
    80004dc4:	fe843503          	ld	a0,-24(s0)
    80004dc8:	d10ff0ef          	jal	800042d8 <fileread>
}
    80004dcc:	70a2                	ld	ra,40(sp)
    80004dce:	7402                	ld	s0,32(sp)
    80004dd0:	6145                	addi	sp,sp,48
    80004dd2:	8082                	ret

0000000080004dd4 <sys_write>:
{
    80004dd4:	7179                	addi	sp,sp,-48
    80004dd6:	f406                	sd	ra,40(sp)
    80004dd8:	f022                	sd	s0,32(sp)
    80004dda:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004ddc:	fd840593          	addi	a1,s0,-40
    80004de0:	4505                	li	a0,1
    80004de2:	ab9fd0ef          	jal	8000289a <argaddr>
  argint(2, &n);
    80004de6:	fe440593          	addi	a1,s0,-28
    80004dea:	4509                	li	a0,2
    80004dec:	a93fd0ef          	jal	8000287e <argint>
  if (argfd(0, 0, &f) < 0)
    80004df0:	fe840613          	addi	a2,s0,-24
    80004df4:	4581                	li	a1,0
    80004df6:	4501                	li	a0,0
    80004df8:	d5dff0ef          	jal	80004b54 <argfd>
    80004dfc:	87aa                	mv	a5,a0
    return -1;
    80004dfe:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004e00:	0007ca63          	bltz	a5,80004e14 <sys_write+0x40>
  return filewrite(f, p, n);
    80004e04:	fe442603          	lw	a2,-28(s0)
    80004e08:	fd843583          	ld	a1,-40(s0)
    80004e0c:	fe843503          	ld	a0,-24(s0)
    80004e10:	d8cff0ef          	jal	8000439c <filewrite>
}
    80004e14:	70a2                	ld	ra,40(sp)
    80004e16:	7402                	ld	s0,32(sp)
    80004e18:	6145                	addi	sp,sp,48
    80004e1a:	8082                	ret

0000000080004e1c <sys_close>:
{
    80004e1c:	1101                	addi	sp,sp,-32
    80004e1e:	ec06                	sd	ra,24(sp)
    80004e20:	e822                	sd	s0,16(sp)
    80004e22:	1000                	addi	s0,sp,32
  if (argfd(0, &fd, &f) < 0)
    80004e24:	fe040613          	addi	a2,s0,-32
    80004e28:	fec40593          	addi	a1,s0,-20
    80004e2c:	4501                	li	a0,0
    80004e2e:	d27ff0ef          	jal	80004b54 <argfd>
    return -1;
    80004e32:	57fd                	li	a5,-1
  if (argfd(0, &fd, &f) < 0)
    80004e34:	02054063          	bltz	a0,80004e54 <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    80004e38:	aabfc0ef          	jal	800018e2 <myproc>
    80004e3c:	fec42783          	lw	a5,-20(s0)
    80004e40:	07e9                	addi	a5,a5,26
    80004e42:	078e                	slli	a5,a5,0x3
    80004e44:	953e                	add	a0,a0,a5
    80004e46:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004e4a:	fe043503          	ld	a0,-32(s0)
    80004e4e:	b62ff0ef          	jal	800041b0 <fileclose>
  return 0;
    80004e52:	4781                	li	a5,0
}
    80004e54:	853e                	mv	a0,a5
    80004e56:	60e2                	ld	ra,24(sp)
    80004e58:	6442                	ld	s0,16(sp)
    80004e5a:	6105                	addi	sp,sp,32
    80004e5c:	8082                	ret

0000000080004e5e <sys_fstat>:
{
    80004e5e:	1101                	addi	sp,sp,-32
    80004e60:	ec06                	sd	ra,24(sp)
    80004e62:	e822                	sd	s0,16(sp)
    80004e64:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004e66:	fe040593          	addi	a1,s0,-32
    80004e6a:	4505                	li	a0,1
    80004e6c:	a2ffd0ef          	jal	8000289a <argaddr>
  if (argfd(0, 0, &f) < 0)
    80004e70:	fe840613          	addi	a2,s0,-24
    80004e74:	4581                	li	a1,0
    80004e76:	4501                	li	a0,0
    80004e78:	cddff0ef          	jal	80004b54 <argfd>
    80004e7c:	87aa                	mv	a5,a0
    return -1;
    80004e7e:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004e80:	0007c863          	bltz	a5,80004e90 <sys_fstat+0x32>
  return filestat(f, st);
    80004e84:	fe043583          	ld	a1,-32(s0)
    80004e88:	fe843503          	ld	a0,-24(s0)
    80004e8c:	be6ff0ef          	jal	80004272 <filestat>
}
    80004e90:	60e2                	ld	ra,24(sp)
    80004e92:	6442                	ld	s0,16(sp)
    80004e94:	6105                	addi	sp,sp,32
    80004e96:	8082                	ret

0000000080004e98 <sys_link>:
{
    80004e98:	7169                	addi	sp,sp,-304
    80004e9a:	f606                	sd	ra,296(sp)
    80004e9c:	f222                	sd	s0,288(sp)
    80004e9e:	1a00                	addi	s0,sp,304
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004ea0:	08000613          	li	a2,128
    80004ea4:	ed040593          	addi	a1,s0,-304
    80004ea8:	4501                	li	a0,0
    80004eaa:	a0dfd0ef          	jal	800028b6 <argstr>
    80004eae:	0e054c63          	bltz	a0,80004fa6 <sys_link+0x10e>
    80004eb2:	08000613          	li	a2,128
    80004eb6:	f5040593          	addi	a1,s0,-176
    80004eba:	4505                	li	a0,1
    80004ebc:	9fbfd0ef          	jal	800028b6 <argstr>
    80004ec0:	0e054363          	bltz	a0,80004fa6 <sys_link+0x10e>
    80004ec4:	ee26                	sd	s1,280(sp)
  begin_op();
    80004ec6:	e35fe0ef          	jal	80003cfa <begin_op>
  if ((ip = namei(old)) == 0) {
    80004eca:	ed040513          	addi	a0,s0,-304
    80004ece:	c4ffe0ef          	jal	80003b1c <namei>
    80004ed2:	84aa                	mv	s1,a0
    80004ed4:	cd35                	beqz	a0,80004f50 <sys_link+0xb8>
  ilock(ip);
    80004ed6:	bb2fe0ef          	jal	80003288 <ilock>
  if (ip->type == T_DIR) {
    80004eda:	04449703          	lh	a4,68(s1)
    80004ede:	4785                	li	a5,1
    80004ee0:	06f70c63          	beq	a4,a5,80004f58 <sys_link+0xc0>
  if (ip->nlink >= NLINK_MAX) {
    80004ee4:	04a49783          	lh	a5,74(s1)
    80004ee8:	6721                	lui	a4,0x8
    80004eea:	177d                	addi	a4,a4,-1 # 7fff <_entry-0x7fff8001>
    80004eec:	06e78d63          	beq	a5,a4,80004f66 <sys_link+0xce>
    80004ef0:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004ef2:	2785                	addiw	a5,a5,1
    80004ef4:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004ef8:	8526                	mv	a0,s1
    80004efa:	adafe0ef          	jal	800031d4 <iupdate>
  iunlock(ip);
    80004efe:	8526                	mv	a0,s1
    80004f00:	c36fe0ef          	jal	80003336 <iunlock>
  if ((dp = nameiparent(new, name)) == 0)
    80004f04:	fd040593          	addi	a1,s0,-48
    80004f08:	f5040513          	addi	a0,s0,-176
    80004f0c:	c2bfe0ef          	jal	80003b36 <nameiparent>
    80004f10:	892a                	mv	s2,a0
    80004f12:	c925                	beqz	a0,80004f82 <sys_link+0xea>
  ilock(dp);
    80004f14:	b74fe0ef          	jal	80003288 <ilock>
  if (dp->nlink == 0) {
    80004f18:	04a91783          	lh	a5,74(s2)
    80004f1c:	cfa1                	beqz	a5,80004f74 <sys_link+0xdc>
  if (dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0) {
    80004f1e:	854a                	mv	a0,s2
    80004f20:	00092703          	lw	a4,0(s2)
    80004f24:	409c                	lw	a5,0(s1)
    80004f26:	04f71b63          	bne	a4,a5,80004f7c <sys_link+0xe4>
    80004f2a:	40d0                	lw	a2,4(s1)
    80004f2c:	fd040593          	addi	a1,s0,-48
    80004f30:	b43fe0ef          	jal	80003a72 <dirlink>
    80004f34:	04054463          	bltz	a0,80004f7c <sys_link+0xe4>
  iunlockput(dp);
    80004f38:	854a                	mv	a0,s2
    80004f3a:	da2fe0ef          	jal	800034dc <iunlockput>
  iput(ip);
    80004f3e:	8526                	mv	a0,s1
    80004f40:	ccafe0ef          	jal	8000340a <iput>
  end_op();
    80004f44:	e43fe0ef          	jal	80003d86 <end_op>
  return 0;
    80004f48:	4501                	li	a0,0
    80004f4a:	64f2                	ld	s1,280(sp)
    80004f4c:	6952                	ld	s2,272(sp)
    80004f4e:	a8a9                	j	80004fa8 <sys_link+0x110>
    end_op();
    80004f50:	e37fe0ef          	jal	80003d86 <end_op>
    return -1;
    80004f54:	64f2                	ld	s1,280(sp)
    80004f56:	a881                	j	80004fa6 <sys_link+0x10e>
    iunlockput(ip);
    80004f58:	8526                	mv	a0,s1
    80004f5a:	d82fe0ef          	jal	800034dc <iunlockput>
    end_op();
    80004f5e:	e29fe0ef          	jal	80003d86 <end_op>
    return -1;
    80004f62:	64f2                	ld	s1,280(sp)
    80004f64:	a089                	j	80004fa6 <sys_link+0x10e>
    iunlockput(ip);
    80004f66:	8526                	mv	a0,s1
    80004f68:	d74fe0ef          	jal	800034dc <iunlockput>
    end_op();
    80004f6c:	e1bfe0ef          	jal	80003d86 <end_op>
    return -1;
    80004f70:	64f2                	ld	s1,280(sp)
    80004f72:	a815                	j	80004fa6 <sys_link+0x10e>
    iunlockput(dp);
    80004f74:	854a                	mv	a0,s2
    80004f76:	d66fe0ef          	jal	800034dc <iunlockput>
    goto bad;
    80004f7a:	a021                	j	80004f82 <sys_link+0xea>
    iunlockput(dp);
    80004f7c:	854a                	mv	a0,s2
    80004f7e:	d5efe0ef          	jal	800034dc <iunlockput>
  ilock(ip);
    80004f82:	8526                	mv	a0,s1
    80004f84:	b04fe0ef          	jal	80003288 <ilock>
  ip->nlink--;
    80004f88:	04a4d783          	lhu	a5,74(s1)
    80004f8c:	37fd                	addiw	a5,a5,-1
    80004f8e:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004f92:	8526                	mv	a0,s1
    80004f94:	a40fe0ef          	jal	800031d4 <iupdate>
  iunlockput(ip);
    80004f98:	8526                	mv	a0,s1
    80004f9a:	d42fe0ef          	jal	800034dc <iunlockput>
  end_op();
    80004f9e:	de9fe0ef          	jal	80003d86 <end_op>
  return -1;
    80004fa2:	64f2                	ld	s1,280(sp)
    80004fa4:	6952                	ld	s2,272(sp)
    return -1;
    80004fa6:	557d                	li	a0,-1
}
    80004fa8:	70b2                	ld	ra,296(sp)
    80004faa:	7412                	ld	s0,288(sp)
    80004fac:	6155                	addi	sp,sp,304
    80004fae:	8082                	ret

0000000080004fb0 <sys_unlink>:
{
    80004fb0:	7151                	addi	sp,sp,-240
    80004fb2:	f586                	sd	ra,232(sp)
    80004fb4:	f1a2                	sd	s0,224(sp)
    80004fb6:	1980                	addi	s0,sp,240
  if (argstr(0, path, MAXPATH) < 0)
    80004fb8:	08000613          	li	a2,128
    80004fbc:	f3040593          	addi	a1,s0,-208
    80004fc0:	4501                	li	a0,0
    80004fc2:	8f5fd0ef          	jal	800028b6 <argstr>
    80004fc6:	14054763          	bltz	a0,80005114 <sys_unlink+0x164>
    80004fca:	eda6                	sd	s1,216(sp)
  begin_op();
    80004fcc:	d2ffe0ef          	jal	80003cfa <begin_op>
  if ((dp = nameiparent(path, name)) == 0) {
    80004fd0:	fb040593          	addi	a1,s0,-80
    80004fd4:	f3040513          	addi	a0,s0,-208
    80004fd8:	b5ffe0ef          	jal	80003b36 <nameiparent>
    80004fdc:	84aa                	mv	s1,a0
    80004fde:	c955                	beqz	a0,80005092 <sys_unlink+0xe2>
  ilock(dp);
    80004fe0:	aa8fe0ef          	jal	80003288 <ilock>
  if (namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004fe4:	00002597          	auipc	a1,0x2
    80004fe8:	5fc58593          	addi	a1,a1,1532 # 800075e0 <etext+0x5e0>
    80004fec:	fb040513          	addi	a0,s0,-80
    80004ff0:	86dfe0ef          	jal	8000385c <namecmp>
    80004ff4:	10050a63          	beqz	a0,80005108 <sys_unlink+0x158>
    80004ff8:	00002597          	auipc	a1,0x2
    80004ffc:	5f058593          	addi	a1,a1,1520 # 800075e8 <etext+0x5e8>
    80005000:	fb040513          	addi	a0,s0,-80
    80005004:	859fe0ef          	jal	8000385c <namecmp>
    80005008:	10050063          	beqz	a0,80005108 <sys_unlink+0x158>
    8000500c:	e9ca                	sd	s2,208(sp)
  if ((ip = dirlookup(dp, name, &off)) == 0)
    8000500e:	f2c40613          	addi	a2,s0,-212
    80005012:	fb040593          	addi	a1,s0,-80
    80005016:	8526                	mv	a0,s1
    80005018:	85bfe0ef          	jal	80003872 <dirlookup>
    8000501c:	892a                	mv	s2,a0
    8000501e:	0e050463          	beqz	a0,80005106 <sys_unlink+0x156>
    80005022:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    80005024:	a64fe0ef          	jal	80003288 <ilock>
  if (ip->nlink < 1)
    80005028:	04a91783          	lh	a5,74(s2)
    8000502c:	06f05763          	blez	a5,8000509a <sys_unlink+0xea>
  if (ip->type == T_DIR && !isdirempty(ip)) {
    80005030:	04491703          	lh	a4,68(s2)
    80005034:	4785                	li	a5,1
    80005036:	06f70863          	beq	a4,a5,800050a6 <sys_unlink+0xf6>
  memset(&de, 0, sizeof(de));
    8000503a:	fc040993          	addi	s3,s0,-64
    8000503e:	4641                	li	a2,16
    80005040:	4581                	li	a1,0
    80005042:	854e                	mv	a0,s3
    80005044:	c71fb0ef          	jal	80000cb4 <memset>
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80005048:	4741                	li	a4,16
    8000504a:	f2c42683          	lw	a3,-212(s0)
    8000504e:	864e                	mv	a2,s3
    80005050:	4581                	li	a1,0
    80005052:	8526                	mv	a0,s1
    80005054:	f00fe0ef          	jal	80003754 <writei>
    80005058:	47c1                	li	a5,16
    8000505a:	08f51763          	bne	a0,a5,800050e8 <sys_unlink+0x138>
  if (ip->type == T_DIR) {
    8000505e:	04491703          	lh	a4,68(s2)
    80005062:	4785                	li	a5,1
    80005064:	08f70863          	beq	a4,a5,800050f4 <sys_unlink+0x144>
  iunlockput(dp);
    80005068:	8526                	mv	a0,s1
    8000506a:	c72fe0ef          	jal	800034dc <iunlockput>
  ip->nlink--;
    8000506e:	04a95783          	lhu	a5,74(s2)
    80005072:	37fd                	addiw	a5,a5,-1
    80005074:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80005078:	854a                	mv	a0,s2
    8000507a:	95afe0ef          	jal	800031d4 <iupdate>
  iunlockput(ip);
    8000507e:	854a                	mv	a0,s2
    80005080:	c5cfe0ef          	jal	800034dc <iunlockput>
  end_op();
    80005084:	d03fe0ef          	jal	80003d86 <end_op>
  return 0;
    80005088:	4501                	li	a0,0
    8000508a:	64ee                	ld	s1,216(sp)
    8000508c:	694e                	ld	s2,208(sp)
    8000508e:	69ae                	ld	s3,200(sp)
    80005090:	a059                	j	80005116 <sys_unlink+0x166>
    end_op();
    80005092:	cf5fe0ef          	jal	80003d86 <end_op>
    return -1;
    80005096:	64ee                	ld	s1,216(sp)
    80005098:	a8b5                	j	80005114 <sys_unlink+0x164>
    panic("unlink: nlink < 1");
    8000509a:	00002517          	auipc	a0,0x2
    8000509e:	55650513          	addi	a0,a0,1366 # 800075f0 <etext+0x5f0>
    800050a2:	fa6fb0ef          	jal	80000848 <panic>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    800050a6:	04c92703          	lw	a4,76(s2)
    800050aa:	02000793          	li	a5,32
    800050ae:	f8e7f6e3          	bgeu	a5,a4,8000503a <sys_unlink+0x8a>
    800050b2:	89be                	mv	s3,a5
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800050b4:	4741                	li	a4,16
    800050b6:	86ce                	mv	a3,s3
    800050b8:	f1840613          	addi	a2,s0,-232
    800050bc:	4581                	li	a1,0
    800050be:	854a                	mv	a0,s2
    800050c0:	da2fe0ef          	jal	80003662 <readi>
    800050c4:	47c1                	li	a5,16
    800050c6:	00f51b63          	bne	a0,a5,800050dc <sys_unlink+0x12c>
    if (de.inum != 0)
    800050ca:	f1845783          	lhu	a5,-232(s0)
    800050ce:	eba1                	bnez	a5,8000511e <sys_unlink+0x16e>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    800050d0:	29c1                	addiw	s3,s3,16
    800050d2:	04c92783          	lw	a5,76(s2)
    800050d6:	fcf9efe3          	bltu	s3,a5,800050b4 <sys_unlink+0x104>
    800050da:	b785                	j	8000503a <sys_unlink+0x8a>
      panic("isdirempty: readi");
    800050dc:	00002517          	auipc	a0,0x2
    800050e0:	52c50513          	addi	a0,a0,1324 # 80007608 <etext+0x608>
    800050e4:	f64fb0ef          	jal	80000848 <panic>
    panic("unlink: writei");
    800050e8:	00002517          	auipc	a0,0x2
    800050ec:	53850513          	addi	a0,a0,1336 # 80007620 <etext+0x620>
    800050f0:	f58fb0ef          	jal	80000848 <panic>
    dp->nlink--;
    800050f4:	04a4d783          	lhu	a5,74(s1)
    800050f8:	37fd                	addiw	a5,a5,-1
    800050fa:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800050fe:	8526                	mv	a0,s1
    80005100:	8d4fe0ef          	jal	800031d4 <iupdate>
    80005104:	b795                	j	80005068 <sys_unlink+0xb8>
    80005106:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80005108:	8526                	mv	a0,s1
    8000510a:	bd2fe0ef          	jal	800034dc <iunlockput>
  end_op();
    8000510e:	c79fe0ef          	jal	80003d86 <end_op>
  return -1;
    80005112:	64ee                	ld	s1,216(sp)
    return -1;
    80005114:	557d                	li	a0,-1
}
    80005116:	70ae                	ld	ra,232(sp)
    80005118:	740e                	ld	s0,224(sp)
    8000511a:	616d                	addi	sp,sp,240
    8000511c:	8082                	ret
    iunlockput(ip);
    8000511e:	854a                	mv	a0,s2
    80005120:	bbcfe0ef          	jal	800034dc <iunlockput>
    goto bad;
    80005124:	694e                	ld	s2,208(sp)
    80005126:	69ae                	ld	s3,200(sp)
    80005128:	b7c5                	j	80005108 <sys_unlink+0x158>

000000008000512a <sys_open>:

uint64
sys_open(void)
{
    8000512a:	7131                	addi	sp,sp,-192
    8000512c:	fd06                	sd	ra,184(sp)
    8000512e:	f922                	sd	s0,176(sp)
    80005130:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80005132:	f4c40593          	addi	a1,s0,-180
    80005136:	4505                	li	a0,1
    80005138:	f46fd0ef          	jal	8000287e <argint>
  if ((n = argstr(0, path, MAXPATH)) < 0)
    8000513c:	08000613          	li	a2,128
    80005140:	f5040593          	addi	a1,s0,-176
    80005144:	4501                	li	a0,0
    80005146:	f70fd0ef          	jal	800028b6 <argstr>
    8000514a:	10054563          	bltz	a0,80005254 <sys_open+0x12a>
    8000514e:	f526                	sd	s1,168(sp)
    return -1;

  begin_op();
    80005150:	babfe0ef          	jal	80003cfa <begin_op>

  if (omode & O_CREATE) {
    80005154:	f4c42783          	lw	a5,-180(s0)
    80005158:	2007f793          	andi	a5,a5,512
    8000515c:	cfd9                	beqz	a5,800051fa <sys_open+0xd0>
    ip = create(path, T_FILE, 0, 0);
    8000515e:	4681                	li	a3,0
    80005160:	4601                	li	a2,0
    80005162:	4589                	li	a1,2
    80005164:	f5040513          	addi	a0,s0,-176
    80005168:	a7fff0ef          	jal	80004be6 <create>
    8000516c:	84aa                	mv	s1,a0
    if (ip == 0) {
    8000516e:	c151                	beqz	a0,800051f2 <sys_open+0xc8>
      end_op();
      return -1;
    }
  }

  if (ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)) {
    80005170:	04449703          	lh	a4,68(s1)
    80005174:	478d                	li	a5,3
    80005176:	00f71763          	bne	a4,a5,80005184 <sys_open+0x5a>
    8000517a:	0464d703          	lhu	a4,70(s1)
    8000517e:	47a5                	li	a5,9
    80005180:	0ae7e863          	bltu	a5,a4,80005230 <sys_open+0x106>
    80005184:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if ((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0) {
    80005186:	f87fe0ef          	jal	8000410c <filealloc>
    8000518a:	892a                	mv	s2,a0
    8000518c:	cd4d                	beqz	a0,80005246 <sys_open+0x11c>
    8000518e:	ed4e                	sd	s3,152(sp)
    80005190:	a19ff0ef          	jal	80004ba8 <fdalloc>
    80005194:	89aa                	mv	s3,a0
    80005196:	0a054463          	bltz	a0,8000523e <sys_open+0x114>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if (ip->type == T_DEVICE) {
    8000519a:	04449703          	lh	a4,68(s1)
    8000519e:	478d                	li	a5,3
    800051a0:	0af70f63          	beq	a4,a5,8000525e <sys_open+0x134>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    800051a4:	4789                	li	a5,2
    800051a6:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    800051aa:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    800051ae:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    800051b2:	f4c42783          	lw	a5,-180(s0)
    800051b6:	0017f713          	andi	a4,a5,1
    800051ba:	00174713          	xori	a4,a4,1
    800051be:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    800051c2:	0037f713          	andi	a4,a5,3
    800051c6:	00e03733          	snez	a4,a4
    800051ca:	00e904a3          	sb	a4,9(s2)

  if ((omode & O_TRUNC) && ip->type == T_FILE) {
    800051ce:	4007f793          	andi	a5,a5,1024
    800051d2:	c791                	beqz	a5,800051de <sys_open+0xb4>
    800051d4:	04449703          	lh	a4,68(s1)
    800051d8:	4789                	li	a5,2
    800051da:	08f70963          	beq	a4,a5,8000526c <sys_open+0x142>
    itrunc(ip);
  }

  iunlock(ip);
    800051de:	8526                	mv	a0,s1
    800051e0:	956fe0ef          	jal	80003336 <iunlock>
  end_op();
    800051e4:	ba3fe0ef          	jal	80003d86 <end_op>

  return fd;
    800051e8:	854e                	mv	a0,s3
    800051ea:	74aa                	ld	s1,168(sp)
    800051ec:	790a                	ld	s2,160(sp)
    800051ee:	69ea                	ld	s3,152(sp)
    800051f0:	a09d                	j	80005256 <sys_open+0x12c>
      end_op();
    800051f2:	b95fe0ef          	jal	80003d86 <end_op>
      return -1;
    800051f6:	74aa                	ld	s1,168(sp)
    800051f8:	a8b1                	j	80005254 <sys_open+0x12a>
    if ((ip = namei(path)) == 0) {
    800051fa:	f5040513          	addi	a0,s0,-176
    800051fe:	91ffe0ef          	jal	80003b1c <namei>
    80005202:	84aa                	mv	s1,a0
    80005204:	c115                	beqz	a0,80005228 <sys_open+0xfe>
    ilock(ip);
    80005206:	882fe0ef          	jal	80003288 <ilock>
    if (ip->type == T_DIR && omode != O_RDONLY) {
    8000520a:	04449703          	lh	a4,68(s1)
    8000520e:	4785                	li	a5,1
    80005210:	f6f710e3          	bne	a4,a5,80005170 <sys_open+0x46>
    80005214:	f4c42783          	lw	a5,-180(s0)
    80005218:	d7b5                	beqz	a5,80005184 <sys_open+0x5a>
      iunlockput(ip);
    8000521a:	8526                	mv	a0,s1
    8000521c:	ac0fe0ef          	jal	800034dc <iunlockput>
      end_op();
    80005220:	b67fe0ef          	jal	80003d86 <end_op>
      return -1;
    80005224:	74aa                	ld	s1,168(sp)
    80005226:	a03d                	j	80005254 <sys_open+0x12a>
      end_op();
    80005228:	b5ffe0ef          	jal	80003d86 <end_op>
      return -1;
    8000522c:	74aa                	ld	s1,168(sp)
    8000522e:	a01d                	j	80005254 <sys_open+0x12a>
    iunlockput(ip);
    80005230:	8526                	mv	a0,s1
    80005232:	aaafe0ef          	jal	800034dc <iunlockput>
    end_op();
    80005236:	b51fe0ef          	jal	80003d86 <end_op>
    return -1;
    8000523a:	74aa                	ld	s1,168(sp)
    8000523c:	a821                	j	80005254 <sys_open+0x12a>
      fileclose(f);
    8000523e:	854a                	mv	a0,s2
    80005240:	f71fe0ef          	jal	800041b0 <fileclose>
    80005244:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80005246:	8526                	mv	a0,s1
    80005248:	a94fe0ef          	jal	800034dc <iunlockput>
    end_op();
    8000524c:	b3bfe0ef          	jal	80003d86 <end_op>
    return -1;
    80005250:	74aa                	ld	s1,168(sp)
    80005252:	790a                	ld	s2,160(sp)
    return -1;
    80005254:	557d                	li	a0,-1
}
    80005256:	70ea                	ld	ra,184(sp)
    80005258:	744a                	ld	s0,176(sp)
    8000525a:	6129                	addi	sp,sp,192
    8000525c:	8082                	ret
    f->type = FD_DEVICE;
    8000525e:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    80005262:	04649783          	lh	a5,70(s1)
    80005266:	02f91223          	sh	a5,36(s2)
    8000526a:	b791                	j	800051ae <sys_open+0x84>
    itrunc(ip);
    8000526c:	8526                	mv	a0,s1
    8000526e:	908fe0ef          	jal	80003376 <itrunc>
    80005272:	b7b5                	j	800051de <sys_open+0xb4>

0000000080005274 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005274:	7175                	addi	sp,sp,-144
    80005276:	e506                	sd	ra,136(sp)
    80005278:	e122                	sd	s0,128(sp)
    8000527a:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    8000527c:	a7ffe0ef          	jal	80003cfa <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0) {
    80005280:	08000613          	li	a2,128
    80005284:	f7040593          	addi	a1,s0,-144
    80005288:	4501                	li	a0,0
    8000528a:	e2cfd0ef          	jal	800028b6 <argstr>
    8000528e:	02054363          	bltz	a0,800052b4 <sys_mkdir+0x40>
    80005292:	4681                	li	a3,0
    80005294:	4601                	li	a2,0
    80005296:	4585                	li	a1,1
    80005298:	f7040513          	addi	a0,s0,-144
    8000529c:	94bff0ef          	jal	80004be6 <create>
    800052a0:	c911                	beqz	a0,800052b4 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800052a2:	a3afe0ef          	jal	800034dc <iunlockput>
  end_op();
    800052a6:	ae1fe0ef          	jal	80003d86 <end_op>
  return 0;
    800052aa:	4501                	li	a0,0
}
    800052ac:	60aa                	ld	ra,136(sp)
    800052ae:	640a                	ld	s0,128(sp)
    800052b0:	6149                	addi	sp,sp,144
    800052b2:	8082                	ret
    end_op();
    800052b4:	ad3fe0ef          	jal	80003d86 <end_op>
    return -1;
    800052b8:	557d                	li	a0,-1
    800052ba:	bfcd                	j	800052ac <sys_mkdir+0x38>

00000000800052bc <sys_mknod>:

uint64
sys_mknod(void)
{
    800052bc:	7135                	addi	sp,sp,-160
    800052be:	ed06                	sd	ra,152(sp)
    800052c0:	e922                	sd	s0,144(sp)
    800052c2:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    800052c4:	a37fe0ef          	jal	80003cfa <begin_op>
  argint(1, &major);
    800052c8:	f6c40593          	addi	a1,s0,-148
    800052cc:	4505                	li	a0,1
    800052ce:	db0fd0ef          	jal	8000287e <argint>
  argint(2, &minor);
    800052d2:	f6840593          	addi	a1,s0,-152
    800052d6:	4509                	li	a0,2
    800052d8:	da6fd0ef          	jal	8000287e <argint>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    800052dc:	08000613          	li	a2,128
    800052e0:	f7040593          	addi	a1,s0,-144
    800052e4:	4501                	li	a0,0
    800052e6:	dd0fd0ef          	jal	800028b6 <argstr>
    800052ea:	02054563          	bltz	a0,80005314 <sys_mknod+0x58>
      (ip = create(path, T_DEVICE, major, minor)) == 0) {
    800052ee:	f6841683          	lh	a3,-152(s0)
    800052f2:	f6c41603          	lh	a2,-148(s0)
    800052f6:	458d                	li	a1,3
    800052f8:	f7040513          	addi	a0,s0,-144
    800052fc:	8ebff0ef          	jal	80004be6 <create>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    80005300:	c911                	beqz	a0,80005314 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005302:	9dafe0ef          	jal	800034dc <iunlockput>
  end_op();
    80005306:	a81fe0ef          	jal	80003d86 <end_op>
  return 0;
    8000530a:	4501                	li	a0,0
}
    8000530c:	60ea                	ld	ra,152(sp)
    8000530e:	644a                	ld	s0,144(sp)
    80005310:	610d                	addi	sp,sp,160
    80005312:	8082                	ret
    end_op();
    80005314:	a73fe0ef          	jal	80003d86 <end_op>
    return -1;
    80005318:	557d                	li	a0,-1
    8000531a:	bfcd                	j	8000530c <sys_mknod+0x50>

000000008000531c <sys_chdir>:

uint64
sys_chdir(void)
{
    8000531c:	7135                	addi	sp,sp,-160
    8000531e:	ed06                	sd	ra,152(sp)
    80005320:	e922                	sd	s0,144(sp)
    80005322:	e14a                	sd	s2,128(sp)
    80005324:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005326:	dbcfc0ef          	jal	800018e2 <myproc>
    8000532a:	892a                	mv	s2,a0

  begin_op();
    8000532c:	9cffe0ef          	jal	80003cfa <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0) {
    80005330:	08000613          	li	a2,128
    80005334:	f6040593          	addi	a1,s0,-160
    80005338:	4501                	li	a0,0
    8000533a:	d7cfd0ef          	jal	800028b6 <argstr>
    8000533e:	02054f63          	bltz	a0,8000537c <sys_chdir+0x60>
    80005342:	e526                	sd	s1,136(sp)
    80005344:	f6040513          	addi	a0,s0,-160
    80005348:	fd4fe0ef          	jal	80003b1c <namei>
    8000534c:	84aa                	mv	s1,a0
    8000534e:	c515                	beqz	a0,8000537a <sys_chdir+0x5e>
    end_op();
    return -1;
  }
  ilock(ip);
    80005350:	f39fd0ef          	jal	80003288 <ilock>
  if (ip->type != T_DIR) {
    80005354:	04449703          	lh	a4,68(s1)
    80005358:	4785                	li	a5,1
    8000535a:	02f71963          	bne	a4,a5,8000538c <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    8000535e:	8526                	mv	a0,s1
    80005360:	fd7fd0ef          	jal	80003336 <iunlock>
  iput(p->cwd);
    80005364:	15093503          	ld	a0,336(s2)
    80005368:	8a2fe0ef          	jal	8000340a <iput>
  end_op();
    8000536c:	a1bfe0ef          	jal	80003d86 <end_op>
  p->cwd = ip;
    80005370:	14993823          	sd	s1,336(s2)
  return 0;
    80005374:	4501                	li	a0,0
    80005376:	64aa                	ld	s1,136(sp)
    80005378:	a029                	j	80005382 <sys_chdir+0x66>
    8000537a:	64aa                	ld	s1,136(sp)
    end_op();
    8000537c:	a0bfe0ef          	jal	80003d86 <end_op>
    return -1;
    80005380:	557d                	li	a0,-1
}
    80005382:	60ea                	ld	ra,152(sp)
    80005384:	644a                	ld	s0,144(sp)
    80005386:	690a                	ld	s2,128(sp)
    80005388:	610d                	addi	sp,sp,160
    8000538a:	8082                	ret
    iunlockput(ip);
    8000538c:	8526                	mv	a0,s1
    8000538e:	94efe0ef          	jal	800034dc <iunlockput>
    end_op();
    80005392:	9f5fe0ef          	jal	80003d86 <end_op>
    return -1;
    80005396:	64aa                	ld	s1,136(sp)
    80005398:	b7e5                	j	80005380 <sys_chdir+0x64>

000000008000539a <sys_exec>:

uint64
sys_exec(void)
{
    8000539a:	7105                	addi	sp,sp,-480
    8000539c:	ef86                	sd	ra,472(sp)
    8000539e:	eba2                	sd	s0,464(sp)
    800053a0:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    800053a2:	e2840593          	addi	a1,s0,-472
    800053a6:	4505                	li	a0,1
    800053a8:	cf2fd0ef          	jal	8000289a <argaddr>
  if (argstr(0, path, MAXPATH) < 0) {
    800053ac:	08000613          	li	a2,128
    800053b0:	f3040593          	addi	a1,s0,-208
    800053b4:	4501                	li	a0,0
    800053b6:	d00fd0ef          	jal	800028b6 <argstr>
    800053ba:	0c054e63          	bltz	a0,80005496 <sys_exec+0xfc>
    800053be:	e7a6                	sd	s1,456(sp)
    800053c0:	e3ca                	sd	s2,448(sp)
    800053c2:	ff4e                	sd	s3,440(sp)
    800053c4:	fb52                	sd	s4,432(sp)
    800053c6:	f756                	sd	s5,424(sp)
    800053c8:	f35a                	sd	s6,416(sp)
    800053ca:	ef5e                	sd	s7,408(sp)
    return -1;
  }
  memset(argv, 0, sizeof(argv));
    800053cc:	e3040a13          	addi	s4,s0,-464
    800053d0:	10000613          	li	a2,256
    800053d4:	4581                	li	a1,0
    800053d6:	8552                	mv	a0,s4
    800053d8:	8ddfb0ef          	jal	80000cb4 <memset>
  for (i = 0;; i++) {
    if (i >= NELEM(argv)) {
    800053dc:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    800053de:	89d2                	mv	s3,s4
    800053e0:	4901                	li	s2,0
      goto bad;
    }
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    800053e2:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if (argv[i] == 0)
      goto bad;
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    800053e6:	6b05                	lui	s6,0x1
    if (i >= NELEM(argv)) {
    800053e8:	02000b93          	li	s7,32
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    800053ec:	00391513          	slli	a0,s2,0x3
    800053f0:	85d6                	mv	a1,s5
    800053f2:	e2843783          	ld	a5,-472(s0)
    800053f6:	953e                	add	a0,a0,a5
    800053f8:	bfefd0ef          	jal	800027f6 <fetchaddr>
    800053fc:	02054663          	bltz	a0,80005428 <sys_exec+0x8e>
    if (uarg == 0) {
    80005400:	e2043783          	ld	a5,-480(s0)
    80005404:	c3b9                	beqz	a5,8000544a <sys_exec+0xb0>
    argv[i] = kalloc();
    80005406:	f18fb0ef          	jal	80000b1e <kalloc>
    8000540a:	85aa                	mv	a1,a0
    8000540c:	00a9b023          	sd	a0,0(s3)
    if (argv[i] == 0)
    80005410:	cd01                	beqz	a0,80005428 <sys_exec+0x8e>
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005412:	865a                	mv	a2,s6
    80005414:	e2043503          	ld	a0,-480(s0)
    80005418:	c24fd0ef          	jal	8000283c <fetchstr>
    8000541c:	00054663          	bltz	a0,80005428 <sys_exec+0x8e>
    if (i >= NELEM(argv)) {
    80005420:	0905                	addi	s2,s2,1
    80005422:	09a1                	addi	s3,s3,8
    80005424:	fd7914e3          	bne	s2,s7,800053ec <sys_exec+0x52>
    kfree(argv[i]);

  return ret;

bad:
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005428:	100a0a13          	addi	s4,s4,256
    8000542c:	6088                	ld	a0,0(s1)
    8000542e:	cd29                	beqz	a0,80005488 <sys_exec+0xee>
    kfree(argv[i]);
    80005430:	e06fb0ef          	jal	80000a36 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005434:	04a1                	addi	s1,s1,8
    80005436:	ff449be3          	bne	s1,s4,8000542c <sys_exec+0x92>
    8000543a:	64be                	ld	s1,456(sp)
    8000543c:	691e                	ld	s2,448(sp)
    8000543e:	79fa                	ld	s3,440(sp)
    80005440:	7a5a                	ld	s4,432(sp)
    80005442:	7aba                	ld	s5,424(sp)
    80005444:	7b1a                	ld	s6,416(sp)
    80005446:	6bfa                	ld	s7,408(sp)
    80005448:	a0b9                	j	80005496 <sys_exec+0xfc>
      argv[i] = 0;
    8000544a:	0009079b          	sext.w	a5,s2
    8000544e:	e3040593          	addi	a1,s0,-464
    80005452:	078e                	slli	a5,a5,0x3
    80005454:	97ae                	add	a5,a5,a1
    80005456:	0007b023          	sd	zero,0(a5)
  int ret = kexec(path, argv);
    8000545a:	f3040513          	addi	a0,s0,-208
    8000545e:	bdeff0ef          	jal	8000483c <kexec>
    80005462:	892a                	mv	s2,a0
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005464:	100a0a13          	addi	s4,s4,256
    80005468:	6088                	ld	a0,0(s1)
    8000546a:	c511                	beqz	a0,80005476 <sys_exec+0xdc>
    kfree(argv[i]);
    8000546c:	dcafb0ef          	jal	80000a36 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005470:	04a1                	addi	s1,s1,8
    80005472:	ff449be3          	bne	s1,s4,80005468 <sys_exec+0xce>
  return ret;
    80005476:	854a                	mv	a0,s2
    80005478:	64be                	ld	s1,456(sp)
    8000547a:	691e                	ld	s2,448(sp)
    8000547c:	79fa                	ld	s3,440(sp)
    8000547e:	7a5a                	ld	s4,432(sp)
    80005480:	7aba                	ld	s5,424(sp)
    80005482:	7b1a                	ld	s6,416(sp)
    80005484:	6bfa                	ld	s7,408(sp)
    80005486:	a809                	j	80005498 <sys_exec+0xfe>
    80005488:	64be                	ld	s1,456(sp)
    8000548a:	691e                	ld	s2,448(sp)
    8000548c:	79fa                	ld	s3,440(sp)
    8000548e:	7a5a                	ld	s4,432(sp)
    80005490:	7aba                	ld	s5,424(sp)
    80005492:	7b1a                	ld	s6,416(sp)
    80005494:	6bfa                	ld	s7,408(sp)
    return -1;
    80005496:	557d                	li	a0,-1
  return -1;
}
    80005498:	60fe                	ld	ra,472(sp)
    8000549a:	645e                	ld	s0,464(sp)
    8000549c:	613d                	addi	sp,sp,480
    8000549e:	8082                	ret

00000000800054a0 <sys_pipe>:

uint64
sys_pipe(void)
{
    800054a0:	7139                	addi	sp,sp,-64
    800054a2:	fc06                	sd	ra,56(sp)
    800054a4:	f822                	sd	s0,48(sp)
    800054a6:	f426                	sd	s1,40(sp)
    800054a8:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    800054aa:	c38fc0ef          	jal	800018e2 <myproc>
    800054ae:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    800054b0:	fd840593          	addi	a1,s0,-40
    800054b4:	4501                	li	a0,0
    800054b6:	be4fd0ef          	jal	8000289a <argaddr>
  if (pipealloc(&rf, &wf) < 0)
    800054ba:	fc840593          	addi	a1,s0,-56
    800054be:	fd040513          	addi	a0,s0,-48
    800054c2:	812ff0ef          	jal	800044d4 <pipealloc>
    800054c6:	0a054663          	bltz	a0,80005572 <sys_pipe+0xd2>
    return -1;
  fd0 = -1;
    800054ca:	57fd                	li	a5,-1
    800054cc:	fcf42223          	sw	a5,-60(s0)
  if ((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0) {
    800054d0:	fd043503          	ld	a0,-48(s0)
    800054d4:	ed4ff0ef          	jal	80004ba8 <fdalloc>
    800054d8:	fca42223          	sw	a0,-60(s0)
    800054dc:	08054363          	bltz	a0,80005562 <sys_pipe+0xc2>
    800054e0:	fc843503          	ld	a0,-56(s0)
    800054e4:	ec4ff0ef          	jal	80004ba8 <fdalloc>
    800054e8:	fca42023          	sw	a0,-64(s0)
    800054ec:	06054263          	bltz	a0,80005550 <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    800054f0:	4711                	li	a4,4
    800054f2:	fc440693          	addi	a3,s0,-60
    800054f6:	fd843603          	ld	a2,-40(s0)
    800054fa:	64ac                	ld	a1,72(s1)
    800054fc:	68a8                	ld	a0,80(s1)
    800054fe:	82efc0ef          	jal	8000152c <copyout>
    80005502:	02054063          	bltz	a0,80005522 <sys_pipe+0x82>
      copyout(p->pagetable, p->sz, fdarray + sizeof(fd0), (char *)&fd1,
    80005506:	4711                	li	a4,4
    80005508:	fc040693          	addi	a3,s0,-64
    8000550c:	fd843603          	ld	a2,-40(s0)
    80005510:	963a                	add	a2,a2,a4
    80005512:	64ac                	ld	a1,72(s1)
    80005514:	68a8                	ld	a0,80(s1)
    80005516:	816fc0ef          	jal	8000152c <copyout>
    8000551a:	87aa                	mv	a5,a0
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    8000551c:	4501                	li	a0,0
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    8000551e:	0407db63          	bgez	a5,80005574 <sys_pipe+0xd4>
    p->ofile[fd0] = 0;
    80005522:	fc442783          	lw	a5,-60(s0)
    80005526:	07e9                	addi	a5,a5,26
    80005528:	078e                	slli	a5,a5,0x3
    8000552a:	97a6                	add	a5,a5,s1
    8000552c:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80005530:	fc042783          	lw	a5,-64(s0)
    80005534:	07e9                	addi	a5,a5,26
    80005536:	078e                	slli	a5,a5,0x3
    80005538:	94be                	add	s1,s1,a5
    8000553a:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    8000553e:	fd043503          	ld	a0,-48(s0)
    80005542:	c6ffe0ef          	jal	800041b0 <fileclose>
    fileclose(wf);
    80005546:	fc843503          	ld	a0,-56(s0)
    8000554a:	c67fe0ef          	jal	800041b0 <fileclose>
    return -1;
    8000554e:	a015                	j	80005572 <sys_pipe+0xd2>
    if (fd0 >= 0)
    80005550:	fc442783          	lw	a5,-60(s0)
    80005554:	0007c763          	bltz	a5,80005562 <sys_pipe+0xc2>
      p->ofile[fd0] = 0;
    80005558:	07e9                	addi	a5,a5,26
    8000555a:	078e                	slli	a5,a5,0x3
    8000555c:	97a6                	add	a5,a5,s1
    8000555e:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005562:	fd043503          	ld	a0,-48(s0)
    80005566:	c4bfe0ef          	jal	800041b0 <fileclose>
    fileclose(wf);
    8000556a:	fc843503          	ld	a0,-56(s0)
    8000556e:	c43fe0ef          	jal	800041b0 <fileclose>
    return -1;
    80005572:	557d                	li	a0,-1
}
    80005574:	70e2                	ld	ra,56(sp)
    80005576:	7442                	ld	s0,48(sp)
    80005578:	74a2                	ld	s1,40(sp)
    8000557a:	6121                	addi	sp,sp,64
    8000557c:	8082                	ret
	...

0000000080005580 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005580:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005582:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005584:	e80e                	sd	gp,16(sp)
        # sd tp, 24(sp)
        sd t0, 32(sp)
    80005586:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    80005588:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000558a:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000558c:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    8000558e:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005590:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005592:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005594:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005596:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    80005598:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000559a:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000559c:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    8000559e:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    800055a0:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    800055a2:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    800055a4:	960fd0ef          	jal	80002704 <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    800055a8:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    800055aa:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    800055ac:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    800055ae:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    800055b0:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    800055b2:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    800055b4:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    800055b6:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    800055b8:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    800055ba:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    800055bc:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    800055be:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    800055c0:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    800055c2:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    800055c4:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    800055c6:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    800055c8:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    800055ca:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    800055cc:	10200073          	sret
    800055d0:	0001                	nop
    800055d2:	00000013          	nop
    800055d6:	00000013          	nop
    800055da:	00000013          	nop

00000000800055de <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    800055de:	1141                	addi	sp,sp,-16
    800055e0:	e406                	sd	ra,8(sp)
    800055e2:	e022                	sd	s0,0(sp)
    800055e4:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32 *)(PLIC + UART0_IRQ * 4) = 1;
    800055e6:	0c000737          	lui	a4,0xc000
    800055ea:	4785                	li	a5,1
    800055ec:	d71c                	sw	a5,40(a4)
  *(uint32 *)(PLIC + VIRTIO0_IRQ * 4) = 1;
    800055ee:	c35c                	sw	a5,4(a4)
}
    800055f0:	60a2                	ld	ra,8(sp)
    800055f2:	6402                	ld	s0,0(sp)
    800055f4:	0141                	addi	sp,sp,16
    800055f6:	8082                	ret

00000000800055f8 <plicinithart>:

void
plicinithart(void)
{
    800055f8:	1141                	addi	sp,sp,-16
    800055fa:	e406                	sd	ra,8(sp)
    800055fc:	e022                	sd	s0,0(sp)
    800055fe:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005600:	aaefc0ef          	jal	800018ae <cpuid>

  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32 *)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005604:	0085171b          	slliw	a4,a0,0x8
    80005608:	0c0027b7          	lui	a5,0xc002
    8000560c:	97ba                	add	a5,a5,a4
    8000560e:	40200713          	li	a4,1026
    80005612:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32 *)PLIC_SPRIORITY(hart) = 0;
    80005616:	00d5151b          	slliw	a0,a0,0xd
    8000561a:	0c2017b7          	lui	a5,0xc201
    8000561e:	97aa                	add	a5,a5,a0
    80005620:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80005624:	60a2                	ld	ra,8(sp)
    80005626:	6402                	ld	s0,0(sp)
    80005628:	0141                	addi	sp,sp,16
    8000562a:	8082                	ret

000000008000562c <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    8000562c:	1141                	addi	sp,sp,-16
    8000562e:	e406                	sd	ra,8(sp)
    80005630:	e022                	sd	s0,0(sp)
    80005632:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005634:	a7afc0ef          	jal	800018ae <cpuid>
  int irq = *(uint32 *)PLIC_SCLAIM(hart);
    80005638:	00d5151b          	slliw	a0,a0,0xd
    8000563c:	0c2017b7          	lui	a5,0xc201
    80005640:	97aa                	add	a5,a5,a0
  return irq;
}
    80005642:	43c8                	lw	a0,4(a5)
    80005644:	60a2                	ld	ra,8(sp)
    80005646:	6402                	ld	s0,0(sp)
    80005648:	0141                	addi	sp,sp,16
    8000564a:	8082                	ret

000000008000564c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    8000564c:	1101                	addi	sp,sp,-32
    8000564e:	ec06                	sd	ra,24(sp)
    80005650:	e822                	sd	s0,16(sp)
    80005652:	e426                	sd	s1,8(sp)
    80005654:	1000                	addi	s0,sp,32
    80005656:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005658:	a56fc0ef          	jal	800018ae <cpuid>
  *(uint32 *)PLIC_SCLAIM(hart) = irq;
    8000565c:	00d5179b          	slliw	a5,a0,0xd
    80005660:	0c201737          	lui	a4,0xc201
    80005664:	97ba                	add	a5,a5,a4
    80005666:	c3c4                	sw	s1,4(a5)
}
    80005668:	60e2                	ld	ra,24(sp)
    8000566a:	6442                	ld	s0,16(sp)
    8000566c:	64a2                	ld	s1,8(sp)
    8000566e:	6105                	addi	sp,sp,32
    80005670:	8082                	ret

0000000080005672 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005672:	1141                	addi	sp,sp,-16
    80005674:	e406                	sd	ra,8(sp)
    80005676:	e022                	sd	s0,0(sp)
    80005678:	0800                	addi	s0,sp,16
  if (i >= NUM)
    8000567a:	479d                	li	a5,7
    8000567c:	04a7ca63          	blt	a5,a0,800056d0 <free_desc+0x5e>
    panic("free_desc 1");
  if (disk.free[i])
    80005680:	0001e797          	auipc	a5,0x1e
    80005684:	e7078793          	addi	a5,a5,-400 # 800234f0 <disk>
    80005688:	97aa                	add	a5,a5,a0
    8000568a:	0187c783          	lbu	a5,24(a5)
    8000568e:	e7b9                	bnez	a5,800056dc <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005690:	00451693          	slli	a3,a0,0x4
    80005694:	0001e797          	auipc	a5,0x1e
    80005698:	e5c78793          	addi	a5,a5,-420 # 800234f0 <disk>
    8000569c:	6398                	ld	a4,0(a5)
    8000569e:	9736                	add	a4,a4,a3
    800056a0:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    800056a4:	6398                	ld	a4,0(a5)
    800056a6:	9736                	add	a4,a4,a3
    800056a8:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    800056ac:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    800056b0:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    800056b4:	97aa                	add	a5,a5,a0
    800056b6:	4705                	li	a4,1
    800056b8:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    800056bc:	0001e517          	auipc	a0,0x1e
    800056c0:	e4c50513          	addi	a0,a0,-436 # 80023508 <disk+0x18>
    800056c4:	893fc0ef          	jal	80001f56 <wakeup>
}
    800056c8:	60a2                	ld	ra,8(sp)
    800056ca:	6402                	ld	s0,0(sp)
    800056cc:	0141                	addi	sp,sp,16
    800056ce:	8082                	ret
    panic("free_desc 1");
    800056d0:	00002517          	auipc	a0,0x2
    800056d4:	f6050513          	addi	a0,a0,-160 # 80007630 <etext+0x630>
    800056d8:	970fb0ef          	jal	80000848 <panic>
    panic("free_desc 2");
    800056dc:	00002517          	auipc	a0,0x2
    800056e0:	f6450513          	addi	a0,a0,-156 # 80007640 <etext+0x640>
    800056e4:	964fb0ef          	jal	80000848 <panic>

00000000800056e8 <virtio_disk_init>:
{
    800056e8:	1101                	addi	sp,sp,-32
    800056ea:	ec06                	sd	ra,24(sp)
    800056ec:	e822                	sd	s0,16(sp)
    800056ee:	e426                	sd	s1,8(sp)
    800056f0:	e04a                	sd	s2,0(sp)
    800056f2:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    800056f4:	00002597          	auipc	a1,0x2
    800056f8:	f5c58593          	addi	a1,a1,-164 # 80007650 <etext+0x650>
    800056fc:	0001e517          	auipc	a0,0x1e
    80005700:	f1c50513          	addi	a0,a0,-228 # 80023618 <disk+0x128>
    80005704:	c74fb0ef          	jal	80000b78 <initlock>
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005708:	100017b7          	lui	a5,0x10001
    8000570c:	4398                	lw	a4,0(a5)
    8000570e:	747277b7          	lui	a5,0x74727
    80005712:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005716:	14f71263          	bne	a4,a5,8000585a <virtio_disk_init+0x172>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000571a:	100017b7          	lui	a5,0x10001
    8000571e:	43d8                	lw	a4,4(a5)
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005720:	4789                	li	a5,2
    80005722:	12f71c63          	bne	a4,a5,8000585a <virtio_disk_init+0x172>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005726:	100017b7          	lui	a5,0x10001
    8000572a:	4798                	lw	a4,8(a5)
    8000572c:	4789                	li	a5,2
    8000572e:	12f71663          	bne	a4,a5,8000585a <virtio_disk_init+0x172>
      *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551) {
    80005732:	100017b7          	lui	a5,0x10001
    80005736:	47d8                	lw	a4,12(a5)
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005738:	554d47b7          	lui	a5,0x554d4
    8000573c:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005740:	10f71d63          	bne	a4,a5,8000585a <virtio_disk_init+0x172>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005744:	100017b7          	lui	a5,0x10001
    80005748:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000574c:	4705                	li	a4,1
    8000574e:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005750:	470d                	li	a4,3
    80005752:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80005754:	10001737          	lui	a4,0x10001
    80005758:	4b18                	lw	a4,16(a4)
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    8000575a:	c7ffe6b7          	lui	a3,0xc7ffe
    8000575e:	55f68693          	addi	a3,a3,1375 # ffffffffc7ffe55f <end+0xffffffff47fdaf2f>
    80005762:	8f75                	and	a4,a4,a3
    80005764:	100016b7          	lui	a3,0x10001
    80005768:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    8000576a:	472d                	li	a4,11
    8000576c:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    8000576e:	0707a903          	lw	s2,112(a5)
  if (!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005772:	00897793          	andi	a5,s2,8
    80005776:	0e078863          	beqz	a5,80005866 <virtio_disk_init+0x17e>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    8000577a:	100017b7          	lui	a5,0x10001
    8000577e:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if (*R(VIRTIO_MMIO_QUEUE_READY))
    80005782:	43fc                	lw	a5,68(a5)
    80005784:	0e079763          	bnez	a5,80005872 <virtio_disk_init+0x18a>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005788:	100017b7          	lui	a5,0x10001
    8000578c:	5bdc                	lw	a5,52(a5)
  if (max == 0)
    8000578e:	0e078863          	beqz	a5,8000587e <virtio_disk_init+0x196>
  if (max < NUM)
    80005792:	471d                	li	a4,7
    80005794:	0ef77b63          	bgeu	a4,a5,8000588a <virtio_disk_init+0x1a2>
  disk.desc = kalloc();
    80005798:	b86fb0ef          	jal	80000b1e <kalloc>
    8000579c:	0001e497          	auipc	s1,0x1e
    800057a0:	d5448493          	addi	s1,s1,-684 # 800234f0 <disk>
    800057a4:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    800057a6:	b78fb0ef          	jal	80000b1e <kalloc>
    800057aa:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    800057ac:	b72fb0ef          	jal	80000b1e <kalloc>
    800057b0:	87aa                	mv	a5,a0
    800057b2:	e888                	sd	a0,16(s1)
  if (!disk.desc || !disk.avail || !disk.used)
    800057b4:	6088                	ld	a0,0(s1)
    800057b6:	0e050063          	beqz	a0,80005896 <virtio_disk_init+0x1ae>
    800057ba:	0001e717          	auipc	a4,0x1e
    800057be:	d3e73703          	ld	a4,-706(a4) # 800234f8 <disk+0x8>
    800057c2:	00173713          	seqz	a4,a4
    800057c6:	0017b793          	seqz	a5,a5
    800057ca:	8fd9                	or	a5,a5,a4
    800057cc:	e7e9                	bnez	a5,80005896 <virtio_disk_init+0x1ae>
  memset(disk.desc, 0, PGSIZE);
    800057ce:	6605                	lui	a2,0x1
    800057d0:	4581                	li	a1,0
    800057d2:	ce2fb0ef          	jal	80000cb4 <memset>
  memset(disk.avail, 0, PGSIZE);
    800057d6:	0001e497          	auipc	s1,0x1e
    800057da:	d1a48493          	addi	s1,s1,-742 # 800234f0 <disk>
    800057de:	6605                	lui	a2,0x1
    800057e0:	4581                	li	a1,0
    800057e2:	6488                	ld	a0,8(s1)
    800057e4:	cd0fb0ef          	jal	80000cb4 <memset>
  memset(disk.used, 0, PGSIZE);
    800057e8:	6605                	lui	a2,0x1
    800057ea:	4581                	li	a1,0
    800057ec:	6888                	ld	a0,16(s1)
    800057ee:	cc6fb0ef          	jal	80000cb4 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    800057f2:	100017b7          	lui	a5,0x10001
    800057f6:	4721                	li	a4,8
    800057f8:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    800057fa:	4098                	lw	a4,0(s1)
    800057fc:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005800:	40d8                	lw	a4,4(s1)
    80005802:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005806:	649c                	ld	a5,8(s1)
    80005808:	10001737          	lui	a4,0x10001
    8000580c:	08f72823          	sw	a5,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005810:	9781                	srai	a5,a5,0x20
    80005812:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005816:	689c                	ld	a5,16(s1)
    80005818:	0af72023          	sw	a5,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    8000581c:	9781                	srai	a5,a5,0x20
    8000581e:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005822:	4785                	li	a5,1
    80005824:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005826:	00f48c23          	sb	a5,24(s1)
    8000582a:	00f48ca3          	sb	a5,25(s1)
    8000582e:	00f48d23          	sb	a5,26(s1)
    80005832:	00f48da3          	sb	a5,27(s1)
    80005836:	00f48e23          	sb	a5,28(s1)
    8000583a:	00f48ea3          	sb	a5,29(s1)
    8000583e:	00f48f23          	sb	a5,30(s1)
    80005842:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005846:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    8000584a:	07272823          	sw	s2,112(a4)
}
    8000584e:	60e2                	ld	ra,24(sp)
    80005850:	6442                	ld	s0,16(sp)
    80005852:	64a2                	ld	s1,8(sp)
    80005854:	6902                	ld	s2,0(sp)
    80005856:	6105                	addi	sp,sp,32
    80005858:	8082                	ret
    panic("could not find virtio disk");
    8000585a:	00002517          	auipc	a0,0x2
    8000585e:	e0650513          	addi	a0,a0,-506 # 80007660 <etext+0x660>
    80005862:	fe7fa0ef          	jal	80000848 <panic>
    panic("virtio disk FEATURES_OK unset");
    80005866:	00002517          	auipc	a0,0x2
    8000586a:	e1a50513          	addi	a0,a0,-486 # 80007680 <etext+0x680>
    8000586e:	fdbfa0ef          	jal	80000848 <panic>
    panic("virtio disk should not be ready");
    80005872:	00002517          	auipc	a0,0x2
    80005876:	e2e50513          	addi	a0,a0,-466 # 800076a0 <etext+0x6a0>
    8000587a:	fcffa0ef          	jal	80000848 <panic>
    panic("virtio disk has no queue 0");
    8000587e:	00002517          	auipc	a0,0x2
    80005882:	e4250513          	addi	a0,a0,-446 # 800076c0 <etext+0x6c0>
    80005886:	fc3fa0ef          	jal	80000848 <panic>
    panic("virtio disk max queue too short");
    8000588a:	00002517          	auipc	a0,0x2
    8000588e:	e5650513          	addi	a0,a0,-426 # 800076e0 <etext+0x6e0>
    80005892:	fb7fa0ef          	jal	80000848 <panic>
    panic("virtio disk kalloc");
    80005896:	00002517          	auipc	a0,0x2
    8000589a:	e6a50513          	addi	a0,a0,-406 # 80007700 <etext+0x700>
    8000589e:	fabfa0ef          	jal	80000848 <panic>

00000000800058a2 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    800058a2:	711d                	addi	sp,sp,-96
    800058a4:	ec86                	sd	ra,88(sp)
    800058a6:	e8a2                	sd	s0,80(sp)
    800058a8:	e4a6                	sd	s1,72(sp)
    800058aa:	e0ca                	sd	s2,64(sp)
    800058ac:	fc4e                	sd	s3,56(sp)
    800058ae:	f852                	sd	s4,48(sp)
    800058b0:	f456                	sd	s5,40(sp)
    800058b2:	f05a                	sd	s6,32(sp)
    800058b4:	ec5e                	sd	s7,24(sp)
    800058b6:	e862                	sd	s8,16(sp)
    800058b8:	1080                	addi	s0,sp,96
    800058ba:	89aa                	mv	s3,a0
    800058bc:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    800058be:	00c52b83          	lw	s7,12(a0)
    800058c2:	001b9b9b          	slliw	s7,s7,0x1
    800058c6:	1b82                	slli	s7,s7,0x20
    800058c8:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    800058cc:	0001e517          	auipc	a0,0x1e
    800058d0:	d4c50513          	addi	a0,a0,-692 # 80023618 <disk+0x128>
    800058d4:	b24fb0ef          	jal	80000bf8 <acquire>
  for (int i = 0; i < NUM; i++) {
    800058d8:	44a1                	li	s1,8
      disk.free[i] = 0;
    800058da:	0001ea97          	auipc	s5,0x1e
    800058de:	c16a8a93          	addi	s5,s5,-1002 # 800234f0 <disk>
  for (int i = 0; i < 3; i++) {
    800058e2:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    800058e4:	5c7d                	li	s8,-1
    800058e6:	a8a5                	j	8000595e <virtio_disk_rw+0xbc>
      disk.free[i] = 0;
    800058e8:	00fa8733          	add	a4,s5,a5
    800058ec:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    800058f0:	c19c                	sw	a5,0(a1)
    if (idx[i] < 0) {
    800058f2:	0207c563          	bltz	a5,8000591c <virtio_disk_rw+0x7a>
  for (int i = 0; i < 3; i++) {
    800058f6:	2905                	addiw	s2,s2,1
    800058f8:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    800058fa:	07490663          	beq	s2,s4,80005966 <virtio_disk_rw+0xc4>
    idx[i] = alloc_desc();
    800058fe:	85b2                	mv	a1,a2
  for (int i = 0; i < NUM; i++) {
    80005900:	0001e717          	auipc	a4,0x1e
    80005904:	bf070713          	addi	a4,a4,-1040 # 800234f0 <disk>
    80005908:	4781                	li	a5,0
    if (disk.free[i]) {
    8000590a:	01874683          	lbu	a3,24(a4)
    8000590e:	fee9                	bnez	a3,800058e8 <virtio_disk_rw+0x46>
  for (int i = 0; i < NUM; i++) {
    80005910:	2785                	addiw	a5,a5,1
    80005912:	0705                	addi	a4,a4,1
    80005914:	fe979be3          	bne	a5,s1,8000590a <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    80005918:	0185a023          	sw	s8,0(a1)
      for (int j = 0; j < i; j++)
    8000591c:	01205d63          	blez	s2,80005936 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80005920:	fa042503          	lw	a0,-96(s0)
    80005924:	d4fff0ef          	jal	80005672 <free_desc>
      for (int j = 0; j < i; j++)
    80005928:	4785                	li	a5,1
    8000592a:	0127d663          	bge	a5,s2,80005936 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    8000592e:	fa442503          	lw	a0,-92(s0)
    80005932:	d41ff0ef          	jal	80005672 <free_desc>
  int idx[3];
  while (1) {
    if (alloc3_desc(idx) == 0) {
      break;
    }
    sleep_prepare(&disk.free[0]);
    80005936:	0001e517          	auipc	a0,0x1e
    8000593a:	bd250513          	addi	a0,a0,-1070 # 80023508 <disk+0x18>
    8000593e:	dacfc0ef          	jal	80001eea <sleep_prepare>
    release(&disk.vdisk_lock);
    80005942:	0001e517          	auipc	a0,0x1e
    80005946:	cd650513          	addi	a0,a0,-810 # 80023618 <disk+0x128>
    8000594a:	b32fb0ef          	jal	80000c7c <release>
    sleep();
    8000594e:	dd8fc0ef          	jal	80001f26 <sleep>
    acquire(&disk.vdisk_lock);
    80005952:	0001e517          	auipc	a0,0x1e
    80005956:	cc650513          	addi	a0,a0,-826 # 80023618 <disk+0x128>
    8000595a:	a9efb0ef          	jal	80000bf8 <acquire>
  for (int i = 0; i < 3; i++) {
    8000595e:	fa040613          	addi	a2,s0,-96
    80005962:	4901                	li	s2,0
    80005964:	bf69                	j	800058fe <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005966:	fa042503          	lw	a0,-96(s0)
    8000596a:	00451693          	slli	a3,a0,0x4

  if (write)
    8000596e:	0001e797          	auipc	a5,0x1e
    80005972:	b8278793          	addi	a5,a5,-1150 # 800234f0 <disk>
    80005976:	00451713          	slli	a4,a0,0x4
    8000597a:	0a070713          	addi	a4,a4,160
    8000597e:	973e                	add	a4,a4,a5
    80005980:	01603633          	snez	a2,s6
    80005984:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005986:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    8000598a:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64)buf0;
    8000598e:	6398                	ld	a4,0(a5)
    80005990:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005992:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80005996:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64)buf0;
    80005998:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    8000599a:	6390                	ld	a2,0(a5)
    8000599c:	00d605b3          	add	a1,a2,a3
    800059a0:	4741                	li	a4,16
    800059a2:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    800059a4:	4805                	li	a6,1
    800059a6:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    800059aa:	fa442703          	lw	a4,-92(s0)
    800059ae:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64)b->data;
    800059b2:	0712                	slli	a4,a4,0x4
    800059b4:	963a                	add	a2,a2,a4
    800059b6:	05898593          	addi	a1,s3,88
    800059ba:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    800059bc:	0007b883          	ld	a7,0(a5)
    800059c0:	9746                	add	a4,a4,a7
    800059c2:	40000613          	li	a2,1024
    800059c6:	c710                	sw	a2,8(a4)
  if (write)
    800059c8:	001b3613          	seqz	a2,s6
    800059cc:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    800059d0:	01066633          	or	a2,a2,a6
    800059d4:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    800059d8:	fa842583          	lw	a1,-88(s0)
    800059dc:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    800059e0:	00250613          	addi	a2,a0,2
    800059e4:	0612                	slli	a2,a2,0x4
    800059e6:	963e                	add	a2,a2,a5
    800059e8:	577d                	li	a4,-1
    800059ea:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64)&disk.info[idx[0]].status;
    800059ee:	0592                	slli	a1,a1,0x4
    800059f0:	98ae                	add	a7,a7,a1
    800059f2:	03068713          	addi	a4,a3,48
    800059f6:	973e                	add	a4,a4,a5
    800059f8:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    800059fc:	6398                	ld	a4,0(a5)
    800059fe:	972e                	add	a4,a4,a1
    80005a00:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005a04:	4689                	li	a3,2
    80005a06:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005a0a:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005a0e:	0109a223          	sw	a6,4(s3)
  disk.info[idx[0]].b = b;
    80005a12:	01363423          	sd	s3,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005a16:	6794                	ld	a3,8(a5)
    80005a18:	0026d703          	lhu	a4,2(a3)
    80005a1c:	8b1d                	andi	a4,a4,7
    80005a1e:	0706                	slli	a4,a4,0x1
    80005a20:	96ba                	add	a3,a3,a4
    80005a22:	00a69223          	sh	a0,4(a3)

// fence for memory-mapped IO
static inline void
io_fence()
{
  asm volatile("fence iorw, iorw" ::: "memory");
    80005a26:	0ff0000f          	fence

  io_fence();

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005a2a:	6798                	ld	a4,8(a5)
    80005a2c:	00275783          	lhu	a5,2(a4)
    80005a30:	2785                	addiw	a5,a5,1
    80005a32:	00f71123          	sh	a5,2(a4)
    80005a36:	0ff0000f          	fence

  io_fence();

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005a3a:	100017b7          	lui	a5,0x10001
    80005a3e:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while (b->disk == 1) {
    80005a42:	0049a783          	lw	a5,4(s3)
    80005a46:	03079663          	bne	a5,a6,80005a72 <virtio_disk_rw+0x1d0>
    sleep_prepare(b);
    release(&disk.vdisk_lock);
    80005a4a:	0001e497          	auipc	s1,0x1e
    80005a4e:	bce48493          	addi	s1,s1,-1074 # 80023618 <disk+0x128>
  while (b->disk == 1) {
    80005a52:	893e                	mv	s2,a5
    sleep_prepare(b);
    80005a54:	854e                	mv	a0,s3
    80005a56:	c94fc0ef          	jal	80001eea <sleep_prepare>
    release(&disk.vdisk_lock);
    80005a5a:	8526                	mv	a0,s1
    80005a5c:	a20fb0ef          	jal	80000c7c <release>
    sleep();
    80005a60:	cc6fc0ef          	jal	80001f26 <sleep>
    acquire(&disk.vdisk_lock);
    80005a64:	8526                	mv	a0,s1
    80005a66:	992fb0ef          	jal	80000bf8 <acquire>
  while (b->disk == 1) {
    80005a6a:	0049a783          	lw	a5,4(s3)
    80005a6e:	ff2783e3          	beq	a5,s2,80005a54 <virtio_disk_rw+0x1b2>
  }

  disk.info[idx[0]].b = 0;
    80005a72:	fa042903          	lw	s2,-96(s0)
    80005a76:	00290713          	addi	a4,s2,2
    80005a7a:	0712                	slli	a4,a4,0x4
    80005a7c:	0001e797          	auipc	a5,0x1e
    80005a80:	a7478793          	addi	a5,a5,-1420 # 800234f0 <disk>
    80005a84:	97ba                	add	a5,a5,a4
    80005a86:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005a8a:	0001e997          	auipc	s3,0x1e
    80005a8e:	a6698993          	addi	s3,s3,-1434 # 800234f0 <disk>
    80005a92:	00491713          	slli	a4,s2,0x4
    80005a96:	0009b783          	ld	a5,0(s3)
    80005a9a:	97ba                	add	a5,a5,a4
    80005a9c:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005aa0:	854a                	mv	a0,s2
    80005aa2:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005aa6:	bcdff0ef          	jal	80005672 <free_desc>
    if (flag & VRING_DESC_F_NEXT)
    80005aaa:	8885                	andi	s1,s1,1
    80005aac:	f0fd                	bnez	s1,80005a92 <virtio_disk_rw+0x1f0>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80005aae:	0001e517          	auipc	a0,0x1e
    80005ab2:	b6a50513          	addi	a0,a0,-1174 # 80023618 <disk+0x128>
    80005ab6:	9c6fb0ef          	jal	80000c7c <release>
}
    80005aba:	60e6                	ld	ra,88(sp)
    80005abc:	6446                	ld	s0,80(sp)
    80005abe:	64a6                	ld	s1,72(sp)
    80005ac0:	6906                	ld	s2,64(sp)
    80005ac2:	79e2                	ld	s3,56(sp)
    80005ac4:	7a42                	ld	s4,48(sp)
    80005ac6:	7aa2                	ld	s5,40(sp)
    80005ac8:	7b02                	ld	s6,32(sp)
    80005aca:	6be2                	ld	s7,24(sp)
    80005acc:	6c42                	ld	s8,16(sp)
    80005ace:	6125                	addi	sp,sp,96
    80005ad0:	8082                	ret

0000000080005ad2 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005ad2:	1101                	addi	sp,sp,-32
    80005ad4:	ec06                	sd	ra,24(sp)
    80005ad6:	e822                	sd	s0,16(sp)
    80005ad8:	e426                	sd	s1,8(sp)
    80005ada:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005adc:	0001e497          	auipc	s1,0x1e
    80005ae0:	a1448493          	addi	s1,s1,-1516 # 800234f0 <disk>
    80005ae4:	0001e517          	auipc	a0,0x1e
    80005ae8:	b3450513          	addi	a0,a0,-1228 # 80023618 <disk+0x128>
    80005aec:	90cfb0ef          	jal	80000bf8 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005af0:	100017b7          	lui	a5,0x10001
    80005af4:	53bc                	lw	a5,96(a5)
    80005af6:	8b8d                	andi	a5,a5,3
    80005af8:	10001737          	lui	a4,0x10001
    80005afc:	d37c                	sw	a5,100(a4)
    80005afe:	0ff0000f          	fence
  io_fence();

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while (disk.used_idx != disk.used->idx) {
    80005b02:	689c                	ld	a5,16(s1)
    80005b04:	0204d703          	lhu	a4,32(s1)
    80005b08:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005b0c:	04f70663          	beq	a4,a5,80005b58 <virtio_disk_intr+0x86>
    80005b10:	0ff0000f          	fence
    io_fence();
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005b14:	6898                	ld	a4,16(s1)
    80005b16:	0204d783          	lhu	a5,32(s1)
    80005b1a:	8b9d                	andi	a5,a5,7
    80005b1c:	078e                	slli	a5,a5,0x3
    80005b1e:	97ba                	add	a5,a5,a4
    80005b20:	43dc                	lw	a5,4(a5)

    if (disk.info[id].status != 0)
    80005b22:	00278713          	addi	a4,a5,2
    80005b26:	0712                	slli	a4,a4,0x4
    80005b28:	9726                	add	a4,a4,s1
    80005b2a:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    80005b2e:	e321                	bnez	a4,80005b6e <virtio_disk_intr+0x9c>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005b30:	0789                	addi	a5,a5,2
    80005b32:	0792                	slli	a5,a5,0x4
    80005b34:	97a6                	add	a5,a5,s1
    80005b36:	6788                	ld	a0,8(a5)
    b->disk = 0; // disk is done with buf
    80005b38:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005b3c:	c1afc0ef          	jal	80001f56 <wakeup>

    disk.used_idx += 1;
    80005b40:	0204d783          	lhu	a5,32(s1)
    80005b44:	2785                	addiw	a5,a5,1
    80005b46:	17c2                	slli	a5,a5,0x30
    80005b48:	93c1                	srli	a5,a5,0x30
    80005b4a:	02f49023          	sh	a5,32(s1)
  while (disk.used_idx != disk.used->idx) {
    80005b4e:	6898                	ld	a4,16(s1)
    80005b50:	00275703          	lhu	a4,2(a4)
    80005b54:	faf71ee3          	bne	a4,a5,80005b10 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005b58:	0001e517          	auipc	a0,0x1e
    80005b5c:	ac050513          	addi	a0,a0,-1344 # 80023618 <disk+0x128>
    80005b60:	91cfb0ef          	jal	80000c7c <release>
}
    80005b64:	60e2                	ld	ra,24(sp)
    80005b66:	6442                	ld	s0,16(sp)
    80005b68:	64a2                	ld	s1,8(sp)
    80005b6a:	6105                	addi	sp,sp,32
    80005b6c:	8082                	ret
      panic("virtio_disk_intr status");
    80005b6e:	00002517          	auipc	a0,0x2
    80005b72:	baa50513          	addi	a0,a0,-1110 # 80007718 <etext+0x718>
    80005b76:	cd3fa0ef          	jal	80000848 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	0000100f          	fence.i
    800060a0:	12000073          	sfence.vma
    800060a4:	18051073          	csrw	satp,a0
    800060a8:	12000073          	sfence.vma
    800060ac:	02000537          	lui	a0,0x2000
    800060b0:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060b2:	0536                	slli	a0,a0,0xd
    800060b4:	02853083          	ld	ra,40(a0)
    800060b8:	03053103          	ld	sp,48(a0)
    800060bc:	03853183          	ld	gp,56(a0)
    800060c0:	04053203          	ld	tp,64(a0)
    800060c4:	04853283          	ld	t0,72(a0)
    800060c8:	05053303          	ld	t1,80(a0)
    800060cc:	05853383          	ld	t2,88(a0)
    800060d0:	7120                	ld	s0,96(a0)
    800060d2:	7524                	ld	s1,104(a0)
    800060d4:	7d2c                	ld	a1,120(a0)
    800060d6:	6150                	ld	a2,128(a0)
    800060d8:	6554                	ld	a3,136(a0)
    800060da:	6958                	ld	a4,144(a0)
    800060dc:	6d5c                	ld	a5,152(a0)
    800060de:	0a053803          	ld	a6,160(a0)
    800060e2:	0a853883          	ld	a7,168(a0)
    800060e6:	0b053903          	ld	s2,176(a0)
    800060ea:	0b853983          	ld	s3,184(a0)
    800060ee:	0c053a03          	ld	s4,192(a0)
    800060f2:	0c853a83          	ld	s5,200(a0)
    800060f6:	0d053b03          	ld	s6,208(a0)
    800060fa:	0d853b83          	ld	s7,216(a0)
    800060fe:	0e053c03          	ld	s8,224(a0)
    80006102:	0e853c83          	ld	s9,232(a0)
    80006106:	0f053d03          	ld	s10,240(a0)
    8000610a:	0f853d83          	ld	s11,248(a0)
    8000610e:	10053e03          	ld	t3,256(a0)
    80006112:	10853e83          	ld	t4,264(a0)
    80006116:	11053f03          	ld	t5,272(a0)
    8000611a:	11853f83          	ld	t6,280(a0)
    8000611e:	7928                	ld	a0,112(a0)
    80006120:	10200073          	sret
	...
